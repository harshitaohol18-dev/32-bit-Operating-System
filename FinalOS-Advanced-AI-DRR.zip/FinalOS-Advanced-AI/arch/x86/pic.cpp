// pic.cpp - remaps IRQ0-15 from vectors 0x08-0x0F/0x70-0x77 (which
// collide with CPU exceptions) onto 32-47.
#include "pic.hpp"
#include "ports.hpp"

#define PIC1_COMMAND 0x20
#define PIC1_DATA    0x21
#define PIC2_COMMAND 0xA0
#define PIC2_DATA    0xA1

#define ICW1_INIT    0x10
#define ICW1_ICW4    0x01
#define ICW4_8086    0x01
#define PIC_EOI      0x20

using namespace Ports;

namespace PIC {

    void remap(uint8_t masterOffset, uint8_t slaveOffset) {
        uint8_t mask1 = inb(PIC1_DATA);
        uint8_t mask2 = inb(PIC2_DATA);

        outb(PIC1_COMMAND, ICW1_INIT | ICW1_ICW4); io_wait();
        outb(PIC2_COMMAND, ICW1_INIT | ICW1_ICW4); io_wait();

        outb(PIC1_DATA, masterOffset); io_wait();
        outb(PIC2_DATA, slaveOffset);  io_wait();

        outb(PIC1_DATA, 4); io_wait();   // slave attached at IRQ2
        outb(PIC2_DATA, 2); io_wait();   // slave cascade identity

        outb(PIC1_DATA, ICW4_8086); io_wait();
        outb(PIC2_DATA, ICW4_8086); io_wait();

        outb(PIC1_DATA, mask1);
        outb(PIC2_DATA, mask2);
    }

    void sendEOI(uint8_t irq) {
        if (irq >= 8) {
            outb(PIC2_COMMAND, PIC_EOI);
        }
        outb(PIC1_COMMAND, PIC_EOI);
    }

    void setMask(uint8_t irqLine) {
        uint16_t port = irqLine < 8 ? PIC1_DATA : PIC2_DATA;
        uint8_t  bit  = irqLine < 8 ? irqLine : irqLine - 8;
        uint8_t  value = inb(port) | (1 << bit);
        outb(port, value);
    }

    void clearMask(uint8_t irqLine) {
        uint16_t port = irqLine < 8 ? PIC1_DATA : PIC2_DATA;
        uint8_t  bit  = irqLine < 8 ? irqLine : irqLine - 8;
        uint8_t  value = inb(port) & ~(1 << bit);
        outb(port, value);
    }
}
