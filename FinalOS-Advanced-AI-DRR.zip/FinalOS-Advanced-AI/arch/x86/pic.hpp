#pragma once
// pic.hpp - 8259 Programmable Interrupt Controller: remapping and EOI.
#include <stdint.h>

namespace PIC {
    void remap(uint8_t masterOffset, uint8_t slaveOffset);
    void sendEOI(uint8_t irq);
    void setMask(uint8_t irqLine);
    void clearMask(uint8_t irqLine);
}
