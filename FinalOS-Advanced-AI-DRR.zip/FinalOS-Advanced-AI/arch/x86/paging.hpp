#pragma once
#include <stdint.h>
namespace Paging {
constexpr uint32_t PAGE_SIZE=4096, PAGE_PRESENT=1, PAGE_RW=2, PAGE_USER=4;
constexpr uint32_t USER_CODE_BASE=0x00800000;
// NOTE: the user stack window must sit inside the identity-mapped low
// 32MB range this kernel actually manages (see paging.cpp's NUM_TABLES),
// since mapPage()/decompose() only manage page tables within that
// range. The traditional 0xBFFFE000 (~3GB) address used by higher-half
// kernels doesn't have a page table allocated for it here at all, so
// mapping the user stack there silently failed (decompose() rejects
// any directory index >= NUM_TABLES) and the very first ring-3 process
// page-faulted on its own stack before executing a single instruction.
// This window (just under the 32MB identity-map ceiling, comfortably
// above the kernel image/heap/BSS which all load starting at 1MB) is
// reused across whichever process is currently "activated" - see
// process.cpp's activate(), which remaps it to that process's private
// physical stack page on every switch.
constexpr uint32_t USER_STACK_TOP=0x01FFF000;
constexpr uint32_t USER_STACK_PAGE=USER_STACK_TOP-PAGE_SIZE;
constexpr uint32_t USER_DATA_BASE=0x00900000;
void initialize();
bool mapPage(uint32_t virtualAddr,uint32_t physicalAddr,uint32_t flags);
void unmapPage(uint32_t virtualAddr);
bool isMapped(uint32_t virtualAddr);
bool isUserAccessible(uint32_t virtualAddr,uint32_t length,bool write);
bool setUserPage(uint32_t virtualAddr,bool writable);
}
