#pragma once
// interrupts.hpp - ties ISR/IRQ assembly stubs to C++ handlers, and
// gives drivers (timer, keyboard, disk...) a way to hook a specific IRQ.
#include <stdint.h>

namespace Interrupts {

    // Register layout pushed by isr_common_stub / irq_common_stub.
    struct Registers {
        uint32_t ds;
        uint32_t edi, esi, ebp, espDummy, ebx, edx, ecx, eax; // pusha order
        uint32_t intNumber;
        uint32_t errorCode;
        uint32_t eip, cs, eflags, useresp, ss; // pushed by CPU
    } __attribute__((packed));

    typedef void (*Handler)(Registers* regs);
    typedef void (*FaultHandler)(Registers* regs);

    void initialize();

    extern "C" void isr_common_handler(Registers* regs);
    extern "C" void irq_common_handler(Registers* regs);

    // Lets drivers install a handler for a specific IRQ line (0-15).
    void registerIRQHandler(uint8_t irq, Handler handler);

    // Lets a module (paging) handle a specific CPU exception vector
    // (0-31) instead of the default "print and halt" behaviour.
    void registerFaultHandler(uint8_t vector, FaultHandler handler);
}
