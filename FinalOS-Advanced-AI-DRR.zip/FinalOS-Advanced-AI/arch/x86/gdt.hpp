#pragma once
#include <stdint.h>
namespace GDT {
struct GDTEntry{uint16_t limitLow;uint16_t baseLow;uint8_t baseMiddle;uint8_t access;uint8_t granularity;uint8_t baseHigh;} __attribute__((packed));
struct GDTPointer{uint16_t limit;uint32_t base;} __attribute__((packed));
enum Selector:uint16_t{KERNEL_CODE=0x08,KERNEL_DATA=0x10,USER_CODE=0x1b,USER_DATA=0x23,TSS=0x28};
void initialize();
void installTSSDescriptor(uint32_t base,uint32_t limit);
}
