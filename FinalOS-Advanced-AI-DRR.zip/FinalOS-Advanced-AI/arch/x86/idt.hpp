#pragma once
// idt.hpp - Interrupt Descriptor Table: maps each of the 256 interrupt
// vectors to a handler gate.
#include <stdint.h>

namespace IDT {

    struct IDTEntry {
        uint16_t baseLow;
        uint16_t selector;
        uint8_t  zero;
        uint8_t  flags;
        uint16_t baseHigh;
    } __attribute__((packed));

    struct IDTPointer {
        uint16_t limit;
        uint32_t base;
    } __attribute__((packed));

    enum GateFlags : uint8_t {
        INTERRUPT_GATE_RING0 = 0x8E,
        TRAP_GATE_RING0      = 0x8F,
        INTERRUPT_GATE_RING3 = 0xEE, // callable via `int` from ring3 (syscalls)
    };

    void initialize();
    void setGate(uint8_t vector, uint32_t handler, uint16_t selector, uint8_t flags);
}
