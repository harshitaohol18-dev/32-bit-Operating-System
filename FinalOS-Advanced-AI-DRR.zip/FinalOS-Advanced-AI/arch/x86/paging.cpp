#include "paging.hpp"
#include "interrupts.hpp"
extern "C" void kprint(const char*); extern "C" void kprintHex(uint32_t);
namespace Paging {
constexpr uint32_t IDENTITY_MAP_MB=32, NUM_TABLES=IDENTITY_MAP_MB/4;
static uint32_t pageDirectory[1024] __attribute__((aligned(4096)));
static uint32_t pageTables[NUM_TABLES][1024] __attribute__((aligned(4096)));
static inline uint32_t readCR2(){uint32_t v;asm volatile("mov %%cr2,%0":"=r"(v));return v;}
static void loadCR3(uint32_t p){asm volatile("mov %0,%%cr3"::"r"(p):"memory");}
static void enablePaging(){uint32_t c;asm volatile("mov %%cr0,%0":"=r"(c));c|=0x80000000;asm volatile("mov %0,%%cr0"::"r"(c):"memory");}
static void invlpg(uint32_t a){asm volatile("invlpg (%0)"::"r"(a):"memory");}
static void pageFaultHandler(Interrupts::Registers* r){
 uint32_t a=readCR2(); kprint("[PAGE FAULT] addr=");kprintHex(a);
 kprint((r->errorCode&1)?" present":" not-present");kprint((r->errorCode&2)?" write":" read");
 kprint((r->errorCode&4)?" user":" kernel");kprint(" eip=");kprintHex(r->eip);kprint("\n");
 asm volatile("cli; hlt");
}
void initialize(){
 kprint("[PAGING] Enabling identity paging (32MB)...\n");
 for(int i=0;i<1024;i++)pageDirectory[i]=0;
 for(uint32_t t=0;t<NUM_TABLES;t++){
  for(uint32_t e=0;e<1024;e++)pageTables[t][e]=(t*1024+e)*PAGE_SIZE|PAGE_PRESENT|PAGE_RW;
  pageDirectory[t]=(uint32_t)&pageTables[t]|PAGE_PRESENT|PAGE_RW;
 }
 Interrupts::registerFaultHandler(14,pageFaultHandler);
 loadCR3((uint32_t)&pageDirectory); enablePaging();
}
static bool decompose(uint32_t va,uint32_t* d,uint32_t* t){*d=va>>22;if(*d>=NUM_TABLES)return false;*t=(va>>12)&1023;return true;}
bool mapPage(uint32_t va,uint32_t pa,uint32_t flags){
 uint32_t d,t;if(!decompose(va,&d,&t))return false;
 pageTables[d][t]=(pa&~0xfff)|(flags|PAGE_PRESENT);
 pageDirectory[d]=((uint32_t)&pageTables[d])|PAGE_PRESENT|PAGE_RW|(flags&PAGE_USER);
 invlpg(va&~0xfff);return true;
}
void unmapPage(uint32_t va){uint32_t d,t;if(!decompose(va,&d,&t))return;pageTables[d][t]=0;invlpg(va&~0xfff);}
bool isMapped(uint32_t va){uint32_t d,t;if(!decompose(va,&d,&t))return false;return (pageTables[d][t]&PAGE_PRESENT)!=0;}
static uint32_t pte(uint32_t va){uint32_t d,t;if(!decompose(va,&d,&t))return 0;return pageTables[d][t];}
bool isUserAccessible(uint32_t va,uint32_t len,bool write){
 if(len==0)return true;
 uint32_t end=va+len-1;if(end<va)return false;
 for(uint32_t p=va&~0xfff;p<=end;p+=PAGE_SIZE){
  uint32_t e=pte(p);if(!(e&PAGE_PRESENT)||!(e&PAGE_USER))return false;
  if(write && !(e&PAGE_RW))return false;
  if(p>end-PAGE_SIZE)break;
 }
 return true;
}
bool setUserPage(uint32_t va,bool writable){
 uint32_t d,t;if(!decompose(va,&d,&t))return false;
 if(!(pageTables[d][t]&PAGE_PRESENT))return false;
 pageTables[d][t]|=PAGE_USER;if(writable)pageTables[d][t]|=PAGE_RW;else pageTables[d][t]&=~PAGE_RW;
 pageDirectory[d]|=PAGE_USER;invlpg(va&~0xfff);return true;
}
}
