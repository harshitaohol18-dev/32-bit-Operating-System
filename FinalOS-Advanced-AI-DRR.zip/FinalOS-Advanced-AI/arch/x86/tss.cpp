#include "tss.hpp"
#include "gdt.hpp"

extern "C" void kprint(const char*);
extern "C" void tss_flush(uint16_t selector);

namespace TSS {
    static Entry tss __attribute__((aligned(16)));
    static uint8_t bootstrapStack[16384] __attribute__((aligned(16)));

    void initialize() {
        for (uint32_t i=0;i<sizeof(Entry);++i) ((uint8_t*)&tss)[i]=0;
        tss.ss0 = GDT::KERNEL_DATA;
        tss.esp0 = (uint32_t)(bootstrapStack + sizeof(bootstrapStack));
        tss.iomap_base = sizeof(Entry);
        GDT::installTSSDescriptor((uint32_t)&tss, sizeof(Entry)-1);
        tss_flush(SELECTOR);
        kprint("[TSS] Loaded ring-3 privilege transition state\n");
    }
    void setKernelStack(uint32_t esp0) { tss.esp0=esp0; }
    uint32_t getKernelStack() { return tss.esp0; }
    Entry* raw() { return &tss; }
}
