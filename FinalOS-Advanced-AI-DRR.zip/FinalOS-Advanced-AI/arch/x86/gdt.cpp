#include "gdt.hpp"
extern "C" void kprint(const char*);
extern "C" void gdt_flush(uint32_t);
namespace GDT {
static const int GDT_ENTRIES=6;
static GDTEntry entries[GDT_ENTRIES]; static GDTPointer pointer;
static void setEntry(int i,uint32_t base,uint32_t limit,uint8_t access,uint8_t flags){
    entries[i].baseLow=base&0xffff; entries[i].baseMiddle=(base>>16)&0xff;
    entries[i].baseHigh=(base>>24)&0xff; entries[i].limitLow=limit&0xffff;
    entries[i].granularity=((limit>>16)&0x0f)|(flags&0xf0); entries[i].access=access;
}
static void setTSS(int i,uint32_t base,uint32_t limit){
    setEntry(i,base,limit,0x89,0x40);
}
void initialize(){
    pointer.limit=sizeof(GDTEntry)*GDT_ENTRIES-1; pointer.base=(uint32_t)&entries;
    setEntry(0,0,0,0,0);
    setEntry(1,0,0xffffffff,0x9a,0xc0);
    setEntry(2,0,0xffffffff,0x92,0xc0);
    setEntry(3,0,0xffffffff,0xfa,0xc0);
    setEntry(4,0,0xffffffff,0xf2,0xc0);
    // TSS descriptor is filled by tss initialization helper after GDT load.
    // Its base is patched in kernel_main before LTR.
    setEntry(5,0,0,0x89,0x40);
    gdt_flush((uint32_t)&pointer);
    kprint("[GDT] Loaded kernel/user flat segments\n");
}
void installTSSDescriptor(uint32_t base,uint32_t limit){
    setTSS(5,base,limit);
    gdt_flush((uint32_t)&pointer);
}
}
