; idt_load.asm
[bits 32]
section .text
global idt_load

; void idt_load(uint32_t idtPointerAddr)
idt_load:
    mov eax, [esp+4]
    lidt [eax]
    ret
