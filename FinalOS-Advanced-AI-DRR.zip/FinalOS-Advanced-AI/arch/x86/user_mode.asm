; enter_user_mode(uint32_t eip, uint32_t esp)
[bits 32]
section .text
global enter_user_mode
enter_user_mode:
    cli
    mov eax,[esp+4]
    mov edx,[esp+8]
    mov ecx,0x23
    mov ds,cx
    mov es,cx
    mov fs,cx
    mov gs,cx
    push dword 0x23
    push edx
    push dword 0x202
    push dword 0x1b
    push eax
    iretd
.hang:
    cli
    hlt
    jmp .hang
