// interrupts.cpp - central interrupt dispatcher: builds the 256 IDT
// gates for CPU exceptions (0-31) and hardware IRQs (32-47), prints
// readable exception messages, and forwards hardware IRQs (with EOI)
// to whichever driver registered for that line.
#include "interrupts.hpp"
#include "idt.hpp"
#include "gdt.hpp"
#include "pic.hpp"

extern "C" void kprint(const char* str);
extern "C" void kprintHex(uint32_t value);

// Assembly ISR stubs (isr.asm) - vectors 0-31
extern "C" void isr0();  extern "C" void isr1();  extern "C" void isr2();
extern "C" void isr3();  extern "C" void isr4();  extern "C" void isr5();
extern "C" void isr6();  extern "C" void isr7();  extern "C" void isr8();
extern "C" void isr9();  extern "C" void isr10(); extern "C" void isr11();
extern "C" void isr12(); extern "C" void isr13(); extern "C" void isr14();
extern "C" void isr15(); extern "C" void isr16(); extern "C" void isr17();
extern "C" void isr18(); extern "C" void isr19(); extern "C" void isr20();
extern "C" void isr21(); extern "C" void isr22(); extern "C" void isr23();
extern "C" void isr24(); extern "C" void isr25(); extern "C" void isr26();
extern "C" void isr27(); extern "C" void isr28(); extern "C" void isr29();
extern "C" void isr30(); extern "C" void isr31();

// Assembly IRQ stubs (irq.asm) - remapped to vectors 32-47
extern "C" void irq0();  extern "C" void irq1();  extern "C" void irq2();
extern "C" void irq3();  extern "C" void irq4();  extern "C" void irq5();
extern "C" void irq6();  extern "C" void irq7();  extern "C" void irq8();
extern "C" void irq9();  extern "C" void irq10(); extern "C" void irq11();
extern "C" void irq12(); extern "C" void irq13(); extern "C" void irq14();
extern "C" void irq15();

namespace Interrupts {

    static const char* exceptionMessages[32] = {
        "Divide by Zero", "Debug", "Non-Maskable Interrupt", "Breakpoint",
        "Overflow", "Bound Range Exceeded", "Invalid Opcode",
        "Device Not Available", "Double Fault", "Coprocessor Segment Overrun",
        "Invalid TSS", "Segment Not Present", "Stack-Segment Fault",
        "General Protection Fault", "Page Fault", "Reserved",
        "x87 Floating Point Exception", "Alignment Check", "Machine Check",
        "SIMD Floating Point Exception", "Virtualization Exception",
        "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
        "Reserved", "Reserved", "Reserved", "Reserved",
        "Security Exception", "Reserved"
    };

    static Handler irqHandlers[16] = { nullptr };
    static FaultHandler faultHandlers[32] = { nullptr };

    void registerIRQHandler(uint8_t irq, Handler handler) {
        if (irq < 16) irqHandlers[irq] = handler;
    }

    void registerFaultHandler(uint8_t vector, FaultHandler handler) {
        if (vector < 32) faultHandlers[vector] = handler;
    }

    void initialize() {
        kprint("[INT] Installing ISR/IRQ gates...\n");

        void (*isrTable[32])() = {
            isr0, isr1, isr2, isr3, isr4, isr5, isr6, isr7,
            isr8, isr9, isr10, isr11, isr12, isr13, isr14, isr15,
            isr16, isr17, isr18, isr19, isr20, isr21, isr22, isr23,
            isr24, isr25, isr26, isr27, isr28, isr29, isr30, isr31
        };
        for (int i = 0; i < 32; i++) {
            IDT::setGate(i, (uint32_t)isrTable[i], GDT::KERNEL_CODE,
                         IDT::INTERRUPT_GATE_RING0);
        }

        PIC::remap(0x20, 0x28);

        void (*irqTable[16])() = {
            irq0, irq1, irq2, irq3, irq4, irq5, irq6, irq7,
            irq8, irq9, irq10, irq11, irq12, irq13, irq14, irq15
        };
        for (int i = 0; i < 16; i++) {
            IDT::setGate(32 + i, (uint32_t)irqTable[i], GDT::KERNEL_CODE,
                         IDT::INTERRUPT_GATE_RING0);
        }

        kprint("[INT] IDT gates installed, PIC remapped to 32-47\n");
    }

    extern "C" void isr_common_handler(Registers* regs) {
        if (regs->intNumber < 32) {
            if (faultHandlers[regs->intNumber]) {
                faultHandlers[regs->intNumber](regs);
                return;
            }

            kprint("[EXCEPTION] ");
            kprint(exceptionMessages[regs->intNumber]);
            kprint(" (vec=");
            kprintHex(regs->intNumber);
            kprint(" err=");
            kprintHex(regs->errorCode);
            kprint(" eip=");
            kprintHex(regs->eip);
            kprint(")\n");

            // No recovery path for unhandled exceptions -> halt.
            asm volatile ("cli; hlt");
        }
    }

    extern "C" void irq_common_handler(Registers* regs) {
        uint8_t irq = (uint8_t)(regs->intNumber - 32);

        // EOI must be sent BEFORE calling the handler, not after: the
        // timer handler can trigger Scheduler::tick() -> schedule() ->
        // context_switch(), which for a task that has never run before
        // jumps into task_trampoline and never returns through this
        // function at all. If EOI were sent afterwards, that first
        // real context switch would permanently starve the PIC of an
        // EOI for this (highest-priority) line and no further IRQs
        // would ever be delivered again.
        PIC::sendEOI(irq);

        if (irqHandlers[irq]) {
            irqHandlers[irq](regs);
        }
    }
}
