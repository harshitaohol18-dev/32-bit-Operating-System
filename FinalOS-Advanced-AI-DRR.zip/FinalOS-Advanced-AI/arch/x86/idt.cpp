// idt.cpp - builds the 256-entry IDT and loads it. Gate contents are
// filled in by Interrupts::initialize() and Syscall::initialize().
#include "idt.hpp"

extern "C" void kprint(const char* str);
extern "C" void idt_load(uint32_t idtPointerAddr); // idt_load.asm

namespace IDT {

    static IDTEntry   entries[256];
    static IDTPointer pointer;

    void setGate(uint8_t vector, uint32_t handler, uint16_t selector, uint8_t flags) {
        entries[vector].baseLow  = handler & 0xFFFF;
        entries[vector].baseHigh = (handler >> 16) & 0xFFFF;
        entries[vector].selector = selector;
        entries[vector].zero     = 0;
        entries[vector].flags    = flags;
    }

    void initialize() {
        kprint("[IDT] Initializing...\n");

        pointer.limit = sizeof(IDTEntry) * 256 - 1;
        pointer.base  = (uint32_t)&entries;

        for (int i = 0; i < 256; i++) {
            entries[i] = {0, 0, 0, 0, 0};
        }

        idt_load((uint32_t)&pointer);

        kprint("[IDT] Loaded successfully\n");
    }
}
