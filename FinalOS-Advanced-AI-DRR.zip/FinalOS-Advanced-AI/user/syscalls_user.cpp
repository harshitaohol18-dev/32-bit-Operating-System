#include <stdint.h>
#include "../syscall/syscall.hpp"
static inline __attribute__((section(".user_text"))) int32_t usys(uint32_t n,uint32_t a=0,uint32_t b=0,uint32_t c=0){int32_t r;asm volatile("int $0x80":"=a"(r):"a"(n),"b"(a),"c"(b),"d"(c):"memory");return r;}
extern "C" __attribute__((section(".user_text"))) int32_t u_write(const char*s){uint32_t n=0;while(s[n])n++;return usys(Syscall::SYS_WRITE,1,(uint32_t)s,n);}
extern "C" __attribute__((section(".user_text"))) int32_t u_write_n(const char*s,uint32_t n){return usys(Syscall::SYS_WRITE,1,(uint32_t)s,n);}
extern "C" __attribute__((section(".user_text"))) int32_t u_getpid(){return usys(Syscall::SYS_GETPID);}
extern "C" __attribute__((section(".user_text"))) int32_t u_getuid(){return usys(Syscall::SYS_GETUID);}
extern "C" __attribute__((section(".user_text"))) int32_t u_fork(){return usys(Syscall::SYS_FORK);}
extern "C" __attribute__((section(".user_text"))) int32_t u_yield(){return usys(Syscall::SYS_YIELD);}
extern "C" __attribute__((section(".user_text"))) int32_t u_sleep(uint32_t t){return usys(Syscall::SYS_SLEEP,t);}
extern "C" __attribute__((section(".user_text"))) int32_t u_exit(uint32_t s){return usys(Syscall::SYS_EXIT,s);}
extern "C" __attribute__((section(".user_text"))) int32_t u_pipe(uint32_t fds[2]){return usys(Syscall::SYS_PIPE,(uint32_t)fds);}
extern "C" __attribute__((section(".user_text"))) int32_t u_read(uint32_t fd,char*b,uint32_t n){return usys(Syscall::SYS_READ,fd,(uint32_t)b,n);}
extern "C" __attribute__((section(".user_text"))) int32_t u_writefd(uint32_t fd,const char*b,uint32_t n){return usys(Syscall::SYS_WRITE,fd,(uint32_t)b,n);}
extern "C" __attribute__((section(".user_text"))) int32_t u_close(uint32_t fd){return usys(Syscall::SYS_CLOSE,fd);}
extern "C" __attribute__((section(".user_text"))) int32_t u_msg_create(uint32_t n){return usys(Syscall::SYS_MSG_CREATE,n);}
extern "C" __attribute__((section(".user_text"))) int32_t u_msg_send(uint32_t q,const char*m,uint32_t n){return usys(Syscall::SYS_MSG_SEND,q,(uint32_t)m,n);}
extern "C" __attribute__((section(".user_text"))) int32_t u_msg_recv(uint32_t q,char*m,uint32_t n){return usys(Syscall::SYS_MSG_RECEIVE,q,(uint32_t)m,n);}
extern "C" __attribute__((section(".user_text"))) int32_t u_msg_destroy(uint32_t q){return usys(Syscall::SYS_MSG_DESTROY,q);}
extern "C" __attribute__((section(".user_text"))) int32_t u_open(const char*p,uint32_t f){return usys(Syscall::SYS_OPEN,(uint32_t)p,f);}
extern "C" __attribute__((section(".user_text"))) int32_t u_closefile(uint32_t f){return usys(Syscall::SYS_CLOSE,f);}
extern "C" __attribute__((section(".user_text"))) int32_t u_setprio(uint32_t p,uint32_t n){return usys(Syscall::SYS_SET_PRIORITY,p,n);}
extern "C" __attribute__((section(".user_text"))) int32_t u_getprio(uint32_t p){return usys(Syscall::SYS_GET_PRIORITY,p);}

extern "C" __attribute__((section(".user_text"))) int32_t u_get_process_info(void*p){return usys(Syscall::SYS_GET_PROCESS_INFO,(uint32_t)p);}

extern "C" __attribute__((section(".user_text"))) int32_t u_exec(const char*p){return usys(Syscall::SYS_EXEC,(uint32_t)p);}
