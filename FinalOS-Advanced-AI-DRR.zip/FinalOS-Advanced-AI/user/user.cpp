// user.cpp - public user-subsystem translation unit.
// Account storage and authentication are implemented in auth.cpp;
// this file intentionally contains no global constructors or libc dependencies.
namespace User { void subsystem_link_anchor() {} }
