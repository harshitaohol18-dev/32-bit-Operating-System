#include <stdint.h>
extern "C" int32_t u_write(const char*);extern "C" int32_t u_write_n(const char*,uint32_t);extern "C" int32_t u_getpid();extern "C" int32_t u_getuid();extern "C" int32_t u_fork();extern "C" int32_t u_yield();extern "C" int32_t u_exit(uint32_t);extern "C" int32_t u_pipe(uint32_t[2]);extern "C" int32_t u_read(uint32_t,char*,uint32_t);extern "C" int32_t u_writefd(uint32_t,const char*,uint32_t);extern "C" int32_t u_close(uint32_t);extern "C" int32_t u_msg_create(uint32_t);extern "C" int32_t u_msg_send(uint32_t,const char*,uint32_t);extern "C" int32_t u_msg_recv(uint32_t,char*,uint32_t);extern "C" int32_t u_msg_destroy(uint32_t);extern "C" int32_t u_open(const char*,uint32_t);extern "C" int32_t u_setprio(uint32_t,uint32_t);
#define URO __attribute__((section(".user_rodata")))
static const char s_pid[] URO="Ring 3 application running. PID/UID: ";
static const char s_kernel[] URO="Protected kernel memory is not user-accessible.\n";
static const char s_pipe[] URO="pipe_test: parent -> child message\n";
static const char s_msg[] URO="message_queue: hello from parent\n";
static const char s_recv[] URO="received: ";
static const char s_perm[] URO="permission_test: normal user write-open result = ";
static const char s_sched[] URO="scheduler_test PID=";
static const char s_fail[] URO="pipe_create failed\n";
static const char s_qfail[] URO="msg queue create failed\n";
static const char s_standalone[] URO="msg_receiver: use msg_sender for the forked queue demo.\n";
static const char s_nl[] URO="\n";
static const char s_slash[] URO="/";
static const char s_welcome_path[] URO="/welcome.txt";
static __attribute__((section(".user_text"))) void num(uint32_t v,char*b){char t[12];int n=0;if(v==0){b[0]='0';b[1]=0;return;}while(v){t[n++]=(char)('0'+v%10);v/=10;}for(int i=0;i<n;i++)b[i]=t[n-1-i];b[n]=0;}
extern "C" __attribute__((section(".user_text"))) void user_app_init(){char n[12];u_write(s_pid);num((uint32_t)u_getpid(),n);u_write(n);u_write(s_slash);num((uint32_t)u_getuid(),n);u_write(n);u_write(s_nl);u_write(s_kernel);u_exit(0);}
extern "C" __attribute__((section(".user_text"))) void user_app_pipe(){uint32_t f[2];if(u_pipe(f)<0){u_write(s_fail);u_exit(1);}int32_t c=u_fork();if(c==0){u_close(f[1]);char b[64];int32_t n;do{n=u_read(f[0],b,sizeof(b)-1);if(n>0){b[n]=0;u_write(s_recv);u_write(b);break;}u_yield();}while(1);u_close(f[0]);u_exit(0);}u_close(f[0]);u_writefd(f[1],s_pipe,sizeof(s_pipe)-1);u_close(f[1]);u_yield();u_exit(0);}
extern "C" __attribute__((section(".user_text"))) void user_app_msg_sender(){int32_t q=u_msg_create(8);if(q<0){u_write(s_qfail);u_exit(1);}int32_t c=u_fork();if(c==0){char b[64];int32_t n;do{n=u_msg_recv((uint32_t)q,b,sizeof(b));if(n>=0){u_write(s_recv);u_write(b);break;}u_yield();}while(1);u_msg_destroy((uint32_t)q);u_exit(0);}u_msg_send((uint32_t)q,s_msg,sizeof(s_msg)-1);u_yield();u_exit(0);}
extern "C" __attribute__((section(".user_text"))) void user_app_msg_receiver(){u_write(s_standalone);u_exit(0);}
extern "C" __attribute__((section(".user_text"))) void user_app_scheduler(){char b[12];uint32_t p=(uint32_t)u_getpid();u_setprio(p,3);for(int i=0;i<10;i++){u_write(s_sched);num(p,b);u_write(b);u_write(s_nl);u_yield();}u_exit(0);}
extern "C" __attribute__((section(".user_text"))) void user_app_permissions(){int32_t fd=u_open(s_welcome_path,3);u_write(s_perm);char b[12];num((uint32_t)(fd<0?fd:0),b);u_write(b);u_write(s_nl);if(fd>=0)u_close(fd);u_exit(0);}
