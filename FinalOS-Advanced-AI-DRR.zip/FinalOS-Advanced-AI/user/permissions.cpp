#include "permissions.hpp"
#include "user.hpp"
#include "../filesystem/filesystem.hpp"
namespace Permissions {
bool check(uint32_t uid,uint32_t gid,uint32_t owner,uint32_t group,uint16_t mode,uint8_t need){
 if(uid==0)return true;uint16_t m=(uid==owner)?((mode>>6)&7):(gid==group?((mode>>3)&7):(mode&7));
 return (m&need)==need;
}
bool check_permission(uint32_t uid,uint32_t gid,uint32_t owner,uint32_t group,uint16_t mode,uint8_t need){return check(uid,gid,owner,group,mode,need);}
bool chmod(const char* path,uint16_t mode){if(!User::get_current_user())return false;return FS::FileSystem::chmod(path,mode);}
bool chown(const char* path,uint32_t uid,uint32_t gid){if(!User::isRoot())return false;return FS::FileSystem::chown(path,uid,gid);}
void modeString(uint16_t m,char out[10]){out[0]=(m&0400)?'r':'-';out[1]=(m&0200)?'w':'-';out[2]=(m&0100)?'x':'-';out[3]=(m&0040)?'r':'-';out[4]=(m&0020)?'w':'-';out[5]=(m&0010)?'x':'-';out[6]=(m&0004)?'r':'-';out[7]=(m&0002)?'w':'-';out[8]=(m&0001)?'x':'-';out[9]=0;}
}
