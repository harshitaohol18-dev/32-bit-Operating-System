#pragma once
#include <stdint.h>
namespace Permissions {
enum Bits:uint16_t{OWNER_READ=0400,OWNER_WRITE=0200,OWNER_EXECUTE=0100,GROUP_READ=0040,GROUP_WRITE=0020,GROUP_EXECUTE=0010,OTHER_READ=0004,OTHER_WRITE=0002,OTHER_EXECUTE=0001};
bool check(uint32_t uid,uint32_t gid,uint32_t owner,uint32_t group,uint16_t mode,uint8_t need);
bool check_permission(uint32_t uid,uint32_t gid,uint32_t owner,uint32_t group,uint16_t mode,uint8_t need);
bool chmod(const char* path,uint16_t mode);
bool chown(const char* path,uint32_t uid,uint32_t gid);
void modeString(uint16_t mode,char out[10]);
}
