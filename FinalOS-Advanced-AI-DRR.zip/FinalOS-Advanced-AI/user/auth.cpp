#include "user.hpp"
#include "../drivers/vga.hpp"
#include "../drivers/keyboard.hpp"
#include "../libc/kstd.hpp"
#include "../mm/heap.hpp"
#include <stdint.h>

namespace User {
static UserAccount accounts[MAX_USERS]; static UserAccount* current=nullptr;
static const char hex[]="0123456789abcdef";
static uint32_t rotr(uint32_t x,uint32_t n){return (x>>n)|(x<<(32-n));}
static uint32_t K(uint32_t i){static const uint32_t k[64]={
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
return k[i];}
static uint32_t rotr32(uint32_t x,uint32_t n){return (x>>n)|(x<<(32-n));}
static void sha256(const char* s,char out[HASH_LEN]){
 uint8_t msg[128];uint32_t n=0;while(s[n]&&n<110){msg[n]=(uint8_t)s[n];n++;}
 uint32_t bitlen=n*8;msg[n++]=0x80;while(n%64!=56)msg[n++]=0;
 msg[n++]=0;msg[n++]=0;msg[n++]=0;msg[n++]=(bitlen>>24)&255;msg[n++]=(bitlen>>16)&255;msg[n++]=(bitlen>>8)&255;msg[n++]=bitlen&255;
 uint32_t h[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
 for(uint32_t off=0;off<n;off+=64){uint32_t w[64];for(int i=0;i<16;i++)w[i]=(msg[off+i*4]<<24)|(msg[off+i*4+1]<<16)|(msg[off+i*4+2]<<8)|msg[off+i*4+3];
  for(int i=16;i<64;i++){uint32_t a=rotr32(w[i-15],7)^rotr32(w[i-15],18)^(w[i-15]>>3);uint32_t b=rotr32(w[i-2],17)^rotr32(w[i-2],19)^(w[i-2]>>10);w[i]=w[i-16]+a+w[i-7]+b;}
  uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
  for(int i=0;i<64;i++){uint32_t S1=rotr32(e,6)^rotr32(e,11)^rotr32(e,25);uint32_t ch=(e&f)^((~e)&g);uint32_t temp1=hh+S1+ch+K(i)+w[i];uint32_t S0=rotr32(a,2)^rotr32(a,13)^rotr32(a,22);uint32_t maj=(a&b)^(a&c)^(b&c);uint32_t temp2=S0+maj;hh=g;g=f;f=e;e=d+temp1;d=c;c=b;b=a;a=temp1+temp2;}
  h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=hh;
 }
 for(int i=0;i<8;i++)for(int j=0;j<4;j++){uint8_t v=(h[i]>>(24-j*8))&255;out[i*8+j*2]=hex[v>>4];out[i*8+j*2+1]=hex[v&15];}out[64]=0;
}
static bool eq(const char*a,const char*b){return KLib::strcmp(a,b)==0;}
static void copy(char*d,const char*s,uint32_t n){KLib::strncpy(d,s,n);d[n-1]=0;}
void initialize(){for(uint32_t i=0;i<MAX_USERS;i++){accounts[i].uid=0;accounts[i].status=AccountStatus::DISABLED;}
 accounts[0].uid=0;accounts[0].gid=0;copy(accounts[0].username,"root",USERNAME_LEN);sha256("root",accounts[0].passwordHash);accounts[0].status=AccountStatus::ACTIVE;
 accounts[1].uid=1000;accounts[1].gid=1000;copy(accounts[1].username,"user",USERNAME_LEN);sha256("user",accounts[1].passwordHash);accounts[1].status=AccountStatus::ACTIVE;current=nullptr;}
bool authenticate_user(const char* u,const char*p){char h[HASH_LEN];sha256(p,h);for(uint32_t i=0;i<MAX_USERS;i++)if(accounts[i].status==AccountStatus::ACTIVE&&eq(accounts[i].username,u)&&eq(accounts[i].passwordHash,h)){current=&accounts[i];return true;}return false;}
UserAccount* get_current_user(){return current;}
bool isRoot(){return current&&current->uid==0;}
bool create_user(const char*u,const char*p,uint32_t uid,uint32_t gid){if(!isRoot()||!u||!p||uid==0)return false;for(uint32_t i=0;i<MAX_USERS;i++)if(accounts[i].status==AccountStatus::ACTIVE&&eq(accounts[i].username,u))return false;for(uint32_t i=0;i<MAX_USERS;i++)if(accounts[i].status==AccountStatus::DISABLED){accounts[i].uid=uid;accounts[i].gid=gid;copy(accounts[i].username,u,USERNAME_LEN);sha256(p,accounts[i].passwordHash);accounts[i].status=AccountStatus::ACTIVE;return true;}return false;}
bool delete_user(uint32_t uid){if(!isRoot()||uid==0)return false;for(uint32_t i=0;i<MAX_USERS;i++)if(accounts[i].status==AccountStatus::ACTIVE&&accounts[i].uid==uid){accounts[i].status=AccountStatus::DISABLED;return true;}return false;}
bool change_password(uint32_t uid,const char*oldp,const char*newp){if(!current||(!isRoot()&&current->uid!=uid))return false;if(!isRoot()){char h[HASH_LEN];sha256(oldp,h);if(!eq(h,current->passwordHash))return false;}for(uint32_t i=0;i<MAX_USERS;i++)if(accounts[i].status==AccountStatus::ACTIVE&&accounts[i].uid==uid){sha256(newp,accounts[i].passwordHash);return true;}return false;}
static void input(char*out,uint32_t max,bool hidden){uint32_t n=0;while(true){char c=Keyboard::get_char();if(c=='\n'){VGA::putchar('\n');break;}if(c=='\b'){if(n){n--;if(!hidden)VGA::putchar('\b');}continue;}if(c>=32&&c<=126&&n<max-1){out[n++]=c;if(!hidden)VGA::putchar(c);}}out[n]=0;}
bool loginPrompt(){char u[USERNAME_LEN],p[64];Keyboard::clear_buffer();for(int tries=0;tries<3;tries++){VGA::set_color(VGA::LIGHT_CYAN,VGA::BLACK);VGA::print("\nlogin: ");VGA::set_color(VGA::WHITE,VGA::BLACK);input(u,sizeof(u),false);VGA::print("password: ");input(p,sizeof(p),true);if(authenticate_user(u,p)){VGA::print("Login successful.\n");return true;}VGA::print("Authentication failed.\n");}return false;}
}
