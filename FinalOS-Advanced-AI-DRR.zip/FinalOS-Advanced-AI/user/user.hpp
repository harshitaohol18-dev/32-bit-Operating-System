#pragma once
#include <stdint.h>
namespace User {
constexpr uint32_t MAX_USERS=8;
constexpr uint32_t USERNAME_LEN=24;
constexpr uint32_t HASH_LEN=65;
enum class AccountStatus:uint32_t{ACTIVE=1,DISABLED=0};
struct UserAccount{
 uint32_t uid,gid; char username[USERNAME_LEN]; char passwordHash[HASH_LEN]; AccountStatus status;
};
void initialize();
bool authenticate_user(const char* username,const char* password);
UserAccount* get_current_user();
bool create_user(const char* username,const char* password,uint32_t uid,uint32_t gid);
bool delete_user(uint32_t uid);
bool change_password(uint32_t uid,const char* oldPassword,const char* newPassword);
bool loginPrompt();
bool isRoot();
}
