#pragma once
#include <stdint.h>
#include "../arch/x86/interrupts.hpp"
namespace Process {
enum class State{NEW,READY,RUNNING,BLOCKED,TERMINATED};
constexpr uint32_t MAX_USER_PROCESSES=8;
struct PCB{
 uint32_t pid,ppid,uid,gid,priority,effectivePriority,waitTicks,creationTick,wakeTick,cpuTicks,contextSwitches,exitStatus;
 State state;bool inUse;
 struct FD{bool used;uint32_t flags;uint32_t offset;uint32_t type;uint32_t object;char path[64];} fds[8];
 uint32_t userStackPhysical;
 uint32_t kernelStackPhysical;
 Interrupts::Registers frame;
};
}
