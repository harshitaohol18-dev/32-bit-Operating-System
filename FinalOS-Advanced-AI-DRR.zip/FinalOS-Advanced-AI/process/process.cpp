#include "process.hpp"
#include "../scheduler/scheduler.hpp"
#include "../user/user.hpp"
#include "../user/permissions.hpp"
#include "../filesystem/filesystem.hpp"
#include "../arch/x86/paging.hpp"
#include "../arch/x86/tss.hpp"
#include "../arch/x86/gdt.hpp"
#include "../drivers/keyboard.hpp"
#include "../ipc/pipe.hpp"
#include "../syscall/errors.hpp"
#include "../libc/kstd.hpp"
extern "C" void enter_user_mode(uint32_t,uint32_t);
extern "C" uint8_t __user_text_start[], __user_text_end[], __user_rodata_start[], __user_rodata_end[];
extern "C" void user_app_init(); extern "C" void user_app_pipe(); extern "C" void user_app_msg_sender();
extern "C" void user_app_msg_receiver(); extern "C" void user_app_scheduler(); extern "C" void user_app_permissions();
extern "C" void kprint(const char*);
namespace Process {
static PCB pcbs[MAX_USER_PROCESSES];static uint8_t stacks[MAX_USER_PROCESSES][Paging::PAGE_SIZE] __attribute__((aligned(4096)));
static uint8_t kernelStacks[MAX_USER_PROCESSES][Paging::PAGE_SIZE] __attribute__((aligned(4096)));
static uint32_t nextPid=100,userTicks=0,quantum=5,quantumLeft=5,rrCursor=0;static PCB*run=nullptr;static bool active=false;static void(*pendingEntry)()=nullptr;
static void cp(char*d,const char*s,uint32_t n){KLib::strncpy(d,s,n);d[n-1]=0;}
static PCB*slot(){for(uint32_t i=0;i<MAX_USER_PROCESSES;i++)if(!pcbs[i].inUse)return &pcbs[i];return nullptr;}
static void mapCode(){uint32_t a=(uint32_t)__user_text_start,e=(uint32_t)__user_text_end;for(a&=~4095u;a<e;a+=4096)Paging::setUserPage(a,false);a=(uint32_t)__user_rodata_start;e=(uint32_t)__user_rodata_end;for(a&=~4095u;a<e;a+=4096)Paging::setUserPage(a,false);}
static void activate(PCB*p,Interrupts::Registers*r){run=p;p->state=State::RUNNING;Paging::mapPage(Paging::USER_STACK_PAGE,p->userStackPhysical,Paging::PAGE_USER|Paging::PAGE_RW);TSS::setKernelStack(p->kernelStackPhysical+Paging::PAGE_SIZE);if(r)*r=p->frame;}
static PCB*select(){
 PCB*b=nullptr;Scheduler::Mode m=Scheduler::getMode();
 if(m==Scheduler::Mode::ROUND_ROBIN){
  for(uint32_t i=0;i<MAX_USER_PROCESSES;i++){PCB*p=&pcbs[i];if(!p->inUse||p->state!=State::READY||p->pid<=rrCursor)continue;if(!b||p->pid<b->pid)b=p;}
  if(!b)for(uint32_t i=0;i<MAX_USER_PROCESSES;i++){PCB*p=&pcbs[i];if(!p->inUse||p->state!=State::READY)continue;if(!b||p->pid<b->pid)b=p;}
  if(b)rrCursor=b->pid;
 }else{
  for(uint32_t i=0;i<MAX_USER_PROCESSES;i++){PCB*p=&pcbs[i];if(!p->inUse||p->state!=State::READY)continue;if(m==Scheduler::Mode::PRIORITY){if(!b||p->effectivePriority<b->effectivePriority)b=p;}else if(!b||p->creationTick<b->creationTick)b=p;}
 }
 return b;
}
static void save(PCB*p,Interrupts::Registers*r){p->frame=*r;p->contextSwitches++;}
static void choose(Interrupts::Registers*r){PCB*n=select();if(!n)return;if(run&&run->state==State::RUNNING){run->state=State::READY;run->waitTicks=0;run->effectivePriority=run->priority;}activate(n,r);n->waitTicks=0;n->effectivePriority=n->priority;quantumLeft=quantum;}
static void launcher(){if(!pendingEntry||!User::get_current_user()){Scheduler::terminateCurrentAndSchedule(ERR_PERMISSION);return;}PCB*p=slot();if(!p){Scheduler::terminateCurrentAndSchedule(ERR_NO_MEMORY);return;}uint32_t idx=(uint32_t)(p-pcbs);User::UserAccount*u=User::get_current_user();p->inUse=true;p->pid=nextPid++;p->ppid=Scheduler::currentTask()?Scheduler::currentTask()->pid:0;p->uid=u->uid;p->gid=u->gid;p->priority=5;p->effectivePriority=5;p->waitTicks=0;p->creationTick=userTicks;p->wakeTick=0;p->cpuTicks=0;p->contextSwitches=0;p->exitStatus=0;p->state=State::RUNNING;p->userStackPhysical=(uint32_t)&stacks[idx][0];p->kernelStackPhysical=(uint32_t)&kernelStacks[idx][0];for(uint32_t i=0;i<8;i++)p->fds[i]={false,0,0,0,0,{0}};p->fds[0].used=true;p->fds[0].flags=1;p->fds[0].type=0;p->fds[1].used=true;p->fds[1].flags=2;p->fds[1].type=0;mapCode();for(uint32_t i=0;i<4096;i++)stacks[idx][i]=0;Paging::mapPage(Paging::USER_STACK_PAGE,p->userStackPhysical,Paging::PAGE_USER|Paging::PAGE_RW);active=true;run=p;TSS::setKernelStack((uint32_t)(kernelStacks[idx]+4096));enter_user_mode((uint32_t)pendingEntry,(uint32_t)Paging::USER_STACK_TOP);while(1)asm volatile("hlt");}
void initialize(){for(uint32_t i=0;i<MAX_USER_PROCESSES;i++)pcbs[i].inUse=false;run=nullptr;active=false;}
int32_t create_process(const char* name, void(*entry)(), uint32_t priority){Scheduler::Task*t=Scheduler::createTask(name,entry,priority);return t?(int32_t)t->pid:ERR_NO_MEMORY;}
int32_t terminate_process(uint32_t pid,uint32_t status){for(uint32_t i=0;i<MAX_USER_PROCESSES;i++)if(pcbs[i].inUse&&pcbs[i].pid==pid){pcbs[i].exitStatus=status;pcbs[i].state=State::TERMINATED;pcbs[i].inUse=false;if(&pcbs[i]==run)run=nullptr;return SUCCESS;}Scheduler::removeTask(pid);return SUCCESS;}
int32_t kill_process(uint32_t pid){return terminate_process(pid,0);}
int32_t wait_process(uint32_t pid){(void)pid;return ERR_NOT_IMPLEMENTED;}
PCB* get_current_process(){return current();}
PCB* get_process(uint32_t pid){for(uint32_t i=0;i<MAX_USER_PROCESSES;i++)if(pcbs[i].inUse&&pcbs[i].pid==pid)return &pcbs[i];return nullptr;}

bool start(const char*name,uint32_t priority){(void)priority;if(active||!name)return false;pendingEntry=nullptr;if(KLib::strcmp(name,"init")==0||KLib::strcmp(name,"echo")==0)pendingEntry=user_app_init;else if(KLib::strcmp(name,"pipe_test")==0)pendingEntry=user_app_pipe;else if(KLib::strcmp(name,"msg_sender")==0)pendingEntry=user_app_msg_sender;else if(KLib::strcmp(name,"msg_receiver")==0)pendingEntry=user_app_msg_receiver;else if(KLib::strcmp(name,"scheduler_test")==0)pendingEntry=user_app_scheduler;else if(KLib::strcmp(name,"permission_test")==0)pendingEntry=user_app_permissions;else return false;return Scheduler::createTask("user-launcher",launcher,1)!=nullptr;}
bool isUserRunning(){return active&&run&&run->inUse;} PCB*current(){return run;}
void yield(Interrupts::Registers*r){if(!run)return;r->eax=SUCCESS;save(run,r);choose(r);}
void sleep(Interrupts::Registers*r,uint32_t ticks){if(!run)return;if(ticks==0){yield(r);return;}PCB*other=select();if(!other){r->eax=SUCCESS;uint32_t end=userTicks+ticks;while(userTicks<end)asm volatile("sti;hlt");return;}r->eax=SUCCESS;save(run,r);run->state=State::BLOCKED;run->wakeTick=userTicks+ticks;choose(r);}
void exitCurrent(Interrupts::Registers*r,uint32_t status){if(!run)return;run->exitStatus=status;run->state=State::TERMINATED;run->inUse=false;run=nullptr;PCB*n=select();if(n){activate(n,r);return;}active=false;Scheduler::terminateCurrentAndSchedule(status);}
static void wake(){for(uint32_t i=0;i<MAX_USER_PROCESSES;i++)if(pcbs[i].inUse&&pcbs[i].state==State::BLOCKED&&pcbs[i].wakeTick<=userTicks){pcbs[i].state=State::READY;pcbs[i].wakeTick=0;pcbs[i].waitTicks=0;pcbs[i].effectivePriority=pcbs[i].priority;}}
bool handleTimer(Interrupts::Registers*r){if(!isUserRunning())return false;userTicks++;run->cpuTicks++;for(uint32_t i=0;i<MAX_USER_PROCESSES;i++)if(pcbs[i].inUse&&pcbs[i].state==State::READY){pcbs[i].waitTicks++;uint32_t b=pcbs[i].waitTicks/20;if(b>pcbs[i].priority)b=pcbs[i].priority;pcbs[i].effectivePriority=pcbs[i].priority-b;}save(run,r);wake();if(quantumLeft)quantumLeft--;if(quantumLeft==0)choose(r);return true;}
int32_t execCurrent(Interrupts::Registers*r,const char*name){if(!run||!name)return ERR_INVALID_ARGUMENT;void(*entry)()=nullptr;if(KLib::strcmp(name,"init")==0||KLib::strcmp(name,"echo")==0)entry=user_app_init;else if(KLib::strcmp(name,"pipe_test")==0)entry=user_app_pipe;else if(KLib::strcmp(name,"msg_sender")==0)entry=user_app_msg_sender;else if(KLib::strcmp(name,"msg_receiver")==0)entry=user_app_msg_receiver;else if(KLib::strcmp(name,"scheduler_test")==0)entry=user_app_scheduler;else if(KLib::strcmp(name,"permission_test")==0)entry=user_app_permissions;else return ERR_NOT_FOUND;uint32_t idx=(uint32_t)(run-pcbs);for(uint32_t i=0;i<4096;i++)stacks[idx][i]=0;mapCode();r->eax=SUCCESS;r->ebx=r->ecx=r->edx=r->esi=r->edi=r->ebp=0;r->eip=(uint32_t)entry;r->cs=GDT::USER_CODE;r->eflags=0x202;r->useresp=Paging::USER_STACK_TOP;r->ss=GDT::USER_DATA;r->ds=GDT::USER_DATA;return SUCCESS;}
int32_t forkCurrent(Interrupts::Registers*r){if(!run)return ERR_PERMISSION;PCB*c=slot();if(!c)return ERR_NO_MEMORY;uint32_t idx=(uint32_t)(c-pcbs);for(uint32_t i=0;i<4096;i++)stacks[idx][i]=((uint8_t*)Paging::USER_STACK_PAGE)[i];save(run,r);/*freshen run->frame with the LIVE syscall-time registers BEFORE copying it into the child - doing this after the copy (as before) left the child's frame holding whatever stale/zeroed frame the parent had from its last save, which for a process that had never yet been preempted meant EIP=0: the child resumed by jumping to address 0 and instantly page-faulted*/*c=*run;c->inUse=true;c->pid=nextPid++;c->ppid=run->pid;c->state=State::READY;c->waitTicks=0;c->effectivePriority=c->priority;c->userStackPhysical=(uint32_t)&stacks[idx][0];c->kernelStackPhysical=(uint32_t)&kernelStacks[idx][0];c->frame.eax=0;c->contextSwitches=0;
 // fork() duplicates the fd table (the *c=*run above already copied it
 // byte-for-byte), but a pipe's reader/writer refcount was only ever 1
 // at creation - close() decrements it unconditionally, so without
 // this, whichever of parent/child closed "their" unused end first
 // would zero that count out from under the other one, which still
 // held its own valid copy of the fd for the end it actually needed.
 // That's exactly the pipe_test hang this fixes: the child's first
 // close(writeEnd) zeroed `writers` before the parent ever got to
 // write, so pipe_write() saw readers==0 too (from the parent's own
 // close(readEnd)) and failed silently, and the child's read loop
 // then spun in u_yield() forever waiting for data that was never
 // written.
 for(int i=0;i<8;i++)if(c->fds[i].used&&c->fds[i].type==1)IPC::pipe_dup(c->fds[i].object,(c->fds[i].flags&2)!=0);
 r->eax=c->pid;return c->pid;}
static bool fdValid(uint32_t fd){return run&&fd<8&&run->fds[fd].used;}
int32_t open(const char*path,uint32_t flags){if(!run||!path)return ERR_INVALID_ARGUMENT;int32_t fd=-1;for(int i=3;i<8;i++)if(!run->fds[i].used){fd=i;break;}if(fd<0)return ERR_NO_MEMORY;uint32_t u,g;uint16_t m;if(!FS::FileSystem::stat(path,&u,&g,&m)){if(flags&4){if(!FS::FileSystem::createFile(path))return ERR_NOT_FOUND;}else return ERR_NOT_FOUND;}if((flags&1)&&!Permissions::check(run->uid,run->gid,u,g,m,4))return ERR_PERMISSION;if((flags&2)&&!Permissions::check(run->uid,run->gid,u,g,m,2))return ERR_PERMISSION;run->fds[fd].used=true;run->fds[fd].flags=flags;run->fds[fd].offset=0;cp(run->fds[fd].path,path,64);return fd;}
int32_t close(uint32_t fd){if(fd<3)return SUCCESS;if(!fdValid(fd))return ERR_INVALID_FD;if(run->fds[fd].type==1)IPC::pipe_close(run->fds[fd].object,(run->fds[fd].flags&2)!=0);run->fds[fd].used=false;return SUCCESS;}
int32_t read(uint32_t fd,char*buf,uint32_t len){if(!run||!buf)return ERR_INVALID_ARGUMENT;if(fd==0){for(uint32_t i=0;i<len;i++){char c=Keyboard::get_char();buf[i]=c;if(c=='\n')return i+1;}return len;}if(!fdValid(fd)||(run->fds[fd].flags&1)==0)return ERR_INVALID_FD;if(run->fds[fd].type==1)return IPC::pipe_read(run->fds[fd].object,buf,len);char tmp[8192];if(!FS::FileSystem::readFile(run->fds[fd].path,tmp,sizeof(tmp)))return ERR_PERMISSION;uint32_t off=run->fds[fd].offset,n=0;while(tmp[off+n]&&n<len)n++;for(uint32_t i=0;i<n;i++)buf[i]=tmp[off+i];run->fds[fd].offset+=n;return n;}
int32_t setPriority(uint32_t pid,uint32_t priority){if(priority>10)priority=10;for(uint32_t i=0;i<MAX_USER_PROCESSES;i++)if(pcbs[i].inUse&&pcbs[i].pid==pid){if(run&&run->uid!=0&&run->pid!=pid)return ERR_PERMISSION;pcbs[i].priority=priority;return SUCCESS;}return ERR_INVALID_PID;}
int32_t pipeCreate(uint32_t*readFd,uint32_t*writeFd){if(!run||!readFd||!writeFd)return ERR_INVALID_ARGUMENT;uint32_t q=0,r=0;if(IPC::pipe_create(&q,&r)<0)return ERR_NO_MEMORY;int rf=-1,wf=-1;for(int i=3;i<8;i++)if(!run->fds[i].used){if(rf<0)rf=i;else{wf=i;break;}}if(wf<0)return ERR_NO_MEMORY;run->fds[rf]={true,1,0,1,q,{0}};run->fds[wf]={true,2,0,1,q,{0}};*readFd=rf;*writeFd=wf;return SUCCESS;}
int32_t write(uint32_t fd,const char*buf,uint32_t len){if(!run||!buf)return ERR_INVALID_ARGUMENT;if(fd==1||fd==2){for(uint32_t i=0;i<len;i++){char x[2]={buf[i],0};kprint(x);}return len;}if(!fdValid(fd)||(run->fds[fd].flags&2)==0)return ERR_INVALID_FD;if(run->fds[fd].type==1)return IPC::pipe_write(run->fds[fd].object,buf,len);static char tmp[8192];uint32_t n=len<8191?len:8191;for(uint32_t i=0;i<n;i++)tmp[i]=buf[i];tmp[n]=0;return FS::FileSystem::writeFile(run->fds[fd].path,tmp)?(int32_t)n:ERR_PERMISSION;}
}
