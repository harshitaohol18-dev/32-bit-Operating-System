#pragma once
#include <stdint.h>
#include "pcb.hpp"
namespace Process {
void initialize();
int32_t create_process(const char* name, void(*entry)(), uint32_t priority);
int32_t terminate_process(uint32_t pid, uint32_t status);
int32_t kill_process(uint32_t pid);
int32_t wait_process(uint32_t pid);
PCB* get_process(uint32_t pid);
PCB* get_current_process();
bool start(const char* name,uint32_t priority);
bool handleTimer(Interrupts::Registers* regs);
void yield(Interrupts::Registers* regs);
void sleep(Interrupts::Registers* regs,uint32_t ticks);
void exitCurrent(Interrupts::Registers* regs,uint32_t status);
int32_t forkCurrent(Interrupts::Registers* regs);
int32_t execCurrent(Interrupts::Registers* regs,const char* name);
PCB* current();
bool isUserRunning();
int32_t open(const char*path,uint32_t flags);
int32_t close(uint32_t fd);
int32_t read(uint32_t fd,char*buf,uint32_t len);
int32_t write(uint32_t fd,const char*buf,uint32_t len);
int32_t pipeCreate(uint32_t*readFd,uint32_t*writeFd);
int32_t setPriority(uint32_t pid,uint32_t priority);
}
