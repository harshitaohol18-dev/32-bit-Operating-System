#include "drivers/vga.hpp"
#include "drivers/keyboard.hpp"
#include "drivers/timer.hpp"
#include "arch/x86/gdt.hpp"
#include "arch/x86/idt.hpp"
#include "arch/x86/interrupts.hpp"
#include "arch/x86/paging.hpp"
#include "arch/x86/tss.hpp"
#include "mm/heap.hpp"
#include "scheduler/scheduler.hpp"
#include "syscall/syscall.hpp"
#include "filesystem/filesystem.hpp"
#include "shell/shell.hpp"
#include "user/user.hpp"
#include "process/process.hpp"
#include "libc/kstd.hpp"
#include "demo/demo.hpp"
static void idleTask(){while(1)asm volatile("sti;hlt");}
static void demoTaskA(){while(1){if(Demo::isVerbose())Syscall::write("[demo] Round-robin/priority kernel task\n");Syscall::sleep(100);}}
static void demoTaskB(){while(1){if(Demo::isVerbose())Syscall::write("[demo2] kernel scheduler task\n");Syscall::sleep(150);}}
extern "C" void kernel_main(){
 VGA::init();VGA::set_color(VGA::LIGHT_GREEN,VGA::BLACK);VGA::print("========================================\n32-BIT EDUCATIONAL x86 OS\n========================================\n");VGA::set_color(VGA::WHITE,VGA::BLACK);
 GDT::initialize();TSS::initialize();IDT::initialize();Interrupts::initialize();Syscall::initialize();
 Heap::initialize();Paging::initialize();Timer::init(100);Keyboard::init();Scheduler::initialize();Process::initialize();
 FS::FileSystem::initialize();
 // Preserve the original persistence demonstration while adding a user-owned home.
 FS::FileSystem::createDirectory("/home");
 FS::FileSystem::createDirectory("/home/user");
 FS::FileSystem::chown("/home/user",1000,1000);
 uint32_t wu,wg; uint16_t wm;
 if(!FS::FileSystem::stat("/welcome.txt",&wu,&wg,&wm) && FS::FileSystem::createFile("/welcome.txt"))FS::FileSystem::writeFile("/welcome.txt","Welcome to FinalOS. This file is stored on the persistent ATA disk image.");
 User::initialize();
 VGA::print("\nDefault educational accounts: root/root and user/user\n");
 while(!User::loginPrompt()){VGA::print("Login required. Please try again.\n");}
 VGA::print("Session UID ");VGA::print_dec(User::get_current_user()->uid);VGA::print("\n");
 Scheduler::createTask("idle",idleTask,10);
 Scheduler::createTask("demo-A",demoTaskA,8);
 Scheduler::createTask("demo-B",demoTaskB,9);
 Scheduler::createTask("shell",Shell::run,5);
 VGA::print("\nSYSTEM READY. Type 'help'.\n");
 asm volatile("sti");while(1)asm volatile("hlt");
}
