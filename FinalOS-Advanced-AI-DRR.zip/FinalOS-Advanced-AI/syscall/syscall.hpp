#pragma once
#include <stdint.h>
namespace Syscall {
enum Number:uint32_t{
SYS_EXIT=1,SYS_READ=2,SYS_WRITE=3,SYS_OPEN=4,SYS_CLOSE=5,SYS_FORK=6,SYS_EXEC=7,SYS_WAIT=8,
SYS_GETPID=9,SYS_GETUID=10,SYS_PIPE=11,SYS_MSG_CREATE=12,SYS_MSG_SEND=13,SYS_MSG_RECEIVE=14,
SYS_MSG_DESTROY=15,SYS_SET_PRIORITY=16,SYS_GET_PRIORITY=17,SYS_YIELD=18,SYS_SLEEP=19,SYS_GET_PROCESS_INFO=20
};
struct ProcessInfo{uint32_t pid,ppid,uid,gid,state,priority,cpuTicks,contextSwitches;};
void initialize();
int32_t invoke(uint32_t n,uint32_t a=0,uint32_t b=0,uint32_t c=0);
inline int32_t write(const char*s){uint32_t n=0;while(s&&s[n])n++;return invoke(SYS_WRITE,1,(uint32_t)s,n);}
inline int32_t writefd(uint32_t fd,const char*s,uint32_t n){return invoke(SYS_WRITE,fd,(uint32_t)s,n);}
inline int32_t sleep(uint32_t t){return invoke(SYS_SLEEP,t);}
inline int32_t exitTask(){return invoke(SYS_EXIT);}
inline uint32_t getPid(){return (uint32_t)invoke(SYS_GETPID);}
inline uint32_t getUid(){return (uint32_t)invoke(SYS_GETUID);}
inline int32_t yieldTask(){return invoke(SYS_YIELD);}
}
