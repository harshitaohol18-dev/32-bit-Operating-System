#include "syscall.hpp"
#include "errors.hpp"
#include "../arch/x86/idt.hpp"
#include "../arch/x86/gdt.hpp"
#include "../arch/x86/interrupts.hpp"
#include "../arch/x86/paging.hpp"
#include "../scheduler/scheduler.hpp"
#include "../user/user.hpp"
#include "../process/process.hpp"
#include "../ipc/message_queue.hpp"
#include "../libc/kstd.hpp"
extern "C" void kprint(const char*);extern "C" void isr128();
namespace Syscall {
static bool fromUser(Interrupts::Registers*r){return (r->cs&3)==3;}
static bool ptr(Interrupts::Registers*r,uint32_t p,uint32_t n,bool w){return !fromUser(r)||Paging::isUserAccessible(p,n,w);}
static bool userStr(Interrupts::Registers*r,uint32_t p,char*out,uint32_t cap){if(!p||!ptr(r,p,1,false))return false;uint32_t n=0;while(n<cap-1){if(!ptr(r,p+n,1,false))return false;char c=((const char*)p)[n];out[n++]=c;if(!c)return true;}out[cap-1]=0;return false;}
static void dispatch(Interrupts::Registers*r){
 bool u=fromUser(r);
 switch(r->eax){
 case SYS_WRITE:{uint32_t fd=r->ebx,p=r->ecx,n=r->edx;if(n>8191||!ptr(r,p,n,false)){r->eax=ERR_INVALID_ARGUMENT;break;}if(u)r->eax=Process::write(fd,(const char*)p,n);else{kprint((const char*)p);r->eax=n;}break;}
 case SYS_READ:{uint32_t fd=r->ebx,p=r->ecx,n=r->edx;if(n>8191||!ptr(r,p,n,true)){r->eax=ERR_INVALID_ARGUMENT;break;}r->eax=u?Process::read(fd,(char*)p,n):ERR_NOT_IMPLEMENTED;break;}
 case SYS_OPEN:{char path[128];if(!userStr(r,r->ebx,path,sizeof(path))){r->eax=ERR_INVALID_ARGUMENT;break;}r->eax=u?Process::open(path,r->ecx):ERR_NOT_IMPLEMENTED;break;}
 case SYS_CLOSE:r->eax=u?Process::close(r->ebx):SUCCESS;break;
 case SYS_FORK:r->eax=u?Process::forkCurrent(r):ERR_PERMISSION;break;
 case SYS_EXEC:{char path[64];if(!u||!userStr(r,r->ebx,path,sizeof(path))){r->eax=ERR_INVALID_ARGUMENT;break;}r->eax=Process::execCurrent(r,path);break;}
 case SYS_WAIT:r->eax=ERR_NOT_IMPLEMENTED;break;
 case SYS_GETPID:{if(u){Process::PCB*p=Process::current();r->eax=p?p->pid:0;}else{Scheduler::Task*t=Scheduler::currentTask();r->eax=t?t->pid:0;}break;}
 case SYS_GETUID:{if(u){Process::PCB*p=Process::current();r->eax=p?p->uid:0;}else{User::UserAccount* x=User::get_current_user();r->eax=x?x->uid:0;}break;}
 case SYS_PIPE:{if(!u||!ptr(r,r->ebx,8,true)){r->eax=ERR_INVALID_ARGUMENT;break;}uint32_t fds[2];r->eax=Process::pipeCreate(&fds[0],&fds[1]);if(r->eax==0){((uint32_t*)r->ebx)[0]=fds[0];((uint32_t*)r->ebx)[1]=fds[1];}break;}
 case SYS_MSG_CREATE:r->eax=IPC::msg_queue_create(u?(Process::current()?Process::current()->uid:0):0,r->ebx);break;
 case SYS_MSG_SEND:{uint32_t p=r->ecx,n=r->edx;if(n>IPC::MAX_MESSAGE_SIZE||!ptr(r,p,n,false)){r->eax=ERR_INVALID_ARGUMENT;break;}r->eax=IPC::msg_send(r->ebx,(const char*)p,n,u?Process::current()->uid:0);break;}
 case SYS_MSG_RECEIVE:{uint32_t p=r->ecx,n=r->edx;if(n>IPC::MAX_MESSAGE_SIZE+1||!ptr(r,p,n,true)){r->eax=ERR_INVALID_ARGUMENT;break;}r->eax=IPC::msg_receive(r->ebx,(char*)p,n,u?Process::current()->uid:0);break;}
 case SYS_MSG_DESTROY:r->eax=IPC::msg_queue_destroy(r->ebx,u?Process::current()->uid:0);break;
 case SYS_SET_PRIORITY:{uint32_t pid=r->ebx,p=r->ecx;if(u){Process::PCB*x=Process::current();if(!x||(pid!=x->pid&&x->uid!=0)){r->eax=ERR_PERMISSION;break;}r->eax=Process::setPriority(pid,p);}else{Scheduler::setPriority(pid,p);r->eax=SUCCESS;}break;}
 case SYS_GET_PRIORITY:{if(u){Process::PCB*x=Process::current();r->eax=(x&&x->pid==r->ebx)?(uint32_t)x->priority:(uint32_t)ERR_INVALID_PID;}else r->eax=Scheduler::getPriority(r->ebx);break;}
 case SYS_YIELD:if(u)Process::yield(r);else{Scheduler::yield();r->eax=SUCCESS;}break;
 case SYS_SLEEP:if(u)Process::sleep(r,r->ebx);else{Scheduler::sleep(r->ebx);r->eax=SUCCESS;}break;
 case SYS_GET_PROCESS_INFO:{if(!u||!ptr(r,r->ebx,sizeof(ProcessInfo),true)){r->eax=ERR_INVALID_ARGUMENT;break;}Process::PCB*p=Process::current();if(!p){r->eax=ERR_INVALID_PID;break;}ProcessInfo x{p->pid,p->ppid,p->uid,p->gid,(uint32_t)p->state,p->priority,p->cpuTicks,p->contextSwitches};*(ProcessInfo*)r->ebx=x;r->eax=SUCCESS;break;}
 case SYS_EXIT:if(u){Process::exitCurrent(r,r->ebx);return;}else Scheduler::terminateCurrentAndSchedule(r->ebx);break;
 default:r->eax=ERR_INVALID_ARGUMENT;break;
 }}
extern "C" void syscall_common_handler(Interrupts::Registers*r){dispatch(r);}
void initialize(){IDT::setGate(0x80,(uint32_t)isr128,GDT::KERNEL_CODE,IDT::INTERRUPT_GATE_RING3);kprint("[SYSCALL] int 0x80 ABI installed (Ring 3 DPL=3)\n");}
int32_t invoke(uint32_t n,uint32_t a,uint32_t b,uint32_t c){int32_t ret;asm volatile("int $0x80":"=a"(ret):"a"(n),"b"(a),"c"(b),"d"(c):"memory");return ret;}
}
