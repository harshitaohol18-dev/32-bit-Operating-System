; syscall_isr.asm - stub for the software interrupt vector 0x80 (128),
; used as the `int 0x80` syscall gate. Same register-save convention
; as isr.asm/irq.asm so it can share the Interrupts::Registers layout.
[bits 32]
section .text

extern syscall_common_handler
global isr128

isr128:
    cli
    push dword 0        ; dummy error code
    push dword 128       ; interrupt number
    pusha

    mov ax, ds
    push eax

    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    push esp
    call syscall_common_handler
    add esp, 4

    pop eax
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    popa
    add esp, 8
    sti
    iret
