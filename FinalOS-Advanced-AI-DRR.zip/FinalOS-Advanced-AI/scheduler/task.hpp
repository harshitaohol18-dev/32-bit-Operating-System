#pragma once
#include <stdint.h>
namespace Scheduler {
enum class TaskState{NEW,READY,RUNNING,BLOCKED,TERMINATED};
// TASK_STACK_SIZE was 8192 (8KB). That's dangerously thin for a ring-0
// task stack in this kernel: hardware IRQs (e.g. the timer) preempt
// straight onto whichever stack is currently active with no separate
// interrupt stack (TSS.esp0 is only used for ring3->ring0 transitions),
// so every tick adds a frame on top of whatever the task was doing, and
// deep call chains (shell command -> filesystem call -> savePerms/
// saveMetadata -> disk I/O) stack further frames on top of that. See
// README "Real bugs found and fixed" for the chmod/chown crash this
// caused. Widened to give real headroom beyond any single call chain.
constexpr uint32_t TASK_STACK_SIZE=16384,MAX_TASKS=32,NAME_LEN=32,MAX_FDS=16;
struct FileDescriptor{bool used;uint32_t entry;uint32_t flags;uint32_t offset;};
struct Task{
 uint32_t pid,ppid,uid,gid;char name[NAME_LEN];uint32_t priority,effectivePriority,waitTicks,wakeTick;
 TaskState state;uint32_t esp,ebp;uint32_t creationTick,startTick,cpuTicks,contextSwitches,exitStatus;
 uint32_t kernelStack,userStack;char cwd[64];FileDescriptor fds[MAX_FDS];
 bool inUse,isUser;
 uint32_t readyTicks,burstRun,firstRunTick,lastWait,drrFlags,drrBase,drrRunnable,drrPrio,drrDispatches,drrQuantumSum; bool hasRun; uint8_t drrCls; // measured/decision state (see ai/dynamic_rr.hpp)
 uint32_t aiQuantum; // last quantum handed out by the AI-Adaptive scheduler (0 if never)
 uint8_t stack[TASK_STACK_SIZE];
};
}
