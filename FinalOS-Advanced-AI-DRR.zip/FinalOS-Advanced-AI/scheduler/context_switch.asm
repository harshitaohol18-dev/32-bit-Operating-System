; context_switch.asm - switches the CPU's stack from one task to another.
;
; This is a plain function call/return switch (not iret-based). It
; works because the four callee-saved registers (ebp, ebx, esi, edi)
; plus a return address get pushed onto whichever stack is CURRENTLY
; active - and since every task always runs on its own private stack,
; that save always lands on the correct task's memory. A brand-new
; task's stack is pre-built by Scheduler::createTask() to look exactly
; like a task that has already been "saved" this way.
[bits 32]
section .text
global context_switch

; void context_switch(uint32_t* oldEspStore, uint32_t newEsp)
context_switch:
    push ebp
    push ebx
    push esi
    push edi

    mov eax, [esp+20]     ; arg1: oldEspStore (4 pushes + return addr = 20)
    mov [eax], esp

    mov eax, [esp+24]     ; arg2: newEsp
    mov esp, eax           ; <-- the actual switch

    pop edi
    pop esi
    pop ebx
    pop ebp
    ret                     ; returns into the new task (or its trampoline)

; First-ever switch into a newly created task lands here.
; Scheduler::createTask() places the task's real entry point just
; above this label's "return address" slot on the new stack.
extern task_exit
global task_trampoline
task_trampoline:
    pop eax        ; task's real entry point
    sti             ; new task starts with interrupts enabled
    call eax
    call task_exit  ; entry function returned -> clean up, never returns
.hang:
    hlt
    jmp .hang
