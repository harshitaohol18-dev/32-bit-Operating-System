#pragma once
#include "task.hpp"
namespace Scheduler {
enum class Mode{ROUND_ROBIN,PRIORITY,FCFS,AI_ADAPTIVE};
void initialize();
Task* createTask(const char* name,void(*entryPoint)(),uint32_t priority);
void removeTask(uint32_t pid);
void terminateCurrentAndSchedule(uint32_t status=0);
void tick();void schedule();void sleep(uint32_t ticks);void yield();
Task* currentTask();Task* getTaskSlot(uint32_t index);
void setMode(Mode mode);Mode getMode();const char* getModeName();
void scheduler_set_mode(Mode mode);Mode scheduler_get_mode();
void setQuantum(uint32_t ticks);uint32_t getQuantum();
void setPriority(uint32_t pid,uint32_t priority);int32_t getPriority(uint32_t pid);
uint32_t getActiveCount();uint32_t getTotalCreated();uint32_t getTotalContextSwitches();
const char* classifyTaskWorkload(Task* t); // AI-Adaptive mode: live classification for display
uint32_t getSystemTicks();uint32_t getDrrDecisions();void resetDrrStats(); // real kernel counters for Dynamic RR
}
