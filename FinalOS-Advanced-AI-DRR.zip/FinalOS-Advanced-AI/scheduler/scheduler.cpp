#include "scheduler.hpp"
#include "../user/user.hpp"
#include "../ai/classifier.hpp"
#include "../ai/adaptive_quantum.hpp"
#include "../ai/dynamic_rr.hpp"
extern "C" void kprint(const char*);extern "C" void context_switch(uint32_t*,uint32_t);extern "C" void task_trampoline();
namespace Scheduler {
static Task tasks[MAX_TASKS];static Task*running=nullptr;static uint32_t nextPid=1,totalCreated=0,totalContextSwitches=0;
static Mode currentMode=Mode::ROUND_ROBIN;static const uint32_t AGING_INTERVAL=20,AGING_CAP=10;static uint32_t timeSlice=5,quantumRemaining=0,rrLastIndex=0,systemTicks=0;
static void copyName(Task*t,const char*n){uint32_t i=0;for(;i<NAME_LEN-1&&n&&n[i];i++)t->name[i]=n[i];t->name[i]=0;}
void initialize(){for(uint32_t i=0;i<MAX_TASKS;i++){tasks[i].inUse=false;tasks[i].state=TaskState::TERMINATED;}running=nullptr;quantumRemaining=timeSlice;kprint("[SCHED] Initialized (RR, priority, FCFS, AI-Adaptive)\n");}
Task* allocateSlot(){for(uint32_t i=0;i<MAX_TASKS;i++)if(!tasks[i].inUse)return &tasks[i];return nullptr;}
Task* createTask(const char*n,void(*entry)(),uint32_t prio){Task*t=allocateSlot();if(!t)return nullptr;t->pid=nextPid++;t->ppid=running?running->pid:0;User::UserAccount*u=User::get_current_user();t->uid=u?u->uid:0;t->gid=u?u->gid:0;copyName(t,n);t->priority=prio>10?10:prio;t->effectivePriority=t->priority;t->waitTicks=0;t->wakeTick=0;t->state=TaskState::READY;t->inUse=true;t->isUser=false;t->creationTick=systemTicks;t->startTick=0;t->cpuTicks=0;t->contextSwitches=0;t->exitStatus=0;t->kernelStack=(uint32_t)(t->stack+TASK_STACK_SIZE);t->userStack=0;t->aiQuantum=0;t->readyTicks=0;t->burstRun=0;t->firstRunTick=0;t->lastWait=0;t->drrFlags=0;t->drrBase=0;t->drrRunnable=0;t->drrPrio=0;t->drrDispatches=0;t->drrQuantumSum=0;t->hasRun=false;t->drrCls=0;for(uint32_t i=0;i<MAX_FDS;i++)t->fds[i]={false,0,0,0};t->cwd[0]='/';t->cwd[1]=0;
 uint32_t*sp=(uint32_t*)(t->stack+TASK_STACK_SIZE);*(--sp)=(uint32_t)entry;*(--sp)=(uint32_t)task_trampoline;*(--sp)=0;*(--sp)=0;*(--sp)=0;*(--sp)=0;t->esp=(uint32_t)sp;t->ebp=0;totalCreated++;return t;}
void removeTask(uint32_t pid){for(uint32_t i=0;i<MAX_TASKS;i++)if(tasks[i].inUse&&tasks[i].pid==pid){tasks[i].state=TaskState::TERMINATED;tasks[i].inUse=false;if(running==&tasks[i])running=nullptr;return;}}
void terminateCurrentAndSchedule(uint32_t status){if(!running)return;uint32_t p=running->pid;running->exitStatus=status;removeTask(p);schedule();while(1)asm volatile("hlt");}
Task* currentTask(){return running;}Task* getTaskSlot(uint32_t i){return i<MAX_TASKS?&tasks[i]:nullptr;}
uint32_t getActiveCount(){uint32_t n=0;for(uint32_t i=0;i<MAX_TASKS;i++)if(tasks[i].inUse&&tasks[i].state!=TaskState::TERMINATED)n++;return n;}
uint32_t getTotalCreated(){return totalCreated;}uint32_t getTotalContextSwitches(){return totalContextSwitches;}
void setMode(Mode m){currentMode=m;quantumRemaining=timeSlice;}
Mode getMode(){return currentMode;}void scheduler_set_mode(Mode m){setMode(m);}Mode scheduler_get_mode(){return getMode();}const char*getModeName(){return currentMode==Mode::ROUND_ROBIN?"Round Robin":currentMode==Mode::PRIORITY?"Priority (aging)":currentMode==Mode::AI_ADAPTIVE?"AI-Adaptive (RR + workload classifier)":"FCFS";}
void setQuantum(uint32_t n){if(n&&n<=1000)timeSlice=n;}uint32_t getQuantum(){return timeSlice;}
static Task* rr(){for(uint32_t s=1;s<=MAX_TASKS;s++){uint32_t i=(rrLastIndex+s)%MAX_TASKS;if(tasks[i].inUse&&tasks[i].state==TaskState::READY){rrLastIndex=i;return &tasks[i];}}return nullptr;}
static Task* priority(){Task*b=nullptr;for(uint32_t i=0;i<MAX_TASKS;i++){Task*t=&tasks[i];if(!t->inUse||t->state!=TaskState::READY)continue;if(!b||t->effectivePriority<b->effectivePriority||(t->effectivePriority==b->effectivePriority&&t->pid<b->pid))b=t;}return b;}
static Task* fcfs(){Task*b=nullptr;for(uint32_t i=0;i<MAX_TASKS;i++){Task*t=&tasks[i];if(!t->inUse||t->state!=TaskState::READY)continue;if(!b||t->creationTick<b->creationTick||(t->creationTick==b->creationTick&&t->pid<b->pid))b=t;}return b;}
static Task* next(){if(currentMode==Mode::ROUND_ROBIN||currentMode==Mode::AI_ADAPTIVE)return rr();return currentMode==Mode::PRIORITY?priority():fcfs();}
// Average observed CPU burst per turn so far - stands in for the
// trained tree's "CPU_time" feature (see ai/classifier.hpp).
static uint32_t drrDecisions=0;
static uint32_t runnableCount(){uint32_t n=0;for(uint32_t i=0;i<MAX_TASKS;i++)if(tasks[i].inUse&&(tasks[i].state==TaskState::READY||tasks[i].state==TaskState::RUNNING))n++;return n;}
static uint32_t avgBurst(Task*t){return t->contextSwitches?t->cpuTicks/t->contextSwitches:t->cpuTicks;}
const char* classifyTaskWorkload(Task*t){if(!t)return "n/a";return AI::workloadName(AI::classify(t->burstRun?t->burstRun:avgBurst(t),t->waitTicks,t->priority,runnableCount()));}
static void aging(){if(currentMode!=Mode::PRIORITY)return;for(uint32_t i=0;i<MAX_TASKS;i++){Task*t=&tasks[i];if(!t->inUse||t->state!=TaskState::READY)continue;t->waitTicks++;uint32_t bonus=t->waitTicks/AGING_INTERVAL;if(bonus>AGING_CAP)bonus=AGING_CAP;t->effectivePriority=(t->priority>bonus)?t->priority-bonus:0;}}
static void wake(){for(uint32_t i=0;i<MAX_TASKS;i++){Task*t=&tasks[i];if(t->inUse&&t->state==TaskState::BLOCKED&&t->wakeTick&&systemTicks>=t->wakeTick){t->state=TaskState::READY;t->waitTicks=0;t->effectivePriority=t->priority;t->wakeTick=0;}}}
void schedule(){Task*n=next();if(!n)return;if(n==running&&running->state==TaskState::RUNNING)return;Task*p=running;if(p&&p->state==TaskState::RUNNING){p->state=TaskState::READY;p->waitTicks=0;p->effectivePriority=p->priority;}uint32_t waited=n->waitTicks;n->lastWait=waited;if(!n->hasRun){n->hasRun=true;n->firstRunTick=systemTicks;}n->state=TaskState::RUNNING;n->waitTicks=0;n->effectivePriority=n->priority;n->contextSwitches++;n->startTick=systemTicks;if(currentMode==Mode::AI_ADAPTIVE){AI::DrrInput in{n->burstRun,waited,n->priority,runnableCount()};AI::DrrDecision d=AI::drrDecide(in);n->aiQuantum=d.quantum;n->drrFlags=d.flags;n->drrBase=d.baseQuantum;n->drrCls=(uint8_t)d.cls;n->drrRunnable=in.runnable;n->drrPrio=in.priority;n->drrDispatches++;n->drrQuantumSum+=d.quantum;drrDecisions++;quantumRemaining=n->aiQuantum;}else{quantumRemaining=timeSlice;}static uint32_t dummy;uint32_t*old=p&&p->inUse?&p->esp:&dummy;uint32_t ne=n->esp;running=n;totalContextSwitches++;context_switch(old,ne);}
void yield(){schedule();}
void sleep(uint32_t ticks){if(!running)return;if(ticks==0){yield();return;}running->burstRun=0;running->state=TaskState::BLOCKED;running->wakeTick=systemTicks+ticks;schedule();}
void setPriority(uint32_t pid,uint32_t p){if(p>10)p=10;for(uint32_t i=0;i<MAX_TASKS;i++)if(tasks[i].inUse&&tasks[i].pid==pid){tasks[i].priority=p;tasks[i].effectivePriority=p;tasks[i].waitTicks=0;return;}}
int32_t getPriority(uint32_t pid){for(uint32_t i=0;i<MAX_TASKS;i++)if(tasks[i].inUse&&tasks[i].pid==pid)return tasks[i].priority;return -1;}
extern "C" void task_exit(){terminateCurrentAndSchedule(0);}
void tick(){systemTicks++;if(running){running->cpuTicks++;running->burstRun++;}for(uint32_t i=0;i<MAX_TASKS;i++){Task*t=&tasks[i];if(t->inUse&&t->state==TaskState::READY){t->readyTicks++;if(currentMode==Mode::AI_ADAPTIVE)t->waitTicks++;}}wake();aging();if(!running||running->state!=TaskState::RUNNING){schedule();return;}if(currentMode==Mode::PRIORITY){Task*b=priority();if(b&&b->effectivePriority<running->priority){schedule();return;}}if(quantumRemaining)quantumRemaining--;if(quantumRemaining==0)schedule();}
uint32_t getSystemTicks(){return systemTicks;}uint32_t getDrrDecisions(){return drrDecisions;}void resetDrrStats(){drrDecisions=0;for(uint32_t i=0;i<MAX_TASKS;i++)if(tasks[i].inUse){tasks[i].drrDispatches=0;tasks[i].drrQuantumSum=0;}}
}
