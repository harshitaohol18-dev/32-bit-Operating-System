#pragma once
// directory.hpp
// A "directory" is just a FileEntry of type DIRECTORY; its children
// are found by scanning the whole entry table for parent == this
// entry's index (flat metadata table, see filesystem.cpp). This file
// exists mainly to document that relationship and give directory
// helpers a home separate from file.hpp.

#include "file.hpp"

namespace FS {

    // Index of the root directory's entry in the metadata table.
    constexpr uint32_t ROOT_ENTRY_INDEX = 0;
}
