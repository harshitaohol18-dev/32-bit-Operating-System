#include "filesystem.hpp"
#include "disk.hpp"
#include "../user/user.hpp"
#include "../user/permissions.hpp"
#include "../scheduler/scheduler.hpp"
#include <stdint.h>
extern "C" void kprint(const char*); extern "C" void kprintDec(uint32_t);

namespace FS {
static uint32_t kstrlen(const char*s){uint32_t n=0;if(!s)return 0;while(s[n])n++;return n;}
static bool kstreq(const char*a,const char*b){if(!a||!b)return false;while(*a&&*b){if(*a!=*b)return false;a++;b++;}return *a==*b;}
static void kstrcpy(char*d,const char*s,uint32_t n){if(!n)return;uint32_t i=0;for(;i<n-1&&s&&s[i];i++)d[i]=s[i];d[i]=0;}
static void kmemset(void*d,uint8_t v,uint32_t n){uint8_t*p=(uint8_t*)d;for(uint32_t i=0;i<n;i++)p[i]=v;}
static void kmemcpy(void*d,const void*s,uint32_t n){uint8_t*a=(uint8_t*)d;const uint8_t*b=(const uint8_t*)s;for(uint32_t i=0;i<n;i++)a[i]=b[i];}
static SuperBlock sb; static FileEntry entries[MAX_ENTRIES]; static uint8_t bitmap[Disk::SECTOR_SIZE];
static const uint32_t METADATA_START_LBA=2;
static const uint32_t ENTRIES_PER_SECTOR=Disk::SECTOR_SIZE/sizeof(FileEntry);
static const uint32_t METADATA_SECTORS=(MAX_ENTRIES*sizeof(FileEntry)+Disk::SECTOR_SIZE-1)/Disk::SECTOR_SIZE;
static const uint32_t DATA_START_LBA=METADATA_START_LBA+METADATA_SECTORS;
static const uint32_t PERM_MAGIC=0x5045524d, PERM_START_LBA=32763, PERM_SECTORS=4;
struct PermissionRecord{uint32_t magic;uint32_t uid;uint32_t gid;uint16_t mode;uint16_t reserved;} __attribute__((packed));
static PermissionRecord perms[MAX_ENTRIES];
static void savePerms();

static uint32_t uid(){User::UserAccount*u=User::get_current_user();return u?u->uid:0;}
static uint32_t gid(){User::UserAccount*u=User::get_current_user();return u?u->gid:0;}
static void loadMetadata(){uint8_t sec[512];uint32_t n=0;for(uint32_t s=0;s<METADATA_SECTORS;s++){Disk::readSector(METADATA_START_LBA+s,sec);for(uint32_t e=0;e<ENTRIES_PER_SECTOR&&n<MAX_ENTRIES;e++,n++)kmemcpy(&entries[n],sec+e*sizeof(FileEntry),sizeof(FileEntry));}}
static void saveMetadata(){uint8_t sec[512];uint32_t n=0;for(uint32_t s=0;s<METADATA_SECTORS;s++){kmemset(sec,0,512);for(uint32_t e=0;e<ENTRIES_PER_SECTOR&&n<MAX_ENTRIES;e++,n++)kmemcpy(sec+e*sizeof(FileEntry),&entries[n],sizeof(FileEntry));Disk::writeSector(METADATA_START_LBA+s,sec);}}
static void loadBitmap(){Disk::readSector(1,bitmap);} static void saveBitmap(){Disk::writeSector(1,bitmap);}
static void loadSB(){uint8_t sec[512];Disk::readSector(0,sec);kmemcpy(&sb,sec,sizeof(sb));}
static void saveSB(){uint8_t sec[512];kmemset(sec,0,512);kmemcpy(sec,&sb,sizeof(sb));Disk::writeSector(0,sec);}
static void loadPerms(){uint8_t sec[512];uint32_t n=0;bool valid=false;for(uint32_t s=0;s<PERM_SECTORS;s++){Disk::readSector(PERM_START_LBA+s,sec);for(uint32_t e=0;e<512/sizeof(PermissionRecord)&&n<MAX_ENTRIES;e++,n++){kmemcpy(&perms[n],sec+e*sizeof(PermissionRecord),sizeof(PermissionRecord));if(perms[n].magic==PERM_MAGIC)valid=true;}}if(!valid){for(uint32_t i=0;i<MAX_ENTRIES;i++){perms[i].magic=PERM_MAGIC;perms[i].uid=0;perms[i].gid=0;perms[i].mode=0;perms[i].reserved=0;if(entries[i].type==EntryType::FILE)perms[i].mode=0644;else if(entries[i].type==EntryType::DIRECTORY)perms[i].mode=0755;}savePerms();}}
static void savePerms(){uint8_t sec[512];uint32_t n=0;for(uint32_t s=0;s<PERM_SECTORS;s++){kmemset(sec,0,512);for(uint32_t e=0;e<512/sizeof(PermissionRecord)&&n<MAX_ENTRIES;e++,n++)kmemcpy(sec+e*sizeof(PermissionRecord),&perms[n],sizeof(PermissionRecord));Disk::writeSector(PERM_START_LBA+s,sec);}}
static bool blockFree(uint32_t i){return !((bitmap[i/8]>>(i%8))&1);} static void setBlockUsed(uint32_t i,bool u){if(u)bitmap[i/8]|=1<<(i%8);else bitmap[i/8]&=~(1<<(i%8));}
static bool allocateBlock(uint32_t*out){for(uint32_t i=0;i<Disk::SECTOR_SIZE*8;i++)if(blockFree(i)){setBlockUsed(i,true);saveBitmap();*out=DATA_START_LBA+i;return true;}return false;}
static void freeBlock(uint32_t lba){if(lba<DATA_START_LBA)return;uint32_t i=lba-DATA_START_LBA;if(i<Disk::SECTOR_SIZE*8){setBlockUsed(i,false);saveBitmap();}}
static int32_t allocateEntry(){for(uint32_t i=0;i<MAX_ENTRIES;i++)if(entries[i].type==EntryType::UNUSED)return i;return -1;}
static int32_t findChild(uint32_t p,const char*n){for(uint32_t i=0;i<MAX_ENTRIES;i++)if(entries[i].type!=EntryType::UNUSED&&entries[i].parent==p&&kstreq(entries[i].name,n))return i;return -1;}
static int32_t resolvePath(const char*path,int32_t*parentOut=nullptr){if(!path)return -1;uint32_t cur=ROOT_ENTRY_INDEX;if(parentOut)*parentOut=cur;if(path[0]=='/')path++;if(!path[0])return cur;char cbuf[MAX_NAME_LEN];uint32_t c=0;int32_t last=-1;for(uint32_t i=0;;i++){char ch=path[i];if(ch=='/'||ch==0){cbuf[c]=0;if(c){int32_t f=findChild(cur,cbuf);if(f<0)return -1;if(parentOut)*parentOut=cur;cur=f;last=f;}c=0;if(ch==0)break;}else if(c<MAX_NAME_LEN-1)cbuf[c++]=ch;}return last;}
static int32_t resolveParentDir(const char*path){uint32_t len=kstrlen(path);int32_t slash=-1;for(uint32_t i=0;i<len;i++)if(path[i]=='/')slash=i;if(slash<=0)return ROOT_ENTRY_INDEX;char p[128];uint32_t n=slash;if(n>127)n=127;kmemcpy(p,path,n);p[n]=0;int32_t x=resolvePath(p);return x>=0&&entries[x].type==EntryType::DIRECTORY?x:-1;}
static void basename(const char*p,char*out){uint32_t n=kstrlen(p),s=0;for(uint32_t i=0;i<n;i++)if(p[i]=='/')s=i+1;kstrcpy(out,p+s,MAX_NAME_LEN);}
static bool can(int32_t i,uint8_t need){return i>=0&&Permissions::check(uid(),gid(),perms[i].uid,perms[i].gid,perms[i].mode,need);}
static bool parentCan(int32_t p){return can(p,2|1);} // write + execute
namespace FileSystem {
bool initialize(){kprint("[FS] Initializing...\n");Disk::initialize();loadSB();if(sb.magic!=FS_MAGIC){kprint("[FS] No existing filesystem found - formatting disk (first boot only)...\n");kmemset(entries,0,sizeof(entries));kmemset(bitmap,0,sizeof(bitmap));sb.magic=FS_MAGIC;sb.totalSectors=32768;sb.blockSize=512;sb.rootDirectory=0;sb.metadataStartLBA=METADATA_START_LBA;sb.metadataSectors=METADATA_SECTORS;sb.dataStartLBA=DATA_START_LBA;entries[0].type=EntryType::DIRECTORY;kstrcpy(entries[0].name,"/",MAX_NAME_LEN);entries[0].parent=0xffffffff;saveSB();saveMetadata();for(uint32_t i=0;i<MAX_ENTRIES;i++){perms[i].magic=PERM_MAGIC;perms[i].uid=0;perms[i].gid=0;perms[i].mode=entries[i].type==EntryType::DIRECTORY?0755:0;}savePerms();saveBitmap();kprint("[FS] Formatted\n");}else{kprint("[FS] Existing filesystem found - loading metadata...\n");loadMetadata();loadBitmap();loadPerms();}return true;}
bool createFile(const char*path){int32_t p=resolveParentDir(path);if(p<0||!parentCan(p))return false;char n[MAX_NAME_LEN];basename(path,n);if(findChild(p,n)>=0)return false;int32_t i=allocateEntry();if(i<0)return false;kmemset(&entries[i],0,sizeof(FileEntry));entries[i].type=EntryType::FILE;kstrcpy(entries[i].name,n,MAX_NAME_LEN);entries[i].parent=p;perms[i]={PERM_MAGIC,uid(),gid(),0644,0};saveMetadata();savePerms();return true;}
bool writeFile(const char*path,const char*data){int32_t i=resolvePath(path);if(i<0||entries[i].type!=EntryType::FILE||!can(i,2))return false;for(uint32_t j=0;j<entries[i].blockCount;j++)freeBlock(entries[i].blocks[j]);entries[i].blockCount=0;uint32_t len=kstrlen(data),w=0;uint8_t sec[512];while(w<len&&entries[i].blockCount<MAX_FILE_BLOCKS){uint32_t n=len-w;if(n>512)n=512;kmemset(sec,0,512);kmemcpy(sec,data+w,n);uint32_t lba;if(!allocateBlock(&lba))break;Disk::writeSector(lba,sec);entries[i].blocks[entries[i].blockCount++]=lba;w+=n;}entries[i].size=w;saveMetadata();return w==len;}
bool readFile(const char*path,char*buf,uint32_t size){if(!buf||size==0)return false;int32_t i=resolvePath(path);if(i<0||entries[i].type!=EntryType::FILE||!can(i,4))return false;uint32_t to=entries[i].size;if(to>size-1)to=size-1;uint8_t sec[512];uint32_t r=0;for(uint32_t b=0;r<to&&b<entries[i].blockCount;b++){Disk::readSector(entries[i].blocks[b],sec);uint32_t n=to-r;if(n>512)n=512;kmemcpy(buf+r,sec,n);r+=n;}buf[r]=0;return true;}
bool deleteFile(const char*path){int32_t i=resolvePath(path);if(i<0||entries[i].type!=EntryType::FILE||!can(i,2))return false;for(uint32_t j=0;j<entries[i].blockCount;j++)freeBlock(entries[i].blocks[j]);entries[i].type=EntryType::UNUSED;entries[i].blockCount=0;entries[i].size=0;perms[i]={0,0,0,0,0};saveMetadata();savePerms();return true;}
bool createDirectory(const char*path){int32_t p=resolveParentDir(path);if(p<0||!parentCan(p))return false;char n[MAX_NAME_LEN];basename(path,n);if(findChild(p,n)>=0)return false;int32_t i=allocateEntry();if(i<0)return false;kmemset(&entries[i],0,sizeof(FileEntry));entries[i].type=EntryType::DIRECTORY;kstrcpy(entries[i].name,n,MAX_NAME_LEN);entries[i].parent=p;perms[i]={PERM_MAGIC,uid(),gid(),0755,0};saveMetadata();savePerms();return true;}
void listDirectory(const char*path){int32_t d=resolvePath(path);if(d<0||entries[d].type!=EntryType::DIRECTORY||!can(d,1)){kprint("[FS] Permission denied\n");return;}for(uint32_t i=0;i<MAX_ENTRIES;i++)if(entries[i].type!=EntryType::UNUSED&&entries[i].parent==(uint32_t)d){char mode[10];Permissions::modeString(perms[i].mode,mode);kprint(mode);kprint(" ");kprint(entries[i].name);kprint("\n");}}
bool chmod(const char*path,uint16_t mode){int32_t i=resolvePath(path);if(i<0||(!User::isRoot()&&uid()!=perms[i].uid))return false;perms[i].mode=mode&0777;savePerms();return true;}
bool chown(const char*path,uint32_t u,uint32_t g){if(User::get_current_user()&&!User::isRoot())return false;int32_t i=resolvePath(path);if(i<0)return false;perms[i].uid=u;perms[i].gid=g;savePerms();return true;}
bool stat(const char*path,uint32_t*u,uint32_t*g,uint16_t*m){int32_t i=resolvePath(path);if(i<0)return false;if(u)*u=perms[i].uid;if(g)*g=perms[i].gid;if(m)*m=perms[i].mode;return true;}
}
}
