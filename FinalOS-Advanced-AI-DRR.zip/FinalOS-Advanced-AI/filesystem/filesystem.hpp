#pragma once
// filesystem.hpp
// Simple block-based, persistent, educational filesystem.
//
// On-disk layout (see disk.hpp for SECTOR_SIZE = 512):
//
//   Sector 0                : SuperBlock
//   Sector 1                : Free block bitmap (1 bit per data block)
//   Sectors 2 .. 2+META-1   : FileEntry metadata table (files + directories)
//   Sectors META_END ..     : File data blocks (1 block = 1 sector)
//
// This is intentionally close to a classic Unix-style "inode table +
// bitmap + data blocks" layout, simplified to fixed-size arrays so it
// needs no dynamic allocation.

#include <stdint.h>
#include "file.hpp"
#include "directory.hpp"

namespace FS {

    struct SuperBlock {
        uint32_t magic;           // identifies a formatted volume
        uint32_t totalSectors;
        uint32_t blockSize;
        uint32_t rootDirectory;   // entry-table index of "/"
        uint32_t metadataStartLBA;
        uint32_t metadataSectors;
        uint32_t dataStartLBA;
    } __attribute__((packed));

    constexpr uint32_t FS_MAGIC = 0x53465854; // "TXFS" in hex-ish, arbitrary signature

    namespace FileSystem {
        bool initialize();

        bool createFile(const char* path);
        bool writeFile(const char* path, const char* data);
        bool readFile(const char* path, char* buffer, uint32_t size);
        bool deleteFile(const char* path);

        bool createDirectory(const char* path);
        void listDirectory(const char* path);
        bool chmod(const char* path, uint16_t mode);
        bool chown(const char* path, uint32_t uid, uint32_t gid);
        bool stat(const char* path, uint32_t* uid, uint32_t* gid, uint16_t* mode);
    }
}
