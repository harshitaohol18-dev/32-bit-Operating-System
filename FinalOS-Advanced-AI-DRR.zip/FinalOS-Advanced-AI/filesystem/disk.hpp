#pragma once
// disk.hpp
// Minimal ATA PIO disk driver - enough sector read/write to back the
// filesystem with a real QEMU disk image (os.img).

#include <stdint.h>

namespace Disk {

    constexpr uint32_t SECTOR_SIZE = 512;

    bool initialize();

    // lba = logical block address (sector number). buffer must be
    // SECTOR_SIZE (512) bytes.
    bool readSector(uint32_t lba, uint8_t* buffer);
    bool writeSector(uint32_t lba, const uint8_t* buffer);
}
