#pragma once
// file.hpp
// On-disk metadata entry shared by both files and directories.
// Kept fixed-size and POD so it can be read/written directly as raw
// bytes with no serialization step (kernel-friendly, no STL).

#include <stdint.h>

namespace FS {

    constexpr uint32_t MAX_NAME_LEN   = 32;
    constexpr uint32_t MAX_ENTRIES    = 128;   // total files+dirs on the volume
    constexpr uint32_t BLOCK_SIZE     = 512;   // 1 block = 1 disk sector
    constexpr uint32_t MAX_FILE_BLOCKS = 16;    // -> 8KB max file size (baseline)

    enum class EntryType : uint32_t {
        UNUSED    = 0,
        FILE      = 1,
        DIRECTORY = 2,
    };

    // One metadata entry: a file OR a directory.
    struct FileEntry {
        char       name[MAX_NAME_LEN];
        EntryType  type;
        uint32_t   size;                      // bytes used (files only)
        uint32_t   parent;                    // index of parent dir entry, or 0xFFFFFFFF for root
        uint32_t   blocks[MAX_FILE_BLOCKS];    // data block LBAs (files only)
        uint32_t   blockCount;
        // Ownership/permissions live in a sidecar table so the original
        // on-disk FileEntry layout remains backward-compatible.
    } __attribute__((packed));
}
