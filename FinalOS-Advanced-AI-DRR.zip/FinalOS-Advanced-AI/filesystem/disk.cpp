// disk.cpp
// ATA PIO mode driver, primary bus, master drive (0x1F0-0x1F7).
// Polling-based (no IRQ14 handling) -- simplest correct approach for
// an educational baseline; fine for QEMU's virtual disk.

#include "disk.hpp"
#include "../arch/x86/ports.hpp"

#define ATA_DATA        0x1F0
#define ATA_ERROR       0x1F1
#define ATA_SECCOUNT    0x1F2
#define ATA_LBA_LOW     0x1F3
#define ATA_LBA_MID     0x1F4
#define ATA_LBA_HIGH    0x1F5
#define ATA_DRIVE_HEAD  0x1F6
#define ATA_STATUS      0x1F7
#define ATA_COMMAND     0x1F7

#define ATA_CMD_READ    0x20
#define ATA_CMD_WRITE   0x30

#define STATUS_ERR  0x01
#define STATUS_DRQ  0x08
#define STATUS_BSY  0x80

extern "C" void kprint(const char* str);

using namespace Ports;

namespace Disk {

    static bool waitReady() {
        // Poll status until BSY clears; then require DRQ (data ready)
        // and no ERR bit before touching the data port.
        for (int spin = 0; spin < 100000; spin++) {
            uint8_t status = inb(ATA_STATUS);
            if (status & STATUS_ERR) return false;
            if (!(status & STATUS_BSY) && (status & STATUS_DRQ)) return true;
        }
        return false;
    }

    bool initialize() {
        kprint("[DISK] ATA PIO driver ready\n");
        return true;
    }

    static void selectLBA(uint32_t lba, uint8_t sectorCount) {
        outb(ATA_DRIVE_HEAD, 0xE0 | ((lba >> 24) & 0x0F)); // master, LBA mode
        outb(ATA_SECCOUNT, sectorCount);
        outb(ATA_LBA_LOW,  (uint8_t)(lba & 0xFF));
        outb(ATA_LBA_MID,  (uint8_t)((lba >> 8) & 0xFF));
        outb(ATA_LBA_HIGH, (uint8_t)((lba >> 16) & 0xFF));
    }

    bool readSector(uint32_t lba, uint8_t* buffer) {
        // Interrupts are masked for the whole PIO handshake: this is a
        // polling driver with no IRQ14 handler, so a timer tick landing
        // mid-transfer (common once the scheduler/shell are live, not
        // during early boot before sti()) could preempt into another
        // task while the ATA controller is mid-command, then resume
        // this one later against a controller state that's moved on.
        asm volatile ("cli");
        selectLBA(lba, 1);
        outb(ATA_COMMAND, ATA_CMD_READ);

        if (!waitReady()) { asm volatile ("sti"); return false; }

        uint16_t* buf16 = (uint16_t*)buffer;
        for (int i = 0; i < 256; i++) {
            buf16[i] = inw(ATA_DATA);
        }
        asm volatile ("sti");
        return true;
    }

    bool writeSector(uint32_t lba, const uint8_t* buffer) {
        asm volatile ("cli");
        selectLBA(lba, 1);
        outb(ATA_COMMAND, ATA_CMD_WRITE);

        if (!waitReady()) { asm volatile ("sti"); return false; }

        const uint16_t* buf16 = (const uint16_t*)buffer;
        for (int i = 0; i < 256; i++) {
            outw(ATA_DATA, buf16[i]);
        }

        outb(ATA_COMMAND, 0xE7); // CACHE FLUSH - make sure it hits the image file
        waitReady();
        asm volatile ("sti");
        return true;
    }
}
