#include "shell.hpp"
#include "../drivers/vga.hpp"
#include "../drivers/keyboard.hpp"
#include "../drivers/timer.hpp"
#include "../scheduler/scheduler.hpp"
#include "../process/process.hpp"
#include "../user/user.hpp"
#include "../user/permissions.hpp"
#include "../filesystem/filesystem.hpp"
#include "../syscall/syscall.hpp"
#include "../libc/kstd.hpp"
#include "../monitor/monitor.hpp"
#include "../demo/demo.hpp"
#include "../ai/dynamic_rr.hpp"
namespace Shell {
static const int MAX_LINE=128,MAX_ARGS=10;static char line[MAX_LINE],*argv[MAX_ARGS];static int argc;
static void readLine(){int p=0;while(1){char c=Keyboard::get_char();if(c=='\n'){VGA::putchar('\n');break;}if(c=='\b'){if(p){p--;VGA::putchar('\b');}continue;}if(p<MAX_LINE-1&&c>=32&&c<=126){line[p++]=c;VGA::putchar(c);}}line[p]=0;}
static void tokenize(){argc=0;int i=0;while(line[i]&&argc<MAX_ARGS){while(line[i]==' ')i++;if(!line[i])break;argv[argc++]=&line[i];while(line[i]&&line[i]!=' ')i++;if(line[i])line[i++]=0;}}
static uint32_t num(const char*s,bool*ok){uint32_t v=0;*ok=true;for(int i=0;s[i];i++){if(s[i]<'0'||s[i]>'9'){*ok=false;return 0;}v=v*10+(uint32_t)(s[i]-'0');}return v;}
static void help(){VGA::print("\nhelp clear login logout whoami id ps kill nice renice scheduler demo\n");VGA::print("ls cat touch mkdir rm chmod chown echo pipe_test msg_test run exit\n");VGA::print("run: init | pipe_test | msg_sender | msg_receiver | scheduler_test | permission_test\n");VGA::print("scheduler rr|priority|fcfs|ai  (ai = AI-Adaptive: workload-classified quantum)\n");VGA::print("drr [reset]  show Dynamic RR decisions + real kernel counters (use after: scheduler ai)\n");VGA::print("demo [on|off]  toggle background demo-task chatter (default: off)\n");}
static void who(){User::UserAccount*u=User::get_current_user();if(!u){VGA::print("not logged in\n");return;}VGA::print(u->username);VGA::print("\n");}
static void id(){User::UserAccount*u=User::get_current_user();if(!u)return;VGA::print("uid=");VGA::print_dec(u->uid);VGA::print(" gid=");VGA::print_dec(u->gid);VGA::print(" user=");VGA::print(u->username);VGA::print("\n");}
static void scheduler(){if(argc<2){VGA::print(Scheduler::getModeName());VGA::print("\n");return;}if(KLib::strcmp(argv[1],"rr")==0)Scheduler::setMode(Scheduler::Mode::ROUND_ROBIN);else if(KLib::strcmp(argv[1],"priority")==0||KLib::strcmp(argv[1],"prio")==0)Scheduler::setMode(Scheduler::Mode::PRIORITY);else if(KLib::strcmp(argv[1],"fcfs")==0)Scheduler::setMode(Scheduler::Mode::FCFS);else if(KLib::strcmp(argv[1],"ai")==0)Scheduler::setMode(Scheduler::Mode::AI_ADAPTIVE);else VGA::print("scheduler rr|priority|fcfs|ai\n");}
static void drrCmd(){if(argc>1&&KLib::strcmp(argv[1],"reset")==0){Scheduler::resetDrrStats();VGA::print("DRR counters reset\n");return;}
VGA::print("\nDynamic RR - REAL kernel counters (mode: ");VGA::print(Scheduler::getModeName());VGA::print(")\n");VGA::print("ticks=");VGA::print_dec(Scheduler::getSystemTicks());VGA::print(" ctxsw=");VGA::print_dec(Scheduler::getTotalContextSwitches());VGA::print(" drr_decisions=");VGA::print_dec(Scheduler::getDrrDecisions());VGA::print("\n");
VGA::print("PID NAME        CPU READY RESP DISP AVGQ  LAST DECISION (explainable)\n");
for(uint32_t i=0;i<Scheduler::MAX_TASKS;i++){Scheduler::Task*t=Scheduler::getTaskSlot(i);if(!t||!t->inUse)continue;VGA::print_dec(t->pid);VGA::print("   ");VGA::print(t->name);VGA::print(" cpu=");VGA::print_dec(t->cpuTicks);VGA::print(" rdy=");VGA::print_dec(t->readyTicks);VGA::print(" resp=");if(t->hasRun)VGA::print_dec(t->firstRunTick-t->creationTick);else VGA::print("-");VGA::print(" disp=");VGA::print_dec(t->drrDispatches);VGA::print(" avgq=");VGA::print_dec(t->drrDispatches?t->drrQuantumSum/t->drrDispatches:0);VGA::print("\n");
if(t->drrDispatches){AI::DrrInput in{t->burstRun,t->lastWait,t->drrPrio,t->drrRunnable};AI::DrrDecision d;d.cls=(AI::Workload)t->drrCls;d.baseQuantum=t->drrBase;d.flags=t->drrFlags;d.quantum=t->aiQuantum;char b[120];AI::drrExplain(in,d,b,sizeof(b));VGA::print("      why: ");VGA::print(b);VGA::print("\n");}}
VGA::print("(decisions only recorded in 'scheduler ai' mode; offline RR-vs-DRR results: casestudy/)\n");}
static void demoCmd(){if(argc<2){VGA::print("Demo chatter is currently ");VGA::print(Demo::isVerbose()?"ON":"OFF");VGA::print("\nUsage: demo [on|off]\n");return;}if(KLib::strcmp(argv[1],"on")==0){Demo::setVerbose(true);VGA::print("Demo chatter ON\n");}else if(KLib::strcmp(argv[1],"off")==0){Demo::setVerbose(false);VGA::print("Demo chatter OFF\n");}else VGA::print("Usage: demo [on|off]\n");}
static bool parseOct(const char*s,uint16_t*out){uint32_t v=0;for(int i=0;s[i];i++){if(s[i]<'0'||s[i]>'7')return false;v=(v<<3)+(s[i]-'0');if(v>0777)return false;}*out=(uint16_t)v;return true;}
static void fsCmd(){if(KLib::strcmp(argv[0],"ls")==0){FS::FileSystem::listDirectory(argc>1?argv[1]:"/");return;}if(argc<2){VGA::print("missing path\n");return;}if(KLib::strcmp(argv[0],"touch")==0)VGA::print(FS::FileSystem::createFile(argv[1])?"OK\n":"FAILED\n");else if(KLib::strcmp(argv[0],"mkdir")==0)VGA::print(FS::FileSystem::createDirectory(argv[1])?"OK\n":"FAILED\n");else if(KLib::strcmp(argv[0],"rm")==0)VGA::print(FS::FileSystem::deleteFile(argv[1])?"OK\n":"FAILED\n");else if(KLib::strcmp(argv[0],"cat")==0){
    // static, not a stack local: a C++ function's stack frame size is
    // fixed at entry (one prologue "sub esp") for the whole function,
    // not per-branch, so an 8192-byte local here was reserved on
    // *every* fsCmd() call - ls, touch, chmod, all of them - even
    // though only "cat" ever touches it. On this kernel's 8KB
    // (TASK_STACK_SIZE) per-task stack that alone left next to no
    // margin, and chmod/chown's deeper call chain (fsCmd -> chmod ->
    // savePerms -> Disk::writeSector) was what actually ran past the
    // end of the task's stack array into adjacent .bss/heap memory and
    // crashed. Confirmed with objdump: the old code's prologue was
    // `sub esp, 0x2008` unconditionally. A static buffer costs zero
    // stack space; safe here since there's a single shell task.
    static char catBuf[8192];
    if(FS::FileSystem::readFile(argv[1],catBuf,sizeof(catBuf))){VGA::print(catBuf);VGA::print("\n");}else VGA::print("FAILED\n");
}else if(KLib::strcmp(argv[0],"chmod")==0){if(argc<3){VGA::print("chmod <mode> <path>\n");return;}uint16_t m;if(!parseOct(argv[1],&m)||!FS::FileSystem::chmod(argv[2],m))VGA::print("FAILED\n");else VGA::print("OK\n");}else if(KLib::strcmp(argv[0],"chown")==0){if(argc<4){VGA::print("chown <uid> <gid> <path>\n");return;}bool a,b;uint32_t u=num(argv[1],&a),g=num(argv[2],&b);if(!a||!b||!FS::FileSystem::chown(argv[3],u,g))VGA::print("FAILED\n");else VGA::print("OK\n");}}
static void ps(){Monitor::displayProcesses();if(Process::isUserRunning()){Process::PCB*p=Process::current();VGA::print("Ring3 PID ");VGA::print_dec(p->pid);VGA::print(" UID ");VGA::print_dec(p->uid);VGA::print("\n");}}
static void killCmd(){if(argc<2){VGA::print("kill <pid>\n");return;}bool ok;uint32_t pid=num(argv[1],&ok);if(!ok){VGA::print("bad pid\n");return;}Scheduler::Task*t=nullptr;for(uint32_t i=0;i<Scheduler::MAX_TASKS;i++){t=Scheduler::getTaskSlot(i);if(t&&t->inUse&&t->pid==pid)break;t=nullptr;}User::UserAccount*u=User::get_current_user();if(!t){VGA::print("not found\n");return;}if(u&&u->uid!=0&&t->uid!=u->uid){VGA::print("permission denied\n");return;}Scheduler::removeTask(pid);VGA::print("terminated\n");}
static void prioCmd(){if(argc<2){VGA::print("nice <priority> or renice <pid> <priority>\n");return;}bool a,b=false;uint32_t pid=0,p=0;if(KLib::strcmp(argv[0],"nice")==0){p=num(argv[1],&a);Scheduler::Task*t=Scheduler::currentTask();if(t)Scheduler::setPriority(t->pid,p);}else{if(argc<3)return;pid=num(argv[1],&a);p=num(argv[2],&b);Scheduler::Task*t=Scheduler::getTaskSlot(0);for(uint32_t i=0;i<Scheduler::MAX_TASKS;i++){t=Scheduler::getTaskSlot(i);if(t&&t->inUse&&t->pid==pid)break;t=nullptr;}User::UserAccount*u=User::get_current_user();if(t&&(!u||u->uid==0||t->uid==u->uid))Scheduler::setPriority(pid,p);else VGA::print("permission denied\n");}}
void run(){VGA::print("\nType 'help' for commands.\n");while(1){VGA::set_color(VGA::LIGHT_CYAN,VGA::BLACK);VGA::print("myos> ");VGA::set_color(VGA::WHITE,VGA::BLACK);readLine();tokenize();if(!argc)continue;
if(KLib::strcmp(argv[0],"help")==0)help();else if(KLib::strcmp(argv[0],"clear")==0)VGA::clear();else if(KLib::strcmp(argv[0],"whoami")==0)who();else if(KLib::strcmp(argv[0],"id")==0)id();else if(KLib::strcmp(argv[0],"ps")==0)ps();else if(KLib::strcmp(argv[0],"scheduler")==0)scheduler();else if(KLib::strcmp(argv[0],"demo")==0)demoCmd();else if(KLib::strcmp(argv[0],"drr")==0)drrCmd();else if(KLib::strcmp(argv[0],"kill")==0)killCmd();else if(KLib::strcmp(argv[0],"nice")==0||KLib::strcmp(argv[0],"renice")==0)prioCmd();else if(KLib::strcmp(argv[0],"ls")==0||KLib::strcmp(argv[0],"cat")==0||KLib::strcmp(argv[0],"touch")==0||KLib::strcmp(argv[0],"mkdir")==0||KLib::strcmp(argv[0],"rm")==0||KLib::strcmp(argv[0],"chmod")==0||KLib::strcmp(argv[0],"chown")==0)fsCmd();else if(KLib::strcmp(argv[0],"echo")==0){for(int i=1;i<argc;i++){if(i>1)VGA::putchar(' ');VGA::print(argv[i]);}VGA::putchar('\n');}else if(KLib::strcmp(argv[0],"login")==0||KLib::strcmp(argv[0],"logout")==0){User::loginPrompt();}else if(KLib::strcmp(argv[0],"run")==0){if(argc<2){VGA::print("run <app>\n");continue;}if(!Process::start(argv[1],5))VGA::print("unknown/busy app\n");else Scheduler::yield();}else if(KLib::strcmp(argv[0],"pipe_test")==0){if(Process::start("pipe_test",5))Scheduler::yield();}else if(KLib::strcmp(argv[0],"msg_test")==0){if(Process::start("msg_sender",5))Scheduler::yield();}else if(KLib::strcmp(argv[0],"exit")==0){VGA::print("Use logout to end the session.\n");}else VGA::print("Unknown command\n");}}
}
