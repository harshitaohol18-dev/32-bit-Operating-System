#pragma once
// shell.hpp - interactive command-line shell. Runs as an ordinary
// scheduled task (see kernel_main.cpp), just like any other process.
namespace Shell {
    void run(); // task entry point
}
