# Standard RR vs Dynamic RR - SIMULATED results

Source: `casestudy/drr_sim.cpp` (tick-level model, 30 seeds per scenario, switch cost 1 tick, 1 tick = 10 ms). Dynamic RR uses the kernel's own `ai/dynamic_rr.cpp` decision code. **These are simulation results, not kernel measurements.** Lower is better except CPU util and Jain fairness. Values are means over seeds.

## cpu_bound
8 CPU-bound jobs, similar length, all arrive at t=0

| Policy | avg_wait | avg_turnaround | avg_response | ctx_switches | cpu_util_pct | jain_fairness | max_wait | short_turnaround | long_turnaround | short_response | avg_quantum |
|---|---|---|---|---|---|---|---|---|---|---|---|
| RR q=5 (kernel default) | 777.80 | 898.09 | 21.00 | 162.50 | 83.11 | 1.00 | 823.37 | 0.00 | 898.09 | 0.00 | 5.00 |
| RR q=10 | 711.41 | 821.81 | 38.50 | 83.43 | 90.55 | 1.00 | 756.77 | 0.00 | 821.81 | 0.00 | 10.00 |
| Dynamic RR | 734.32 | 848.22 | 10.50 | 111.43 | 87.77 | 1.00 | 781.30 | 0.00 | 848.22 | 0.00 | 7.59 |

## mixed_interactive_batch
3 long CPU hogs + 8 interactive jobs (short CPU bursts with I/O)

| Policy | avg_wait | avg_turnaround | avg_response | ctx_switches | cpu_util_pct | jain_fairness | max_wait | short_turnaround | long_turnaround | short_response | avg_quantum |
|---|---|---|---|---|---|---|---|---|---|---|---|
| RR q=5 (kernel default) | 357.35 | 474.52 | 24.83 | 167.27 | 82.10 | 0.99 | 672.80 | 315.77 | 897.88 | 31.89 | 5.00 |
| RR q=10 | 377.05 | 488.27 | 36.13 | 101.77 | 88.28 | 0.97 | 628.17 | 358.75 | 833.67 | 45.56 | 10.00 |
| Dynamic RR | 508.82 | 625.15 | 14.25 | 158.07 | 82.89 | 0.92 | 685.30 | 525.45 | 891.03 | 18.19 | 5.20 |

## io_heavy
10 jobs alternating tiny CPU bursts and long I/O waits

| Policy | avg_wait | avg_turnaround | avg_response | ctx_switches | cpu_util_pct | jain_fairness | max_wait | short_turnaround | long_turnaround | short_response | avg_quantum |
|---|---|---|---|---|---|---|---|---|---|---|---|
| RR q=5 (kernel default) | 91.39 | 238.77 | 11.44 | 69.50 | 69.74 | 0.99 | 107.67 | 238.77 | 0.00 | 11.44 | 5.00 |
| RR q=10 | 91.39 | 238.77 | 11.44 | 69.50 | 69.74 | 0.99 | 107.67 | 238.77 | 0.00 | 11.44 | 10.00 |
| Dynamic RR | 118.84 | 269.42 | 8.92 | 101.53 | 62.77 | 0.99 | 141.23 | 269.42 | 0.00 | 8.92 | 2.94 |

## convoy_short_behind_long
2 very long jobs arrive first, then 10 short jobs trickle in

| Policy | avg_wait | avg_turnaround | avg_response | ctx_switches | cpu_util_pct | jain_fairness | max_wait | short_turnaround | long_turnaround | short_response | avg_quantum |
|---|---|---|---|---|---|---|---|---|---|---|---|
| RR q=5 (kernel default) | 130.75 | 198.28 | 26.32 | 135.00 | 83.34 | 0.68 | 441.57 | 78.62 | 796.57 | 30.99 | 5.00 |
| RR q=10 | 115.90 | 178.02 | 41.46 | 70.07 | 90.59 | 0.70 | 406.30 | 67.38 | 731.20 | 48.65 | 10.00 |
| Dynamic RR | 163.35 | 226.93 | 19.46 | 87.53 | 88.51 | 0.50 | 426.43 | 122.67 | 748.20 | 22.95 | 8.02 |

## bursty_arrivals
16 mixed jobs arriving in two bursts (t~0 and t~100)

| Policy | avg_wait | avg_turnaround | avg_response | ctx_switches | cpu_util_pct | jain_fairness | max_wait | short_turnaround | long_turnaround | short_response | avg_quantum |
|---|---|---|---|---|---|---|---|---|---|---|---|
| RR q=5 (kernel default) | 527.60 | 600.57 | 38.12 | 188.33 | 82.72 | 0.94 | 912.30 | 282.95 | 934.60 | 39.62 | 5.00 |
| RR q=10 | 489.94 | 557.46 | 65.76 | 101.17 | 89.85 | 0.92 | 833.33 | 276.56 | 853.95 | 68.74 | 10.00 |
| Dynamic RR | 610.87 | 682.31 | 27.59 | 164.00 | 84.38 | 0.88 | 867.63 | 481.02 | 896.02 | 29.35 | 6.00 |

## high_load_mixed
24 mixed jobs at once (stress: runnable queue >= 6 most of the time)

| Policy | avg_wait | avg_turnaround | avg_response | ctx_switches | cpu_util_pct | jain_fairness | max_wait | short_turnaround | long_turnaround | short_response | avg_quantum |
|---|---|---|---|---|---|---|---|---|---|---|---|
| RR q=5 (kernel default) | 498.37 | 555.06 | 60.50 | 201.70 | 82.21 | 0.81 | 993.83 | 288.30 | 1038.51 | 67.34 | 5.00 |
| RR q=10 | 469.23 | 522.12 | 91.01 | 110.63 | 89.36 | 0.75 | 914.47 | 284.84 | 953.17 | 101.65 | 10.00 |
| Dynamic RR | 598.59 | 654.87 | 32.61 | 192.10 | 82.81 | 0.84 | 993.47 | 445.91 | 1035.00 | 36.26 | 5.31 |

## priority_mix
8 CPU jobs with priorities 1..9 (tests the priority rule)

| Policy | avg_wait | avg_turnaround | avg_response | ctx_switches | cpu_util_pct | jain_fairness | max_wait | short_turnaround | long_turnaround | short_response | avg_quantum |
|---|---|---|---|---|---|---|---|---|---|---|---|
| RR q=5 (kernel default) | 777.80 | 898.09 | 21.00 | 162.50 | 83.11 | 1.00 | 823.37 | 0.00 | 898.09 | 0.00 | 5.00 |
| RR q=10 | 711.41 | 821.81 | 38.50 | 83.43 | 90.55 | 1.00 | 756.77 | 0.00 | 821.81 | 0.00 | 10.00 |
| Dynamic RR | 695.45 | 808.79 | 13.75 | 106.97 | 88.20 | 0.98 | 786.20 | 0.00 | 808.79 | 0.00 | 7.90 |

## Scoreboard
Scenarios where Dynamic RR beats BOTH fixed-RR baselines (scenario mean): avg wait 1/7, avg turnaround 1/7, avg response 7/7, fewer context switches 0/7.
