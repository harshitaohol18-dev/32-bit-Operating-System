# Case Study: Standard Round Robin vs Dynamic Round Robin (FinalOS)

## 1. What is real, what is not (read first)
| Component | Status |
|---|---|
| Rule layer (`ai/dynamic_rr.cpp`: load / alone / priority / clamp) | **Hand-written heuristic.** Not learned. |
| Workload classifier (`ai/classifier.cpp`) | **Hand-ported decision tree.** The README says it was fit offline with scikit-learn on synthetic telemetry, but **no model file, training data or training script is in this repository**, so that claim cannot be verified or reproduced here. Treat it as a fixed hand-coded rule table. |
| Class -> quantum table (`ai/adaptive_quantum.cpp`) | Hand-chosen constants. |
| Tables in `results/` | **Simulated** (`casestudy/drr_sim.cpp`, tick model). |
| `drr` shell command / per-task counters | **Real kernel measurements** (ticks, ready ticks, response, dispatches). Instrumentation was added and compiles; **no kernel benchmark run is reported** here (no QEMU in the build environment). |
| Trained ML model | **None exists in this project.** |
Also: the shipped archive contained no GUI and no separate `FinalOS-Advanced-AI-CaseStudy` directory; the existing case study was the AI-Adaptive scheduler and README text.

## 2. Methodology
`drr_sim` is a 1-tick discrete simulator: a process is a list of CPU/I/O bursts plus arrival and priority. Policies run on **identical process sets** (same seed): RR q=5 (the kernel default), RR q=10, and Dynamic RR, which calls the *same* `AI::drrDecide()` the kernel calls. Each context switch to a different process costs 1 tick. 7 scenarios x 30 seeds (cpu_bound, mixed_interactive_batch, io_heavy, convoy_short_behind_long, bursty_arrivals, high_load_mixed, priority_mix). Dynamic RR only sees observable features (burst length since last block, time just spent waiting, priority, runnable count) - not remaining burst time.
Metrics: avg waiting (time READY), turnaround, response (arrival to first dispatch), context switches, CPU utilization (useful ticks / makespan), Jain fairness over progress = (cpu+io)/turnaround, max wait, short-job and long-job turnaround.

## 3. Algorithm (Dynamic RR)
At each dispatch: `class = classify(burst, wait, prio, runnable)`; `q = classQuantum(class)` (Short 3, Interactive 4, I/O 6, Background 6, Long/CPU 12);
1. `runnable >= 6` -> `q = q*3/4`; else `runnable <= 1` -> `q = q*2`
2. `prio <= 2` -> `q += 2`; `prio >= 8` -> `q -= 1`
3. clamp to [2, 20].
Every decision records which rules fired; `drrExplain()` renders it, e.g. `class=Short Running base=3; load 8>=6 x3/4; => q=2` (see `results/decision_trace_sample.txt`; kernel: `scheduler ai` then `drr`).

## 4. Results (simulated; means over 30 seeds; full tables in `results/summary.md`)
| Scenario | Avg response RR5 / RR10 / **DRR** | Avg wait RR5 / RR10 / **DRR** | Ctx switches RR5 / RR10 / **DRR** |
|---|---|---|---|
| cpu_bound | 21.0 / 38.5 / **10.5** | 778 / 711 / **734** | 163 / 83 / **111** |
| mixed_interactive_batch | 24.8 / 36.1 / **14.3** | 357 / 377 / **509** | 167 / 102 / **158** |
| io_heavy | 11.4 / 11.4 / **8.9** | 91 / 91 / **119** | 70 / 70 / **102** |
| convoy_short_behind_long | 26.3 / 41.5 / **19.5** | 131 / 116 / **163** | 135 / 70 / **88** |
| bursty_arrivals | 38.1 / 65.8 / **27.6** | 528 / 490 / **611** | 188 / 101 / **164** |
| high_load_mixed | 60.5 / 91.0 / **32.6** | 498 / 469 / **599** | 202 / 111 / **192** |
| priority_mix | 21.0 / 38.5 / **13.8** | 778 / 711 / **695** | 163 / 83 / **107** |

Scoreboard (DRR beats both fixed baselines): response 7/7, avg waiting 1/7, avg turnaround 1/7, fewer context switches 0/7.

**Honest reading:** this first version of Dynamic RR is a *response-time* policy. It reliably cuts response time (roughly 25-50% vs RR q=5), but it **loses on average waiting, turnaround and short-job turnaround** in mixed/high-load workloads (e.g. mixed_interactive_batch short-job turnaround 525 vs 316 for RR q=5) and uses more context switches than RR q=10. Fairness (Jain) is mixed: better in high_load_mixed (0.84 vs 0.81/0.75), worse in convoy (0.50 vs 0.68) and mixed (0.92 vs 0.99). It is not a general improvement over standard RR.

## 5. Why (diagnosed from the decision traces)
- A task with no history has `burst=0`, so the tree labels even CPU hogs "Short Running" (q=3, then 2 under load) until their burst grows, then "I/O Intensive" (burst 4-11, prio>3) - CPU-bound jobs are misclassified for their first ~15 ticks each time they block/start.
- Short-job quanta (2-4) are often smaller than the job's burst, forcing an extra full queue rotation behind the hogs - hurting turnaround.
- Tree thresholds `readyQueueLen <= 426` and `waitTicks <= 552` come from the original simulator's scale and are effectively constant in a 32-task kernel.
- The class-quantum constants and the x3/4 load rule were set by hand and **not tuned** (no tuning was done, so as not to overfit these scenarios).

## 6. Limitations
Simulation only (no I/O device contention, no preemption cost beyond a fixed tick, deterministic bursts from a simple RNG, 100 Hz tick); synthetic workloads; classifier not verifiably trained; real-kernel numbers not yet collected; Jain index computed on progress ratio, one of several reasonable fairness definitions; ring-3 processes bypass `Scheduler::tick()` (existing design) so DRR applies to kernel tasks only.
