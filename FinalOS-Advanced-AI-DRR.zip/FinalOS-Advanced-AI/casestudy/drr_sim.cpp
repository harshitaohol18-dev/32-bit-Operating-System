// drr_sim.cpp - host-side SIMULATION: standard Round Robin vs Dynamic RR.
// Uses the kernel's own ai/dynamic_rr.cpp + ai/classifier.cpp decision code.
// All numbers it produces are SIMULATED (tick-level model), not kernel runs.
// Build: see casestudy/Makefile.  Usage: ./drr_sim <outdir>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <deque>
#include <string>
#include <vector>
#include <functional>
#include <algorithm>
#include "../ai/dynamic_rr.hpp"

struct Proc { std::string name; int arrival, prio; bool shortJob; std::vector<int> bursts; // cpu,io,cpu,...,cpu
  // runtime
  size_t idx=0; int rem=0, ioDone=-1, burstRun=0, waitCur=0, readyTicks=0, first=-1, finish=-1, cpuTotal=0, ioTotal=0; };
struct Policy { std::string name; int fixedQ; /* 0 => dynamic */ };
struct Metrics { double wait,turn,resp,ctx,util,jain,maxWait,shortTurn,longTurn,shortResp,avgQ; };
struct Rng { uint32_t s; int next(int lo,int hi){ s=s*1664525u+1013904223u; return lo+(int)((s>>8)%(uint32_t)(hi-lo+1)); } };
struct Trace { int t; std::string proc; std::string why; };

static Metrics simulate(std::vector<Proc> ps, const Policy& pol, int switchCost, std::vector<Trace>* trace){
  for(auto&p:ps){ p.idx=0; p.rem=p.bursts[0]; for(size_t i=0;i<p.bursts.size();i++){ if(i%2==0)p.cpuTotal+=p.bursts[i]; else p.ioTotal+=p.bursts[i]; } }
  std::deque<int> q; int run=-1, last=-1, used=0, quantum=0, overhead=0, pend=-1, done=0, t=0;
  long ctx=0, useful=0, qSum=0, qN=0; int n=ps.size();
  while(done<n && t<1000000){
    for(int i=0;i<n;i++) if(ps[i].arrival==t) q.push_back(i);
    for(int i=0;i<n;i++) if(ps[i].ioDone==t){ ps[i].ioDone=-1; ps[i].waitCur=0; q.push_back(i);} 
    if(pend>=0){ q.push_back(pend); pend=-1; }
    if(run<0 && !q.empty()){
      run=q.front(); q.pop_front(); Proc&p=ps[run];
      if(p.first<0) p.first=t;
      if(pol.fixedQ){ quantum=pol.fixedQ; }
      else{
        AI::DrrInput in{(uint32_t)p.burstRun,(uint32_t)p.waitCur,(uint32_t)p.prio,(uint32_t)q.size()+1};
        AI::DrrDecision d=AI::drrDecide(in); quantum=d.quantum;
        if(trace && trace->size()<400){ char b[200]; AI::drrExplain(in,d,b,sizeof b); trace->push_back({t,p.name,b}); }
      }
      qSum+=quantum; qN++; used=0; p.waitCur=0;
      if(run!=last){ ctx++; overhead=switchCost; } else overhead=0;
      last=run;
    }
    // execute one tick
    for(int x:q){ ps[x].readyTicks++; ps[x].waitCur++; }
    if(run>=0){
      Proc&p=ps[run];
      if(overhead>0){ overhead--; }
      else{
        p.rem--; p.burstRun++; used++; useful++;
        if(p.rem==0){
          if(p.idx+1>=p.bursts.size()){ p.finish=t+1; done++; }
          else{ p.ioDone=t+1+p.bursts[p.idx+1]; p.idx+=2; p.rem=p.bursts[p.idx]; p.burstRun=0; }
          run=-1;
        } else if(used>=quantum){ pend=run; run=-1; }
      }
    }
    t++;
  }
  Metrics m{}; double sw=0,st=0,sr=0,mw=0,stS=0,stL=0,srS=0; int nS=0,nL=0; double s1=0,s2=0;
  for(auto&p:ps){ double turn=p.finish-p.arrival; sw+=p.readyTicks; st+=turn; sr+=p.first-p.arrival; mw=std::max<double>(mw,p.readyTicks);
    if(p.shortJob){stS+=turn;srS+=p.first-p.arrival;nS++;} else {stL+=turn;nL++;}
    double prog=(double)(p.cpuTotal+p.ioTotal)/turn; s1+=prog; s2+=prog*prog; }
  m.wait=sw/n; m.turn=st/n; m.resp=sr/n; m.ctx=ctx; m.util=100.0*useful/t; m.jain=s1*s1/(n*s2); m.maxWait=mw;
  m.shortTurn=nS?stS/nS:0; m.longTurn=nL?stL/nL:0; m.shortResp=nS?srS/nS:0; m.avgQ=qN?(double)qSum/qN:0; return m;
}

// ---- workload scenarios (deterministic per seed) ----
struct Scenario { const char* id; const char* desc; std::function<std::vector<Proc>(Rng&)> gen; };
static Proc mk(const char*nm,int arr,int prio,bool sh,std::vector<int> b){ Proc p; p.name=nm; p.arrival=arr; p.prio=prio; p.shortJob=sh; p.bursts=b; return p; }
static std::vector<Scenario> scenarios(){ return {
 {"cpu_bound","8 CPU-bound jobs, similar length, all arrive at t=0",[](Rng&r){ std::vector<Proc> v; for(int i=0;i<8;i++) v.push_back(mk(("cpu"+std::to_string(i)).c_str(),0,5,false,{r.next(80,120)})); return v; }},
 {"mixed_interactive_batch","3 long CPU hogs + 8 interactive jobs (short CPU bursts with I/O)",[](Rng&r){ std::vector<Proc> v; for(int i=0;i<3;i++) v.push_back(mk(("batch"+std::to_string(i)).c_str(),0,5,false,{r.next(150,250)})); for(int i=0;i<8;i++){ std::vector<int> b; int k=r.next(4,7); for(int j=0;j<k;j++){ b.push_back(r.next(2,6)); if(j<k-1) b.push_back(r.next(5,15)); } v.push_back(mk(("inter"+std::to_string(i)).c_str(),r.next(0,10),3,true,b)); } return v; }},
 {"io_heavy","10 jobs alternating tiny CPU bursts and long I/O waits",[](Rng&r){ std::vector<Proc> v; for(int i=0;i<10;i++){ std::vector<int> b; int k=r.next(5,9); for(int j=0;j<k;j++){ b.push_back(r.next(1,5)); if(j<k-1) b.push_back(r.next(10,30)); } v.push_back(mk(("io"+std::to_string(i)).c_str(),r.next(0,15),5,true,b)); } return v; }},
 {"convoy_short_behind_long","2 very long jobs arrive first, then 10 short jobs trickle in",[](Rng&r){ std::vector<Proc> v; for(int i=0;i<2;i++) v.push_back(mk(("long"+std::to_string(i)).c_str(),0,5,false,{r.next(250,350)})); for(int i=0;i<10;i++) v.push_back(mk(("short"+std::to_string(i)).c_str(),r.next(5,60),5,true,{r.next(3,12)})); return v; }},
 {"bursty_arrivals","16 mixed jobs arriving in two bursts (t~0 and t~100)",[](Rng&r){ std::vector<Proc> v; for(int i=0;i<16;i++){ bool sh=r.next(0,1); int arr=(i<8?0:100)+r.next(0,5); if(sh) v.push_back(mk(("s"+std::to_string(i)).c_str(),arr,4,true,{r.next(4,15),r.next(5,12),r.next(4,15)})); else v.push_back(mk(("l"+std::to_string(i)).c_str(),arr,5,false,{r.next(60,140)})); } return v; }},
 {"high_load_mixed","24 mixed jobs at once (stress: runnable queue >= 6 most of the time)",[](Rng&r){ std::vector<Proc> v; for(int i=0;i<24;i++){ int k=r.next(0,2); if(k==0) v.push_back(mk(("c"+std::to_string(i)).c_str(),r.next(0,10),5,false,{r.next(60,120)})); else if(k==1){ std::vector<int> b{r.next(3,8),r.next(8,20),r.next(3,8),r.next(8,20),r.next(3,8)}; v.push_back(mk(("m"+std::to_string(i)).c_str(),r.next(0,10),4,true,b)); } else v.push_back(mk(("t"+std::to_string(i)).c_str(),r.next(0,30),5,true,{r.next(2,10)})); } return v; }},
 {"priority_mix","8 CPU jobs with priorities 1..9 (tests the priority rule)",[](Rng&r){ std::vector<Proc> v; for(int i=0;i<8;i++) v.push_back(mk(("p"+std::to_string(i)).c_str(),0,1+i,false,{r.next(80,120)})); return v; }},
};}

int main(int argc,char**argv){
  std::string out=argc>1?argv[1]:"results"; std::string mk_="mkdir -p "+out; if(system(mk_.c_str())) return 1;
  const int SEEDS=30, COST=1; // 1 tick = 10 ms @100Hz; each switch costs 1 tick overhead
  std::vector<Policy> pols={{"RR q=5 (kernel default)",5},{"RR q=10",10},{"Dynamic RR",0}};
  const char* mn[]={"avg_wait","avg_turnaround","avg_response","ctx_switches","cpu_util_pct","jain_fairness","max_wait","short_turnaround","long_turnaround","short_response","avg_quantum"};
  FILE*csv=fopen((out+"/results.csv").c_str(),"w"); fprintf(csv,"scenario,policy,seeds"); for(auto m:mn) fprintf(csv,",%s",m); fprintf(csv,"\n");
  FILE*md=fopen((out+"/summary.md").c_str(),"w");
  fprintf(md,"# Standard RR vs Dynamic RR - SIMULATED results\n\nSource: `casestudy/drr_sim.cpp` (tick-level model, %d seeds per scenario, switch cost %d tick, 1 tick = 10 ms). Dynamic RR uses the kernel's own `ai/dynamic_rr.cpp` decision code. **These are simulation results, not kernel measurements.** Lower is better except CPU util and Jain fairness. Values are means over seeds.\n\n",SEEDS,COST);
  FILE*tr=fopen((out+"/decision_trace_sample.txt").c_str(),"w");
  int dynWinsWait=0,dynWinsTurn=0,dynWinsResp=0,dynWinsCtx=0,total=0;
  for(auto&sc:scenarios()){
    std::vector<Metrics> avg(pols.size()); std::vector<std::vector<double>> wins(3); 
    for(int s=1;s<=SEEDS;s++){
      Rng r{(uint32_t)(s*7919)}; auto ps=sc.gen(r);
      for(size_t k=0;k<pols.size();k++){
        std::vector<Trace> t; Metrics m=simulate(ps,pols[k],COST,(s==1&&k==2)?&t:nullptr);
        double*a=(double*)&avg[k]; double*b=(double*)&m; for(int i=0;i<11;i++) a[i]+=b[i]/SEEDS;
        if(!t.empty()){ fprintf(tr,"=== scenario %s, seed 1: first Dynamic RR decisions ===\n",sc.id); for(size_t i=0;i<t.size()&&i<25;i++) fprintf(tr,"t=%-4d %-8s %s\n",t[i].t,t[i].proc.c_str(),t[i].why.c_str()); fprintf(tr,"\n"); }
      }
    }
    fprintf(md,"## %s\n%s\n\n| Policy |",sc.id,sc.desc); for(auto m:mn) fprintf(md," %s |",m); fprintf(md,"\n|---|"); for(size_t i=0;i<11;i++) fprintf(md,"---|"); fprintf(md,"\n");
    for(size_t k=0;k<pols.size();k++){ double*a=(double*)&avg[k]; fprintf(md,"| %s |",pols[k].name.c_str()); fprintf(csv,"%s,\"%s\",%d",sc.id,pols[k].name.c_str(),SEEDS); for(int i=0;i<11;i++){ fprintf(md," %.2f |",a[i]); fprintf(csv,",%.4f",a[i]); } fprintf(md,"\n"); fprintf(csv,"\n"); }
    fprintf(md,"\n"); total++;
    // Dynamic vs best of the two fixed baselines, on the scenario mean
    auto cmp=[&](int field,bool lowerBetter,int&ctr){ double*d=(double*)&avg[2],*a=(double*)&avg[0],*b=(double*)&avg[1]; double best=lowerBetter?std::min(a[field],b[field]):std::max(a[field],b[field]); if(lowerBetter?d[field]<best:d[field]>best) ctr++; };
    cmp(0,true,dynWinsWait); cmp(1,true,dynWinsTurn); cmp(2,true,dynWinsResp); cmp(3,true,dynWinsCtx);
  }
  fprintf(md,"## Scoreboard\nScenarios where Dynamic RR beats BOTH fixed-RR baselines (scenario mean): avg wait %d/%d, avg turnaround %d/%d, avg response %d/%d, fewer context switches %d/%d.\n",dynWinsWait,total,dynWinsTurn,total,dynWinsResp,total,dynWinsCtx,total);
  fclose(csv);fclose(md);fclose(tr); printf("wrote %s/{results.csv,summary.md,decision_trace_sample.txt}\n",out.c_str()); return 0; }
