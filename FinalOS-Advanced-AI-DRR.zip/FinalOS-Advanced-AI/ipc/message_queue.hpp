#pragma once
#include <stdint.h>
namespace IPC {
constexpr uint32_t MAX_QUEUES=8,MAX_MESSAGES=16,MAX_MESSAGE_SIZE=128;
int32_t msg_queue_create(uint32_t owner,uint32_t maxMessages=MAX_MESSAGES);
int32_t msg_queue_destroy(uint32_t qid,uint32_t uid);
int32_t msg_send(uint32_t qid,const char*msg,uint32_t len,uint32_t uid);
int32_t msg_receive(uint32_t qid,char*out,uint32_t maxLen,uint32_t uid);
}
