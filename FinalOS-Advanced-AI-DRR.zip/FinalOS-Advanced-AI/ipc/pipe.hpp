#pragma once
#include <stdint.h>
namespace IPC {
constexpr uint32_t PIPE_SIZE=1024,MAX_PIPES=8;
struct Pipe{bool used;uint32_t id,readers,writers,rpos,wpos,count;uint32_t blockedReaders[8],blockedWriters[8];uint8_t buffer[PIPE_SIZE];};
int32_t pipe_create(uint32_t*readFd,uint32_t*writeFd);
int32_t pipe_read(uint32_t id,char*buf,uint32_t len);
int32_t pipe_write(uint32_t id,const char*buf,uint32_t len);
int32_t pipe_close(uint32_t id,bool writer);
int32_t pipe_dup(uint32_t id,bool writer); // fork(): register that another process now also holds this end open
}
