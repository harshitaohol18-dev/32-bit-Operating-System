#include "pipe.hpp"
#include "../syscall/errors.hpp"
namespace IPC {
static Pipe p[MAX_PIPES];static uint32_t next=1;
static Pipe*find(uint32_t id){for(uint32_t i=0;i<MAX_PIPES;i++)if(p[i].used&&p[i].id==id)return &p[i];return nullptr;}
int32_t pipe_create(uint32_t*r,uint32_t*w){for(uint32_t i=0;i<MAX_PIPES;i++)if(!p[i].used){p[i].used=true;p[i].id=next++;p[i].readers=1;p[i].writers=1;p[i].rpos=p[i].wpos=p[i].count=0;for(int j=0;j<8;j++){p[i].blockedReaders[j]=0;p[i].blockedWriters[j]=0;}*r=p[i].id;*w=p[i].id;return SUCCESS;}return ERR_NO_MEMORY;}
int32_t pipe_read(uint32_t id,char*b,uint32_t n){Pipe*x=find(id);if(!x)return ERR_NOT_FOUND;if(!b)return ERR_INVALID_ARGUMENT;if(!x->count)return x->writers?ERR_QUEUE_EMPTY:ERR_PIPE_CLOSED;uint32_t k=n<x->count?n:x->count;for(uint32_t i=0;i<k;i++){b[i]=x->buffer[x->rpos];x->rpos=(x->rpos+1)%PIPE_SIZE;}x->count-=k;return k;}
int32_t pipe_write(uint32_t id,const char*b,uint32_t n){Pipe*x=find(id);if(!x)return ERR_NOT_FOUND;if(!b)return ERR_INVALID_ARGUMENT;if(!x->readers)return ERR_PIPE_CLOSED;uint32_t space=PIPE_SIZE-x->count;if(!space)return ERR_QUEUE_FULL;uint32_t k=n<space?n:space;for(uint32_t i=0;i<k;i++){x->buffer[x->wpos]=b[i];x->wpos=(x->wpos+1)%PIPE_SIZE;}x->count+=k;return k;}
int32_t pipe_close(uint32_t id,bool writer){Pipe*x=find(id);if(!x)return ERR_NOT_FOUND;if(writer){if(x->writers)x->writers--;}else{if(x->readers)x->readers--;}if(!x->readers&&!x->writers)x->used=false;return SUCCESS;}
int32_t pipe_dup(uint32_t id,bool writer){Pipe*x=find(id);if(!x)return ERR_NOT_FOUND;if(writer)x->writers++;else x->readers++;return SUCCESS;}
}
