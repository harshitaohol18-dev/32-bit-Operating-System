#include "message_queue.hpp"
#include "../syscall/errors.hpp"
namespace IPC {
struct Q{bool used;uint32_t id,owner,max,count,head,tail;uint32_t waitingSenders[8],waitingReceivers[8];char data[MAX_MESSAGES][MAX_MESSAGE_SIZE];uint32_t lens[MAX_MESSAGES];};
static Q q[MAX_QUEUES];static uint32_t nextId=1;
int32_t msg_queue_create(uint32_t owner,uint32_t max){if(max==0||max>MAX_MESSAGES)return ERR_INVALID_ARGUMENT;for(uint32_t i=0;i<MAX_QUEUES;i++)if(!q[i].used){q[i].used=true;q[i].id=nextId++;q[i].owner=owner;q[i].max=max;q[i].count=q[i].head=q[i].tail=0;return q[i].id;}return ERR_NO_MEMORY;}
static Q* find(uint32_t id){for(uint32_t i=0;i<MAX_QUEUES;i++)if(q[i].used&&q[i].id==id)return &q[i];return nullptr;}
int32_t msg_queue_destroy(uint32_t id,uint32_t uid){Q*x=find(id);if(!x)return ERR_NOT_FOUND;if(uid!=0&&uid!=x->owner)return ERR_PERMISSION;x->used=false;return SUCCESS;}
int32_t msg_send(uint32_t id,const char*m,uint32_t len,uint32_t uid){Q*x=find(id);if(!x)return ERR_NOT_FOUND;if(!m||len>MAX_MESSAGE_SIZE)return ERR_INVALID_ARGUMENT;if(x->owner!=uid&&uid!=0){}if(x->count>=x->max)return ERR_QUEUE_FULL;for(uint32_t i=0;i<len;i++)x->data[x->tail][i]=m[i];x->lens[x->tail]=len;x->tail=(x->tail+1)%x->max;x->count++;return SUCCESS;}
int32_t msg_receive(uint32_t id,char*out,uint32_t max,uint32_t uid){(void)uid;Q*x=find(id);if(!x)return ERR_NOT_FOUND;if(!out||max==0)return ERR_INVALID_ARGUMENT;if(!x->count)return ERR_QUEUE_EMPTY;uint32_t n=x->lens[x->head];if(n>=max)n=max-1;for(uint32_t i=0;i<n;i++)out[i]=x->data[x->head][i];out[n]=0;x->head=(x->head+1)%x->max;x->count--;return (int32_t)n;}
}
