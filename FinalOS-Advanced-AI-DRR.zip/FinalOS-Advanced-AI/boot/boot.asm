; boot.asm - Multiboot entry point.
; GRUB loads us already in 32-bit protected mode (paging off) per the
; Multiboot spec: this is where "Protected Mode" entry comes from.
; From here on, the kernel installs its OWN GDT (see arch/x86/gdt.cpp)
; instead of relying on GRUB's temporary descriptor table.
; Our job here: set up a boot stack and call into kernel_main().

MBALIGN     equ 1<<0
MEMINFO     equ 1<<1
FLAGS       equ MBALIGN | MEMINFO
MAGIC       equ 0x1BADB002
CHECKSUM    equ -(MAGIC + FLAGS)

section .multiboot
align 4
    dd MAGIC
    dd FLAGS
    dd CHECKSUM

section .bss
align 16
stack_bottom:
    resb 65536              ; 64KB boot stack
stack_top:

section .text
global _start
extern kernel_main

_start:
    cli
    mov esp, stack_top
    mov ebp, 0

    push ebx                ; multiboot info pointer (unused for now)
    push eax                ; multiboot magic

    call kernel_main

.hang:
    cli
    hlt
    jmp .hang
