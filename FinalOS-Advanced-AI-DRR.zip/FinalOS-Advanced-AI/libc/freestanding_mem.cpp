// freestanding_mem.cpp - even with -ffreestanding, GCC can still lower
// large struct/array zeroing or copying into calls to memcpy/memset/
// memmove/memcmp. We link with -nostdlib (no real libc), so without
// these symbols such code would fail to link. They simply forward to
// the KLib implementations used everywhere else in the kernel.
#include "kstd.hpp"

extern "C" void* memcpy(void* dst, const void* src, size_t n) {
    return KLib::memcpy(dst, src, n);
}

extern "C" void* memset(void* dst, int value, size_t n) {
    return KLib::memset(dst, value, n);
}

extern "C" void* memmove(void* dst, const void* src, size_t n) {
    return KLib::memmove(dst, src, n);
}

extern "C" int memcmp(const void* a, const void* b, size_t n) {
    const unsigned char* pa = (const unsigned char*)a;
    const unsigned char* pb = (const unsigned char*)b;
    for (size_t i = 0; i < n; i++) {
        if (pa[i] != pb[i]) return (int)pa[i] - (int)pb[i];
    }
    return 0;
}

extern "C" size_t strlen(const char* s) {
    return KLib::strlen(s);
}
