// kstd.cpp - tiny freestanding string/memory helpers.
#include "kstd.hpp"

namespace KLib {

    size_t strlen(const char* s) {
        size_t n = 0;
        while (s[n]) n++;
        return n;
    }

    int strcmp(const char* a, const char* b) {
        while (*a && (*a == *b)) { a++; b++; }
        return (unsigned char)*a - (unsigned char)*b;
    }

    int strncmp(const char* a, const char* b, size_t n) {
        for (size_t i = 0; i < n; i++) {
            if (a[i] != b[i] || a[i] == 0) return (unsigned char)a[i] - (unsigned char)b[i];
        }
        return 0;
    }

    char* strcpy(char* dst, const char* src) {
        size_t i = 0;
        while ((dst[i] = src[i]) != 0) i++;
        return dst;
    }

    char* strncpy(char* dst, const char* src, size_t n) {
        size_t i = 0;
        for (; i < n - 1 && src[i]; i++) dst[i] = src[i];
        for (; i < n; i++) dst[i] = 0;
        return dst;
    }

    char* strcat(char* dst, const char* src) {
        size_t dlen = strlen(dst);
        size_t i = 0;
        while ((dst[dlen + i] = src[i]) != 0) i++;
        return dst;
    }

    void* memset(void* dst, int value, size_t len) {
        uint8_t* d = (uint8_t*)dst;
        for (size_t i = 0; i < len; i++) d[i] = (uint8_t)value;
        return dst;
    }

    void* memcpy(void* dst, const void* src, size_t len) {
        uint8_t* d = (uint8_t*)dst;
        const uint8_t* s = (const uint8_t*)src;
        for (size_t i = 0; i < len; i++) d[i] = s[i];
        return dst;
    }

    void* memmove(void* dst, const void* src, size_t len) {
        uint8_t* d = (uint8_t*)dst;
        const uint8_t* s = (const uint8_t*)src;
        if (d < s) {
            for (size_t i = 0; i < len; i++) d[i] = s[i];
        } else {
            for (size_t i = len; i > 0; i--) d[i - 1] = s[i - 1];
        }
        return dst;
    }

    void itoa(uint32_t value, char* buf) {
        if (value == 0) { buf[0] = '0'; buf[1] = 0; return; }
        char tmp[12];
        int i = 0;
        while (value > 0) {
            tmp[i++] = (char)('0' + (value % 10));
            value /= 10;
        }
        int j = 0;
        while (i > 0) buf[j++] = tmp[--i];
        buf[j] = 0;
    }
}
