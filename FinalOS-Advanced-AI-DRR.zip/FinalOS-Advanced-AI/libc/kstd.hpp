#pragma once
// kstd.hpp - tiny freestanding string/memory helpers. No libc is
// linked (-nostdlib -ffreestanding), so every module that needs these
// operations shares this implementation instead of rolling its own.
#include <stdint.h>
#include <stddef.h>

namespace KLib {
    size_t strlen(const char* s);
    int strcmp(const char* a, const char* b);
    int strncmp(const char* a, const char* b, size_t n);
    char* strcpy(char* dst, const char* src);
    char* strncpy(char* dst, const char* src, size_t n);
    char* strcat(char* dst, const char* src);
    void* memset(void* dst, int value, size_t len);
    void* memcpy(void* dst, const void* src, size_t len);
    void* memmove(void* dst, const void* src, size_t len);

    // Decimal integer -> string. buf must be at least 12 bytes.
    void itoa(uint32_t value, char* buf);
}
