# PART3A_HANDOFF

## Finding about the input
The zip held only the kernel (`FinalOS-Advanced-AI/`). There was **no GUI** and **no `FinalOS-Advanced-AI-CaseStudy` directory**; the "case study" was the AI-Adaptive scheduler (`ai/`) + README. Nothing was rewritten; everything was extended.

## Algorithm
`AI::drrDecide(DrrInput{burstTicks,waitTicks,priority,runnable})` -> `DrrDecision{quantum,baseQuantum,cls,flags}`:
classify (existing tree) -> class quantum (existing table) -> load (`runnable>=6` x3/4, `<=1` x2) -> priority (`<=2` +2, `>=8` -1) -> clamp [2,20]. `flags` records fired rules; `drrExplain()` prints the reason. Same code runs in kernel and simulator.

## Changed / new files
New: `ai/dynamic_rr.{hpp,cpp}`, `casestudy/{drr_sim.cpp,Makefile,CASESTUDY_REPORT.md,results/*}`, this file.
Modified: `scheduler/task.hpp` (measurement + decision fields), `scheduler/scheduler.cpp` (AI mode now calls `drrDecide`; per-tick `readyTicks`/`burstRun`; `burstRun` reset in `sleep()`; new `getSystemTicks/getDrrDecisions/resetDrrStats`), `scheduler/scheduler.hpp`, `shell/shell.cpp` (`drr`, `drr reset`, help line), `Makefile` (adds dynamic_rr.cpp), `README.md`.
Behavior change to know: previously AI mode classified with `waitTicks` always 0 (it was zeroed before the call) and avg-burst; it now uses real wait and `burstRun`. `ps` WORKLOAD column uses `burstRun`. All other modes (RR, priority, FCFS), fs, ring-3, IPC, auth untouched.

## Checks done
Kernel objects compile and `kernel.elf` links (g++ -m32). Simulator builds and ran 7 scenarios x 30 seeds. **Not done:** booting in QEMU (not installed), so the `drr` command and AI mode are untested at runtime.

## Part 3B suggestions
1. Boot in QEMU; add a kernel benchmark (spawn N CPU-bound + N sleeping kernel tasks, run under `scheduler rr` vs `ai`, print `drr` output) -> first REAL measurements; report separately from simulation.
2. Fix misclassification of fresh tasks (burst=0) and sub-burst quanta; tune on some seeds and **evaluate on held-out seeds**; consider an EWMA of past burst lengths.
3. Replace unreachable thresholds (426, 552) with kernel-scale values, or train a real model (needs data collection + script; none exists now) and document it as such.
4. Optional: GUI/report visualization (none existed), per-class breakdown charts from `results.csv`.

Run: `cd casestudy && make results`. Kernel: `make`, then `scheduler ai`, `drr`.
