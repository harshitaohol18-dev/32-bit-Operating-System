#pragma once
// demo.hpp - runtime on/off switch for the background demo tasks'
// console chatter. They keep running/sleeping/switching either way
// (so `ps`/`metrics` show live activity) - this only gates whether
// they print, so they don't fight the shell for the screen.
// Default is OFF so the shell is usable the moment you log in.
namespace Demo {
    void setVerbose(bool on);
    bool isVerbose();
}
