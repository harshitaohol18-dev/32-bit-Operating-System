#include "demo.hpp"
namespace Demo {
    static volatile bool verbose = false;
    void setVerbose(bool on) { verbose = on; }
    bool isVerbose() { return verbose; }
}
