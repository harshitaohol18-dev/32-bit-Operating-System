#pragma once
// monitor.hpp - process monitor: `ps`-style listing plus system-wide
// performance metrics (CPU utilization, context-switch rate, etc.),
// built on top of Scheduler's task table and Timer's tick count.
namespace Monitor {
    void displayProcesses();
    void displaySystemInfo();
    void displayPerformanceMetrics();
}
