// monitor.cpp - process monitor built on Scheduler's task table.
#include "monitor.hpp"
#include "../scheduler/scheduler.hpp"
#include "../drivers/vga.hpp"
#include "../drivers/timer.hpp"
#include "../mm/heap.hpp"
#include "../libc/kstd.hpp"

namespace Monitor {

    static const char* stateName(Scheduler::TaskState s) {
        switch (s) {
            case Scheduler::TaskState::NEW:        return "NEW";
            case Scheduler::TaskState::READY:      return "READY";
            case Scheduler::TaskState::RUNNING:    return "RUNNING";
            case Scheduler::TaskState::BLOCKED:    return "BLOCKED";
            case Scheduler::TaskState::TERMINATED: return "TERMINATED";
        }
        return "UNKNOWN";
    }

    static void printPadded(const char* s, int width) {
        VGA::print(s);
        int len = (int)KLib::strlen(s);
        for (int i = len; i < width; i++) VGA::print(" ");
    }

    void displayProcesses() {
        bool ai = Scheduler::getMode() == Scheduler::Mode::AI_ADAPTIVE;

        VGA::print("\n");
        VGA::set_color(VGA::YELLOW, VGA::BLACK);
        if (ai) {
            VGA::print("PID  NAME                 STATE       PRIO  CPU(ticks)  SWITCHES  WORKLOAD        QTM\n");
        } else {
            VGA::print("PID  NAME                 STATE       PRIO  CPU(ticks)  SWITCHES\n");
        }
        VGA::set_color(VGA::WHITE, VGA::BLACK);
        VGA::print("---------------------------------------------------------------------------------------\n");

        for (uint32_t i = 0; i < Scheduler::MAX_TASKS; i++) {
            Scheduler::Task* t = Scheduler::getTaskSlot(i);
            if (!t || !t->inUse) continue;

            char buf[12];
            KLib::itoa(t->pid, buf);
            printPadded(buf, 5);

            printPadded(t->name, 21);
            printPadded(stateName(t->state), 12);

            KLib::itoa(t->priority, buf);
            printPadded(buf, 6);

            KLib::itoa(t->cpuTicks, buf);
            printPadded(buf, 12);

            KLib::itoa(t->contextSwitches, buf);
            if (!ai) {
                VGA::print(buf);
                VGA::print("\n");
                continue;
            }
            printPadded(buf, 10);

            printPadded(Scheduler::classifyTaskWorkload(t), 16);
            KLib::itoa(t->aiQuantum, buf);
            VGA::print(buf);
            VGA::print("\n");
        }

        VGA::print("\nActive: ");
        VGA::print_dec(Scheduler::getActiveCount());
        VGA::print("   Total created: ");
        VGA::print_dec(Scheduler::getTotalCreated());
        VGA::print("\n");
    }

    void displaySystemInfo() {
        VGA::print("\n============= SYSTEM INFORMATION =============\n");
        VGA::print("Uptime: ");
        VGA::print_dec(Timer::get_time_sec());
        VGA::print("s (");
        VGA::print_dec(Timer::get_ticks());
        VGA::print(" ticks @ ");
        VGA::print_dec(Timer::get_frequency());
        VGA::print("Hz)\n");

        VGA::print("Active processes: ");
        VGA::print_dec(Scheduler::getActiveCount());
        VGA::print("   Total created: ");
        VGA::print_dec(Scheduler::getTotalCreated());
        VGA::print("\n");

        Scheduler::Task* cur = Scheduler::currentTask();
        VGA::print("Current process: ");
        if (cur) {
            VGA::print(cur->name);
            VGA::print(" (PID ");
            VGA::print_dec(cur->pid);
            VGA::print(")\n");
        } else {
            VGA::print("none\n");
        }

        VGA::print("\n============= SCHEDULER =============\n");
        VGA::print("Policy: ");
        VGA::print(Scheduler::getModeName());
        VGA::print("\nQuantum: ");
        VGA::print_dec(Scheduler::getQuantum());
        VGA::print(" ticks\nTotal context switches: ");
        VGA::print_dec(Scheduler::getTotalContextSwitches());
        VGA::print("\n");

        Heap::Stats hs = Heap::getStats();
        VGA::print("\n============= MEMORY =============\n");
        VGA::print("Heap total: ");
        VGA::print_dec(hs.totalBytes / 1024);
        VGA::print(" KB   used: ");
        VGA::print_dec(hs.usedBytes / 1024);
        VGA::print(" KB   free: ");
        VGA::print_dec(hs.freeBytes / 1024);
        VGA::print(" KB\n");
        VGA::print("Blocks: ");
        VGA::print_dec(hs.blockCount);
        VGA::print(" (");
        VGA::print_dec(hs.freeBlockCount);
        VGA::print(" free)\n");
    }

    void displayPerformanceMetrics() {
        uint32_t ticks = Timer::get_ticks();
        uint32_t sw = Scheduler::getTotalContextSwitches();
        uint32_t sec = Timer::get_time_sec();

        VGA::print("\n============= PERFORMANCE METRICS =============\n");
        VGA::print("Context switches: ");
        VGA::print_dec(sw);
        VGA::print("\nContext switches/sec: ");
        VGA::print_dec(sec > 0 ? sw / sec : 0);
        VGA::print("\nScheduler ticks: ");
        VGA::print_dec(ticks);
        VGA::print("\nActive/Total processes: ");
        VGA::print_dec(Scheduler::getActiveCount());
        VGA::print("/");
        VGA::print_dec(Scheduler::getTotalCreated());
        VGA::print("\n\nPer-process CPU ticks:\n");

        for (uint32_t i = 0; i < Scheduler::MAX_TASKS; i++) {
            Scheduler::Task* t = Scheduler::getTaskSlot(i);
            if (!t || !t->inUse) continue;
            VGA::print("  ");
            VGA::print(t->name);
            VGA::print(": ");
            VGA::print_dec(t->cpuTicks);
            VGA::print(" ticks, ");
            VGA::print_dec(t->contextSwitches);
            VGA::print(" switches\n");
        }
    }
}
