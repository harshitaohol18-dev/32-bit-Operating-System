// keyboard.cpp - PS/2 keyboard driver. Registers itself for IRQ1 via
// the shared Interrupts dispatcher instead of owning a raw ISR.
#include "keyboard.hpp"
#include "../arch/x86/interrupts.hpp"
#include <stdint.h>

static inline uint8_t inb(uint16_t port) {
    uint8_t r; asm volatile ("inb %1, %0" : "=a"(r) : "Nd"(port)); return r;
}

namespace Keyboard {

    static char buffer[256];
    static volatile int head = 0;
    static volatile int tail = 0;

    static const char normal_keys[128] = {
        0,    0,
        '1','2','3','4','5','6','7','8','9','0','-','=',
        0,    0,
        'q','w','e','r','t','y','u','i','o','p','[',']',
        0,    0,
        'a','s','d','f','g','h','j','k','l',';','\'','`',
        0,
        '\\','z','x','c','v','b','n','m',',','.','/',
        0,
        '*',
        0,
        ' ',
        0,
        0,0,0,0,0,0,0,0,0,0,
        0,
        0,
        '7','8','9','-',
        '4','5','6','+',
        '1','2','3','0',
        '.',
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    };

    static const char shifted_keys[128] = {
        0,0,'!','@','#','$','%','^','&','*','(',')','_','+',0,0,
        'Q','W','E','R','T','Y','U','I','O','P','{','}',0,0,
        'A','S','D','F','G','H','J','K','L',':','"','~',0,
        '|','Z','X','C','V','B','N','M','<','>','?',0,'*',0,' '
    };

    static bool shift_pressed = false;
    static bool caps_lock = false;
    static bool ctrl_pressed = false;
    static bool alt_pressed = false;

    static void add_to_buffer(char c) {
        int next = (head + 1) % 256;
        if (next != tail) {
            buffer[head] = c;
            head = next;
        }
    }

    static void irqHandler(Interrupts::Registers* /*regs*/) {
        uint8_t scan_code = inb(0x60);
        uint8_t key = scan_code & 0x7F;
        bool released = (scan_code & 0x80) != 0;

        if (key == 0x2A || key == 0x36) { shift_pressed = !released; return; }
        if (key == 0x1D) { ctrl_pressed = !released; return; }
        if (key == 0x38) { alt_pressed = !released; return; }
        if (key == 0x3A && !released) { caps_lock = !caps_lock; return; }
        if (released) return;

        char character = 0;
        if (key == 0x1C) character = '\n';
        else if (key == 0x0E) character = '\b';
        else if (key == 0x0F) character = '\t';
        else {
            character = (shift_pressed || caps_lock) ? shifted_keys[key] : normal_keys[key];
            if (character == 0) character = normal_keys[key];
        }

        if (character != 0) add_to_buffer(character);
    }

    void init() {
        head = 0;
        tail = 0;
        shift_pressed = caps_lock = ctrl_pressed = alt_pressed = false;
        Interrupts::registerIRQHandler(1, irqHandler);
    }

    char get_char() {
        while (head == tail) {
            asm volatile ("sti; hlt");
        }
        char c = buffer[tail];
        tail = (tail + 1) % 256;
        return c;
    }

    bool has_char() { return head != tail; }

    char peek_char() {
        if (head == tail) return 0;
        return buffer[tail];
    }

    void clear_buffer() { head = 0; tail = 0; }
}
