// vga.cpp - VGA text-mode console driver + the kprint/kprintDec/kprintHex
// glue functions that the arch/scheduler/filesystem modules call.
#include "vga.hpp"
#include "serial.hpp"

namespace VGA {

    const int WIDTH = 80;
    const int HEIGHT = 25;
    const uint32_t VIDEO_ADDR = 0xB8000;

    static uint16_t* const video_memory = (uint16_t*)VIDEO_ADDR;
    static int cursor_x = 0;
    static int cursor_y = 0;
    static uint8_t text_color = 0x0F;

    static inline uint16_t make_char(char c, uint8_t color) {
        return (uint16_t)((color << 8) | (uint8_t)c);
    }

    static inline void outb(uint16_t port, uint8_t value) {
        asm volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
    }

    static void update_hardware_cursor() {
        uint16_t position = (uint16_t)(cursor_y * WIDTH + cursor_x);
        outb(0x3D4, 0x0F);
        outb(0x3D5, position & 0xFF);
        outb(0x3D4, 0x0E);
        outb(0x3D5, (position >> 8) & 0xFF);
    }

    static void scroll() {
        for (int i = 0; i < (HEIGHT - 1) * WIDTH; i++) {
            video_memory[i] = video_memory[i + WIDTH];
        }
        uint16_t blank = make_char(' ', text_color);
        for (int i = (HEIGHT - 1) * WIDTH; i < HEIGHT * WIDTH; i++) {
            video_memory[i] = blank;
        }
    }

    void clear() {
        uint16_t blank = make_char(' ', text_color);
        for (int i = 0; i < WIDTH * HEIGHT; i++) video_memory[i] = blank;
        cursor_x = 0;
        cursor_y = 0;
        update_hardware_cursor();
    }

    void putchar(char c) {
        if (c == '\n') {
            cursor_x = 0;
            cursor_y++;
        } else if (c == '\r') {
            cursor_x = 0;
        } else if (c == '\b') {
            if (cursor_x > 0) {
                cursor_x--;
                video_memory[cursor_y * WIDTH + cursor_x] = make_char(' ', text_color);
            }
        } else if (c == '\t') {
            for (int i = 0; i < 4; i++) putchar(' ');
            return;
        } else if (c >= 32 && c <= 126) {
            video_memory[cursor_y * WIDTH + cursor_x] = make_char(c, text_color);
            cursor_x++;
        }

        if (cursor_x >= WIDTH) {
            cursor_x = 0;
            cursor_y++;
        }
        if (cursor_y >= HEIGHT) {
            scroll();
            cursor_y = HEIGHT - 1;
        }
        update_hardware_cursor();
    }

    void print(const char* str) {
        for (int i = 0; str[i] != '\0'; i++) putchar(str[i]);
        Serial::write(str); // mirror everything to COM1 for headless debugging
    }

    void print_dec(uint32_t num) {
        if (num == 0) { print("0"); return; }
        char buffer[12];
        int i = 10;
        buffer[11] = '\0';
        while (num > 0 && i >= 0) {
            buffer[i--] = (char)('0' + (num % 10));
            num /= 10;
        }
        print(&buffer[i + 1]);
    }

    void print_hex(uint32_t num) {
        const char* hex_chars = "0123456789ABCDEF";
        char buffer[9];
        buffer[8] = '\0';
        for (int i = 7; i >= 0; i--) {
            buffer[i] = hex_chars[num & 0x0F];
            num >>= 4;
        }
        print("0x");
        print(buffer);
    }

    void set_color(uint8_t foreground, uint8_t background) {
        text_color = (uint8_t)((background << 4) | foreground);
    }

    uint8_t get_color() { return text_color; }

    void set_cursor(int x, int y) {
        if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {
            cursor_x = x;
            cursor_y = y;
            update_hardware_cursor();
        }
    }

    void get_cursor(int& x, int& y) { x = cursor_x; y = cursor_y; }

    void init() {
        Serial::init();
        clear();
        set_color(WHITE, BLACK);
        set_cursor(0, 0);
    }
}

// ---- glue for modules that only know about kprint/kprintDec/kprintHex ----
extern "C" void kprint(const char* str) { VGA::print(str); }
extern "C" void kprintDec(uint32_t value) { VGA::print_dec(value); }
extern "C" void kprintHex(uint32_t value) { VGA::print_hex(value); }
