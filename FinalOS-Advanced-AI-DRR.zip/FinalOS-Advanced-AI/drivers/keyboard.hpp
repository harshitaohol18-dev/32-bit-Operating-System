#pragma once
// keyboard.hpp - PS/2 keyboard driver (IRQ1), US layout.
namespace Keyboard {
    void init();
    char get_char();     // blocks (halts) until a key is available
    bool has_char();
    char peek_char();
    void clear_buffer();
}
