#pragma once
// serial.hpp - minimal COM1 driver, used only to mirror console output
// so the OS can be verified headlessly (qemu -serial file:...). Not
// one of the graded features; purely a debugging aid.
namespace Serial {
    void init();
    void write(const char* str);
}
