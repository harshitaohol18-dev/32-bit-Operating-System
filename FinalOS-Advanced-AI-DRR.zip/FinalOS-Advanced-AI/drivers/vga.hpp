#pragma once
// vga.hpp - VGA text-mode console driver (80x25, 0xB8000).
#include <stdint.h>

namespace VGA {

    enum Colors {
        BLACK = 0, BLUE = 1, GREEN = 2, CYAN = 3, RED = 4, MAGENTA = 5,
        BROWN = 6, LIGHT_GRAY = 7, DARK_GRAY = 8, LIGHT_BLUE = 9,
        LIGHT_GREEN = 10, LIGHT_CYAN = 11, LIGHT_RED = 12,
        LIGHT_MAGENTA = 13, YELLOW = 14, WHITE = 15
    };

    void init();
    void clear();
    void putchar(char c);
    void print(const char* str);
    void print_dec(uint32_t num);
    void print_hex(uint32_t num);
    void set_color(uint8_t foreground, uint8_t background = BLACK);
    uint8_t get_color();
    void set_cursor(int x, int y);
    void get_cursor(int& x, int& y);
}
