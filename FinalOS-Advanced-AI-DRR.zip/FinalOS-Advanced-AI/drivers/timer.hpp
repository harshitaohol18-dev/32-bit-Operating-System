#pragma once
// timer.hpp - PIT (Programmable Interval Timer) driver on IRQ0. Owns
// the system tick counter and drives the scheduler's preemption tick.
#include <stdint.h>

namespace Timer {
    void init(uint32_t frequencyHz);
    uint32_t get_ticks();
    uint32_t get_time_ms();
    uint32_t get_time_sec();
    uint32_t get_frequency();
    void set_callback(void (*callback)());   // optional extra per-tick hook
    void sleep_ticks(uint32_t ticks);         // busy-wait (only for boot-time use)
}
