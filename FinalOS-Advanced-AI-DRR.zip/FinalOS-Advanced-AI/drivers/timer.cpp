// timer.cpp - programs PIT channel 0 for a periodic IRQ0, keeps the
// system tick count, and drives Scheduler::tick() on every tick.
#include "timer.hpp"
#include "../arch/x86/interrupts.hpp"
#include "../scheduler/scheduler.hpp"
#include "../process/process.hpp"

static inline void outb(uint16_t port, uint8_t value) {
    asm volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

namespace Timer {

    static volatile uint32_t system_ticks = 0;
    static uint32_t timer_frequency = 100;
    static void (*extra_callback)() = nullptr;

    static void irqHandler(Interrupts::Registers* regs) {
        system_ticks++;
        if (!Process::handleTimer(regs)) Scheduler::tick();
        if (extra_callback) extra_callback();
    }

    void init(uint32_t frequency) {
        timer_frequency = frequency;
        system_ticks = 0;

        uint32_t divisor = 1193182 / frequency;
        outb(0x43, 0x36);
        outb(0x40, divisor & 0xFF);
        outb(0x40, (divisor >> 8) & 0xFF);

        Interrupts::registerIRQHandler(0, irqHandler);
    }

    uint32_t get_ticks() { return system_ticks; }
    uint32_t get_time_ms() { return (system_ticks * 1000) / timer_frequency; }
    uint32_t get_time_sec() { return system_ticks / timer_frequency; }
    uint32_t get_frequency() { return timer_frequency; }
    void set_callback(void (*callback)()) { extra_callback = callback; }

    void sleep_ticks(uint32_t ticks) {
        uint32_t target = system_ticks + ticks;
        while (system_ticks < target) {
            asm volatile ("sti; hlt");
        }
    }
}
