// serial.cpp - minimal polling COM1 (0x3F8) driver for debug mirroring.
#include "serial.hpp"
#include <stdint.h>

#define COM1 0x3F8

static inline void outb(uint16_t port, uint8_t val) {
    asm volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}
static inline uint8_t inb(uint16_t port) {
    uint8_t r; asm volatile ("inb %1, %0" : "=a"(r) : "Nd"(port)); return r;
}

namespace Serial {

    void init() {
        outb(COM1 + 1, 0x00); // disable interrupts
        outb(COM1 + 3, 0x80); // enable DLAB
        outb(COM1 + 0, 0x03); // divisor low  (38400 baud)
        outb(COM1 + 1, 0x00); // divisor high
        outb(COM1 + 3, 0x03); // 8 bits, no parity, one stop bit
        outb(COM1 + 2, 0xC7); // enable FIFO, clear, 14-byte threshold
        outb(COM1 + 4, 0x0B); // IRQs disabled, RTS/DSR set
    }

    static bool transmitEmpty() { return inb(COM1 + 5) & 0x20; }

    static void putc(char c) {
        for (int spin = 0; spin < 100000 && !transmitEmpty(); spin++) {}
        outb(COM1, (uint8_t)c);
    }

    void write(const char* str) {
        for (int i = 0; str[i]; i++) {
            if (str[i] == '\n') putc('\r');
            putc(str[i]);
        }
    }
}
