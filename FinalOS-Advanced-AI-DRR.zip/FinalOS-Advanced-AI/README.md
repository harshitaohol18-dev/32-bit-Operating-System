# 32-bit Protected-Mode OS — Advanced + AI Edition

This build merges three separate deliverables into one kernel:

1. **`FinalOS-extended-32bit.zip`** — an advanced extension of the base
   OS (real ring-3 user mode with a TSS, process fork/exec, IPC
   pipes + message queues, and a user/permissions/auth layer).
2. **`os_project.zip`** — a host-side research prototype comparing a
   fixed-quantum Round Robin scheduler against an "AI-Assisted RR"
   that adapts each process's quantum to its classified workload.
3. **`Person1_Deliverables`** — the ML side of that research: a
   decision tree (scikit-learn) trained to classify workload type
   from scheduler telemetry.

A kernel can't load a `.pkl` file or run scikit-learn, so the trained
tree's actual decision logic was hand-ported into plain C++
(`ai/classifier.cpp`) and wired into the scheduler as a new,
selectable **AI-Adaptive** mode — a real scheduling policy, not a
simulation bolted on the side.

## Dynamic Round Robin case study (new)
`scheduler ai` now uses an explainable Dynamic RR decision (`ai/dynamic_rr.cpp`): tree classifier -> class quantum -> load/priority rules -> clamp. Type `drr` to see each task's last decision with its reason plus real kernel counters (CPU/ready ticks, response, dispatches).
Offline comparison vs standard RR (simulation, 7 scenarios x 30 seeds): `casestudy/CASESTUDY_REPORT.md`, `casestudy/results/`; rebuild with `cd casestudy && make results`. Summary: Dynamic RR improves response time but, in this first untuned version, worsens waiting/turnaround in mixed workloads. The classifier is a hand-ported tree (no trained model file ships here); simulated results are not kernel measurements.

## Quick start

```sh
sudo apt-get install nasm xorriso grub-pc-bin grub-common mtools \
                      gcc-multilib g++-multilib qemu-system-x86
make
make run
```

Log in with **root / root** (or **user / user** for a non-root
account), then `help` for the command list.

## What's new in this build

### Ring-3 user mode
Real privilege-level-3 processes: a TSS for the ring3->ring0 stack
switch, per-process page mappings (code/rodata at a fixed user
window, a private stack page), `fork()`, `exit()`, and an `int 0x80`
syscall ABI usable from ring 3. Try:
```
run init               # prints its own PID/UID, then a blocked write
                        # to kernel memory shows the protection works
run pipe_test           # fork() + a pipe: child blocks until parent writes
run msg_sender          # fork() + a message queue
run scheduler_test      # a ring-3 process yielding under the scheduler
run permission_test     # a normal user's file-permission check
```

### IPC
Non-blocking pipes (`ipc/pipe.cpp`) and message queues
(`ipc/message_queue.cpp`), both usable from ring 3 via syscalls.

### Users, auth, permissions
A login prompt (SHA-256 password hashing, `user/auth.cpp`), uid/gid,
and a Unix-style permission model (`chmod`, `chown`, `stat`) enforced
on file open/read/write. `chmod`/`chown` used to crash the kernel from
the interactive shell; see item 6 under **Real bugs found and fixed**
below for the root cause and the fix.

### AI-Adaptive scheduling
`scheduler ai` switches the scheduler into a mode where task order is
still round robin, but each task's time quantum is set by classifying
its recent behavior (`ai/classifier.cpp`) into one of six workload
types (Short Running, Interactive, I/O Intensive, Long Running, CPU
Intensive, Background) and mapping that to a quantum
(`ai/adaptive_quantum.cpp`). `ps` shows a live `WORKLOAD`/`QTM` column
while this mode is active:
```
scheduler ai
ps
```
See "AI-Adaptive Scheduling: provenance" below for exactly how the
original decision tree maps onto this code.

### Everything from the base OS
GDT/IDT/interrupts, paging, a heap allocator, round robin / priority
(aging) / FCFS / AI-adaptive scheduling, a persistent block filesystem
with directories, and a process monitor - all still present, see
`help` for the full command list.

## Real bugs found and fixed during this integration

Each of these was a genuine defect, confirmed by actually booting the
merged kernel in QEMU and driving the shell interactively (scripted
keystrokes via the QEMU monitor) - not just a compile pass.

1. **Ring-3 user stack mapped outside the paged range.** The user
   stack's virtual address was the traditional `0xBFFFE000` (~3GB,
   the classic higher-half split), but this kernel's paging only
   manages page tables for the low 32MB it identity-maps. Mapping the
   user stack there silently failed, so the very first ring-3 process
   page-faulted on its own stack before executing one instruction.
   Fixed by moving the user stack window to `0x01FFF000`, inside the
   actual identity-mapped range (`arch/x86/paging.hpp`).
2. **`fork()` gave the child a stale/zeroed register frame.**
   `forkCurrent()` copied the parent's saved frame into the child
   *before* refreshing that frame with the live syscall-time
   registers - so a process forking for the first time (frame never
   yet touched) handed its child `EIP=0`. The child would resume by
   jumping to address 0 and instantly page-fault. Fixed by saving the
   live frame first, then copying (`process/process.cpp`).
3. **Pipe reference counts didn't survive `fork()`.** A pipe's
   reader/writer counts start at 1 each; `fork()` duplicates the fd
   table but never bumped them, so the first `close()` by *either*
   parent or child - even closing the end it didn't need - zeroed
   that count out from under the other process, which still held its
   own valid copy of the fd it actually needed. Result: `pipe_write`
   silently failed (`readers==0`) and the child's read loop spun in
   `yield()` forever, permanently hanging the shell (ring-3 scheduling
   monopolizes the timer interrupt while any ring-3 process is alive,
   so once one spins forever, nothing else in the OS runs again - not
   even the shell that launched it). Fixed with a `pipe_dup()` call in
   `forkCurrent()` that increments the correct count per inherited fd
   (`ipc/pipe.cpp`, `process/process.cpp`).
4. **Demo tasks flooding the shell.** Two background kernel tasks
   printed on every wake-up, fighting the shell for the screen.
   Fixed the same way as in the previous version of this OS: silent
   by default (`demo/demo.hpp`), toggle with `demo on` / `demo off`.
5. **`-lgcc` link failure without 32-bit multilib.** Dropped from the
   Makefile; this kernel doesn't need it (no 64-bit arithmetic, and
   `memcpy`/`memset`/etc. are supplied directly).
6. **`chmod`/`chown` crashed the kernel.** This was previously listed
   under Known Issues as unresolved; it's now fixed. Root cause: a
   task's kernel stack (`TASK_STACK_SIZE`) was 8KB, and the shell's
   `cat` command had `char b[8192]` as a plain stack-local buffer in
   `fsCmd()`. A C++ function's stack frame size is fixed once, at
   function entry, for whatever the *largest* simultaneously-needed
   locals are across all of its branches - not re-sized per branch -
   so *every* call to `fsCmd()` (`ls`, `touch`, `chmod`, all of them)
   reserved that entire 8KB buffer's worth of stack up front, even
   though only `cat` ever touched it. Confirmed by compiling the
   original code and disassembling it: `fsCmd`'s prologue was
   `sub esp, 0x2008` unconditionally - on an 8KB task stack, that's
   already the whole budget gone before the function body even runs.
   `chmod`/`chown` were the commands that actually crashed because
   their call chain nests deepest past that point
   (`fsCmd -> FileSystem::chmod -> savePerms -> Disk::writeSector`),
   which was enough to write past the end of the task's stack array
   into adjacent `.bss`/heap memory - matching the originally-reported
   symptom of a fault address/EIP landing in `.bss`/heap rather than
   at a clean out-of-bounds index. This is also why it only showed up
   from the interactive shell: `kernel_main()` runs on the 64KB boot
   stack (`boot/boot.asm`), only the "shell" task (and other
   `Scheduler::createTask` tasks) use the small `TASK_STACK_SIZE`
   stack. The earlier `cli`/`sti` guard added around the ATA PIO
   handshake (`filesystem/disk.cpp`) is still in place as a genuinely
   good defensive measure for a polling disk driver under a preemptive
   scheduler, but it was never the cause of this particular crash,
   which is why it didn't fix it. Two changes, both in this build:
   `shell/shell.cpp`'s `cat` buffer is now `static` (lives in `.bss`,
   costs zero stack), and `TASK_STACK_SIZE` (`scheduler/task.hpp`) was
   raised from 8KB to 16KB for headroom, since ring-0 IRQs in this
   kernel preempt directly onto whichever stack is currently active
   (there's no separate interrupt stack; `TSS.esp0` is only used for
   ring3->ring0 transitions) and can stack a frame on top of whatever
   a kernel task was doing at the time.

## Known issues (not fixed - please read before relying on these)

- Ring-3 processes are cooperative-within-preemptive: while any
  ring-3 process is alive, ring-3 scheduling takes over the timer
  interrupt entirely (this is by design in the extended kernel this
  build is based on), so a ring-3 process that never exits or never
  makes progress will hang the whole system, not just itself. All the
  bundled test apps (`init`, `pipe_test`, `msg_sender`,
  `scheduler_test`, `permission_test`) terminate correctly.
- No SMP, no ELF loader for arbitrary user binaries (the four ring-3
  apps are built into the kernel image at fixed addresses), no
  network stack.

## AI-Adaptive Scheduling: provenance

The original decision tree (`Person1_Deliverables/tree_rules.txt`)
used five features: `CPU_time`, `Wait`, `Priority`, `RQ_len`, and
`MemKB`. This kernel doesn't track per-task memory use, so any split
where both branches led to the same class regardless of `MemKB`
(there were several - typical of a small tree fit on synthetic data)
was collapsed to that shared class, and splits where `MemKB` was the
*only* distinguishing feature resolved to the branch's majority
class. The surviving splits map directly onto values this kernel
already tracks per task:

| Tree feature | Kernel value used |
|---|---|
| `CPU_time` | average ticks run per scheduling turn so far (`cpuTicks / contextSwitches`) |
| `Wait` | ticks spent READY-but-not-running (the existing aging counter) |
| `Priority` | task priority (lower number = more urgent, this kernel's convention) |
| `RQ_len` | number of currently READY/RUNNING tasks |

The resulting six-way classification (`ai/classifier.cpp`) is mapped
to a quantum (`ai/adaptive_quantum.cpp`) using the same values the
`os_project` prototype's `adaptive_quantum.cpp` used for the classes
it shared (Interactive=4, CPU Intensive=12, Short Running=3, Long
Running=12), with the new "I/O Intensive" class (which didn't exist
in that simpler prototype) given the same quantum as its fallback
bucket ("Background"=6).

## Repository layout

```
boot/               Multiboot entry point
arch/x86/           GDT, TSS, IDT, PIC, interrupt dispatch, paging
drivers/            VGA, keyboard, timer, serial (debug mirror)
mm/                 kmalloc/kfree heap allocator
libc/               freestanding string/memory helpers
scheduler/          Task struct, RR/Priority/FCFS/AI-Adaptive scheduler, context switch
ai/                 workload classifier + adaptive quantum (see above)
process/            ring-3 PCB, fork/exec, syscalls dispatch glue
syscall/            int 0x80 ABI (kernel side + user-mode wrappers)
ipc/                pipes, message queues
user/               accounts, SHA-256 auth, Unix-style permissions
filesystem/         block filesystem + ATA PIO disk driver
demo/               background demo-task chatter toggle
monitor/            `ps`/`info`/`metrics`
shell/              the interactive shell
```

## Building with a real cross-compiler

This Makefile defaults to your distro's `g++ -m32` (works fine, no
cross-compiler needed). To use a real `i686-elf-g++` instead:
```sh
make CXX=i686-elf-g++
```
