#include "adaptive_quantum.hpp"

namespace AI {

    static uint32_t rawQuantum(Workload w) {
        switch (w) {
            case Workload::Interactive:   return 4;
            case Workload::CPUIntensive:  return 12;
            case Workload::ShortRunning:  return 3;
            case Workload::LongRunning:   return 12;
            case Workload::IOIntensive:   return 6;
            case Workload::Background:    return 6;
        }
        return 6;
    }

    uint32_t getAdaptiveQuantum(Workload w) {
        uint32_t q = rawQuantum(w);
        if (q == 0 || q > 20) return 6; // validateQuantum()-style fallback
        return q;
    }
}
