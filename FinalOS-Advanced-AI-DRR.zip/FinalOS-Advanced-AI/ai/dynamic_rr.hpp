#pragma once
// dynamic_rr.hpp - explainable Dynamic Round Robin quantum decision.
//
// One freestanding implementation shared by the kernel scheduler
// (AI-Adaptive mode) and the host-side case-study simulator
// (casestudy/drr_sim.cpp), so both run literally the same decision code.
//
// Layers (be precise when describing results):
//   1. AI::classify()  - hand-ported decision tree (ai/classifier.cpp).
//                        Its provenance is documented in README; no
//                        model file or training data ships in this repo.
//   2. Rule layer here - hand-written heuristic adjustments (load,
//                        priority, clamp). NOT learned.
//   3. Only features observable by a real kernel are used (no oracle
//      knowledge of remaining burst time).
#include <stdint.h>
#include "classifier.hpp"

namespace AI {

    enum DrrFlag : uint32_t {
        DRR_LOAD_SHRINK   = 1,   // many runnable tasks -> shorter slice
        DRR_ALONE_GROW    = 2,   // nobody else runnable -> longer slice
        DRR_PRIO_BOOST    = 4,   // urgent priority -> longer slice
        DRR_PRIO_PENALTY  = 8,   // low priority -> shorter slice
        DRR_CLAMP_LO      = 16,
        DRR_CLAMP_HI      = 32,
    };

    constexpr uint32_t DRR_MIN_Q = 2, DRR_MAX_Q = 20;
    constexpr uint32_t DRR_HIGH_LOAD = 6;   // runnable tasks (incl. this one)

    struct DrrInput {
        uint32_t burstTicks;   // CPU ticks run since this task last blocked
        uint32_t waitTicks;    // ticks it just spent READY before this dispatch
        uint32_t priority;     // 0 (urgent) .. 10
        uint32_t runnable;     // READY + RUNNING tasks, including this one
    };

    struct DrrDecision {
        uint32_t quantum;      // final slice, ticks
        uint32_t baseQuantum;  // slice from workload class alone
        Workload cls;
        uint32_t flags;        // DrrFlag bitmask: which rules fired
    };

    DrrDecision drrDecide(const DrrInput& in);

    // Human-readable "why", e.g.
    // "class=CPU Intensive base=12; load 8>=6 x3/4; => q=9"
    // Writes at most cap bytes (NUL-terminated).
    void drrExplain(const DrrInput& in, const DrrDecision& d, char* out, uint32_t cap);
}
