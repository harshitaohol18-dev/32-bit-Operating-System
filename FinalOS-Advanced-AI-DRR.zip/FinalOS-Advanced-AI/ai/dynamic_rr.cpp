#include "dynamic_rr.hpp"
#include "adaptive_quantum.hpp"

namespace AI {

    DrrDecision drrDecide(const DrrInput& in) {
        DrrDecision d;
        d.cls = classify(in.burstTicks, in.waitTicks, in.priority, in.runnable);
        d.baseQuantum = getAdaptiveQuantum(d.cls);
        d.flags = 0;
        int32_t q = (int32_t)d.baseQuantum;

        // Rule 1 - load: under contention a shorter slice cuts the time
        // everyone else waits for their first/next turn.
        if (in.runnable >= DRR_HIGH_LOAD) { q = (q * 3) / 4; d.flags |= DRR_LOAD_SHRINK; }
        // Rule 2 - alone: switching to nobody is pure overhead.
        else if (in.runnable <= 1)        { q = q * 2;       d.flags |= DRR_ALONE_GROW; }

        // Rule 3 - priority (0 = most urgent).
        if (in.priority <= 2)       { q += 2; d.flags |= DRR_PRIO_BOOST; }
        else if (in.priority >= 8)  { q -= 1; d.flags |= DRR_PRIO_PENALTY; }

        if (q < (int32_t)DRR_MIN_Q) { q = DRR_MIN_Q; d.flags |= DRR_CLAMP_LO; }
        if (q > (int32_t)DRR_MAX_Q) { q = DRR_MAX_Q; d.flags |= DRR_CLAMP_HI; }
        d.quantum = (uint32_t)q;
        return d;
    }

    namespace {
        struct W { char* o; uint32_t n, cap; };
        void putc_(W& w, char c) { if (w.n + 1 < w.cap) w.o[w.n++] = c; }
        void puts_(W& w, const char* s) { while (*s) putc_(w, *s++); }
        void putu(W& w, uint32_t v) {
            char t[12]; int i = 0;
            if (!v) t[i++] = '0';
            while (v) { t[i++] = (char)('0' + v % 10); v /= 10; }
            while (i) putc_(w, t[--i]);
        }
    }

    void drrExplain(const DrrInput& in, const DrrDecision& d, char* out, uint32_t cap) {
        if (!cap) return;
        W w{out, 0, cap};
        puts_(w, "class="); puts_(w, workloadName(d.cls));
        puts_(w, " base="); putu(w, d.baseQuantum);
        if (d.flags & DRR_LOAD_SHRINK)  { puts_(w, "; load "); putu(w, in.runnable); puts_(w, ">=6 x3/4"); }
        if (d.flags & DRR_ALONE_GROW)   { puts_(w, "; alone x2"); }
        if (d.flags & DRR_PRIO_BOOST)   { puts_(w, "; prio "); putu(w, in.priority); puts_(w, " +2"); }
        if (d.flags & DRR_PRIO_PENALTY) { puts_(w, "; prio "); putu(w, in.priority); puts_(w, " -1"); }
        if (d.flags & DRR_CLAMP_LO)     { puts_(w, "; clamp min"); }
        if (d.flags & DRR_CLAMP_HI)     { puts_(w, "; clamp max"); }
        puts_(w, "; => q="); putu(w, d.quantum);
        w.o[w.n] = 0;
    }
}
