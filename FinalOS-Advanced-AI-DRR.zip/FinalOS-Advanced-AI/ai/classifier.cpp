// classifier.cpp - see classifier.hpp for provenance and the
// MemKB-collapsing note. Thresholds below are copied directly from
// tree_rules.txt's surviving (class-determining) splits; only the
// scale of "CPU_time" and "Wait" needed reinterpreting from the
// original simulator's abstract time units into this kernel's 100Hz
// scheduler ticks, which is why they're passed in as ticks rather
// than re-deriving a unit conversion here.
#include "classifier.hpp"

namespace AI {

    const char* workloadName(Workload w) {
        switch (w) {
            case Workload::ShortRunning: return "Short Running";
            case Workload::Interactive:  return "Interactive";
            case Workload::IOIntensive:  return "I/O Intensive";
            case Workload::LongRunning:  return "Long Running";
            case Workload::CPUIntensive: return "CPU Intensive";
            case Workload::Background:   return "Background";
        }
        return "Unknown";
    }

    Workload classify(uint32_t cpuBurstTicks, uint32_t waitTicks,
                       uint32_t priority, uint32_t readyQueueLen) {

        // Root split: CPU_time <= 11
        if (cpuBurstTicks <= 11) {

            // CPU_time <= 3 -> every surviving leaf in the source tree
            // under this branch is "Short Running" once the MemKB-only
            // splits are collapsed.
            if (cpuBurstTicks <= 3) {
                return Workload::ShortRunning;
            }

            // 3 < CPU_time <= 11
            if (priority <= 3) {
                // Urgent/interactive-priority tasks: a short ready
                // queue means it's genuinely interactive; a long one
                // means it's actually waiting on something else.
                return (readyQueueLen <= 426) ? Workload::Interactive
                                               : Workload::IOIntensive;
            } else {
                // Lower-priority tasks in this CPU_time band: mostly
                // I/O-bound unless they've been waiting a long time,
                // at which point the tree calls it Background.
                return (waitTicks <= 552) ? Workload::IOIntensive
                                           : Workload::Background;
            }

        } else if (cpuBurstTicks <= 14) {
            // 11 < CPU_time <= 14: mostly Long Running in the source
            // tree, except a mid-sized ready queue with a fairly
            // urgent priority, which the tree calls I/O Intensive.
            if (readyQueueLen > 104 && readyQueueLen <= 392 && priority <= 10) {
                return Workload::IOIntensive;
            }
            if (readyQueueLen > 363) {
                return Workload::IOIntensive;
            }
            return Workload::LongRunning;

        } else {
            // CPU_time > 14: dominant class across the whole source
            // subtree is CPU Intensive once MemKB-only splits collapse.
            return Workload::CPUIntensive;
        }
    }
}
