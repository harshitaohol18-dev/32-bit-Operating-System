#pragma once
// adaptive_quantum.hpp - maps a workload classification to a time
// quantum. Ported from os_project/src/adaptive_quantum.cpp (the
// AI-Assisted Round Robin research prototype); "I/O Intensive" is new
// here (it didn't exist as a class in that prototype's simpler
// heuristic classifier) and is given the same quantum as the
// prototype's fallback bucket, matching how it treated its other
// non-CPU-bound, non-interactive class ("Background").
#include <stdint.h>
#include "classifier.hpp"

namespace AI {

    // Returns a validated quantum in ticks. Mirrors the source
    // prototype's fault_handler.cpp validateQuantum() bound (1-20)
    // so a corrupted/unexpected classification can't hand a task an
    // unreasonable slice of the CPU.
    uint32_t getAdaptiveQuantum(Workload w);
}
