#pragma once
// classifier.hpp - workload classifier for the AI-Adaptive scheduler
// mode. This is a hand-compiled port of a decision tree trained
// offline (scikit-learn, see Person1_Deliverables/tree_rules.txt for
// the original) on synthetic scheduler telemetry (workload_data.csv),
// re-expressed as plain C++ so it can run inside a freestanding
// kernel with no ML runtime and no dynamic allocation.
//
// The original tree used five features: CPU_time, Wait, Priority,
// RQ_len, and MemKB. This kernel doesn't track per-task memory use,
// so MemKB-only splits (ones where both branches of the tree led to
// the same class regardless of the MemKB value - the tree had several
// of these, typical of a small tree fit on synthetic data) were
// collapsed to their shared class, and splits where MemKB was the
// *only* distinguishing feature were resolved to the branch's
// majority class. See README.md's "AI-Adaptive Scheduling" section
// for the full mapping from the original tree to this function.
#include <stdint.h>

namespace AI {

    enum class Workload : uint8_t {
        ShortRunning,
        Interactive,
        IOIntensive,
        LongRunning,
        CPUIntensive,
        Background,
    };

    const char* workloadName(Workload w);

    // cpuBurstTicks: this task's average observed CPU burst length
    //                (ticks actually run per scheduling turn so far) -
    //                stands in for the tree's "CPU_time" feature.
    // waitTicks:     ticks spent READY-but-not-running (aging counter)
    //                - the tree's "Wait" feature.
    // priority:      task priority, lower number = more urgent (this
    //                kernel's convention) - the tree's "Priority".
    // readyQueueLen: number of currently READY/RUNNING tasks - the
    //                tree's "RQ_len".
    Workload classify(uint32_t cpuBurstTicks, uint32_t waitTicks,
                       uint32_t priority, uint32_t readyQueueLen);
}
