#pragma once
// heap.hpp - simple first-fit free-list kernel heap allocator.
// No paging-backed demand growth: the heap is a fixed static region
// (identity-mapped, so it works whether or not paging is on yet).
#include <stdint.h>
#include <stddef.h>

namespace Heap {
    void initialize();
    void* kmalloc(size_t size);
    void kfree(void* ptr);

    struct Stats {
        uint32_t totalBytes;
        uint32_t usedBytes;
        uint32_t freeBytes;
        uint32_t blockCount;
        uint32_t freeBlockCount;
    };
    Stats getStats();
}
