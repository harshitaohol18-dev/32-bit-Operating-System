// heap.cpp - first-fit free-list allocator over a static arena.
//
// Layout: [BlockHeader][user data...][BlockHeader][user data...]...
// Each header carries size (of the user-data region), a free flag,
// and a forward link. Free/alloc are O(n) scans over the header
// chain - simple and correct, which matters more than speed here.
#include "heap.hpp"

extern "C" void kprint(const char* str);

namespace Heap {

    struct BlockHeader {
        uint32_t magic;      // corruption/sanity check
        size_t   size;       // usable bytes following this header
        bool     free;
        BlockHeader* next;
    };

    constexpr uint32_t HEAP_MAGIC = 0x4B484541; // "KHEA"
    constexpr size_t HEAP_SIZE = 4 * 1024 * 1024; // 4MB kernel heap

    alignas(16) static uint8_t heapArena[HEAP_SIZE];
    static BlockHeader* freeListHead = nullptr;
    static uint32_t usedBytes = 0;

    static size_t align16(size_t n) { return (n + 15) & ~((size_t)15); }

    void initialize() {
        kprint("[HEAP] Initializing 4MB kernel heap...\n");

        freeListHead = (BlockHeader*)heapArena;
        freeListHead->magic = HEAP_MAGIC;
        freeListHead->size = HEAP_SIZE - sizeof(BlockHeader);
        freeListHead->free = true;
        freeListHead->next = nullptr;
        usedBytes = 0;

        kprint("[HEAP] Ready\n");
    }

    static void splitBlock(BlockHeader* block, size_t size) {
        size_t remaining = block->size - size;
        if (remaining <= sizeof(BlockHeader) + 16) return; // not worth splitting

        BlockHeader* newBlock = (BlockHeader*)((uint8_t*)(block + 1) + size);
        newBlock->magic = HEAP_MAGIC;
        newBlock->size = remaining - sizeof(BlockHeader);
        newBlock->free = true;
        newBlock->next = block->next;

        block->size = size;
        block->next = newBlock;
    }

    void* kmalloc(size_t size) {
        if (size == 0) return nullptr;
        size = align16(size);

        BlockHeader* current = freeListHead;
        while (current) {
            if (current->free && current->size >= size) {
                splitBlock(current, size);
                current->free = false;
                usedBytes += (uint32_t)current->size;
                return (void*)(current + 1);
            }
            current = current->next;
        }

        kprint("[HEAP] kmalloc: out of memory\n");
        return nullptr;
    }

    static void mergeAdjacentFree() {
        BlockHeader* current = freeListHead;
        while (current && current->next) {
            if (current->free && current->next->free) {
                current->size += sizeof(BlockHeader) + current->next->size;
                current->next = current->next->next;
                continue; // re-check same node against its new neighbour
            }
            current = current->next;
        }
    }

    void kfree(void* ptr) {
        if (!ptr) return;
        BlockHeader* block = (BlockHeader*)ptr - 1;
        if (block->magic != HEAP_MAGIC) {
            kprint("[HEAP] kfree: corrupted or invalid pointer, ignoring\n");
            return;
        }
        if (block->free) return; // double free guard

        block->free = true;
        if (usedBytes >= block->size) usedBytes -= (uint32_t)block->size;
        mergeAdjacentFree();
    }

    Stats getStats() {
        Stats s{};
        s.totalBytes = HEAP_SIZE;
        s.usedBytes = usedBytes;
        s.freeBytes = HEAP_SIZE - usedBytes;

        BlockHeader* current = freeListHead;
        while (current) {
            s.blockCount++;
            if (current->free) s.freeBlockCount++;
            current = current->next;
        }
        return s;
    }
}
